<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Application
|--------------------------------------------------------------------------
*/

define('APP_NAME', 'Square Furniture Manufacture');

/*
| Your XAMPP project is:
| C:\xampp\htdocs\pys\
|
| Therefore the website URL is:
| http://localhost/pys/
*/
define('BASE_URL', '/pys');

define('CURRENCY', 'ZAR');


/*
|--------------------------------------------------------------------------
| Database
|--------------------------------------------------------------------------
*/

define('DB_HOST', 'localhost');
define('DB_NAME', 'furniture_db');
define('DB_USER', 'root');
define('DB_PASS', '');


/*
|--------------------------------------------------------------------------
| Administrator
|--------------------------------------------------------------------------
*/

define('ADMIN_EMAIL', 'technical@bthirteennets.co.za');

/*
|--------------------------------------------------------------------------
| Brevo transactional email
|--------------------------------------------------------------------------
| Generate an API key in Brevo > Settings > SMTP & API.
| The sender email must be verified in Brevo.
| Keep the API key private and never commit a real key to public source control.
|--------------------------------------------------------------------------
*/
/*
| Brevo transactional email
*/

define('BREVO_API_KEY', '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');

define('BREVO_SMTP_HOST', 'smtp-relay.brevo.com');
define('BREVO_SMTP_PORT', 587);
define('BREVO_SMTP_USERNAME', 'b9ef5e001@smtp-brevo.com');
define('BREVO_SMTP_PASSWORD', 'xsmtpsib-b5ae8649490e7c629770c586f99b41eba45a44533997f510d2645ef8efb92817-Ex2feAi140NAG4OF');

define('BREVO_SENDER_EMAIL', 'technical@bthirteennets.co.za');
define('BREVO_SENDER_NAME', APP_NAME);
define('BREVO_REPLY_TO', ADMIN_EMAIL);


/*
|--------------------------------------------------------------------------
| PayFast
|--------------------------------------------------------------------------
*/

define('PAYFAST_SANDBOX', true);

define(
    'PAYFAST_MERCHANT_ID',
    'YOUR_PAYFAST_MERCHANT_ID'
);

define(
    'PAYFAST_MERCHANT_KEY',
    'YOUR_PAYFAST_MERCHANT_KEY'
);

define(
    'PAYFAST_PASSPHRASE',
    'YOUR_PAYFAST_PASSPHRASE'
);


/*
|--------------------------------------------------------------------------
| Timezone
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Africa/Johannesburg');