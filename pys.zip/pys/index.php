<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/init.php';

$page_title = 'Home - ' . APP_NAME;


/*
|--------------------------------------------------------------------------
| HERO SLIDES
|--------------------------------------------------------------------------
*/

$slides = [
    [
        'img' => 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=85',
        'eyebrow' => 'Made for living',
        'title' => 'Furniture that makes home feel like home.',
        'text' => 'Quality furniture for bedrooms, kitchens, living rooms and outdoor spaces.'
    ],
    [
        'img' => 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1800&q=85',
        'eyebrow' => 'Living collection',
        'title' => 'Modern Living Rooms',
        'text' => 'Comfortable pieces with a clean, timeless look.'
    ],
    [
        'img' => 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85',
        'eyebrow' => 'Outdoor collection',
        'title' => 'Outdoor Collection',
        'text' => 'Create a beautiful space for relaxed South African living.'
    ],
    [
        'img' => 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1800&q=85',
        'eyebrow' => 'Bedroom collection',
        'title' => 'Sleep in style',
        'text' => 'Furniture designed around comfort, storage and everyday living.'
    ],
];


/*
|--------------------------------------------------------------------------
| CATEGORIES
|--------------------------------------------------------------------------
*/

$cats = [
    'Bedroom' => [
        'img' => 'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Beds, storage & more'
    ],

    'Kitchen' => [
        'img' => 'https://images.unsplash.com/photo-1556912167-f556f1f39fdf?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Cabinets & kitchen furniture'
    ],

    'Living' => [
        'img' => 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Sofas, tables & chairs'
    ],

    'Out-door' => [
        'img' => 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Patio & outdoor comfort'
    ],

    'Dining' => [
        'img' => 'https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Dining tables & chairs'
    ],

    'Office' => [
        'img' => 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=700&q=80',
        'desc' => 'Desks, chairs & office furniture'
    ],
];


include __DIR__ . '/includes/header.php';

?>


<!-- =========================================================
     HERO
========================================================== -->

<section class="hero-wrap">
  <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">


    <div class="container">

        <div class="hero" id="hero">

            <?php foreach ($slides as $i => $s): ?>

                <article class="hero-slide <?= $i === 0 ? 'active' : '' ?>">

                    <img
                        src="<?= e($s['img']) ?>"
                        alt="<?= e($s['title']) ?>"
                    >

                    <div class="hero-content">

                        <div class="eyebrow">
                            <?= e($s['eyebrow']) ?>
                        </div>

                        <h1>
                            <?= e($s['title']) ?>
                        </h1>

                        <p>
                            <?= e($s['text']) ?>
                        </p>

                        <a
                            class="btn-yellow"
                            href="<?= BASE_URL ?>/products.php"
                        >
                            Shop Now
                        </a>

                    </div>

                </article>

            <?php endforeach; ?>


            <!-- HERO ARROWS -->

            <button
                class="hero-arrow prev"
                type="button"
                data-hero-prev
                aria-label="Previous slide"
            >
                ‹
            </button>

            <button
                class="hero-arrow next"
                type="button"
                data-hero-next
                aria-label="Next slide"
            >
                ›
            </button>


            <!-- HERO DOTS -->

            <div class="hero-dots">

                <?php foreach ($slides as $i => $s): ?>

                    <button
                        class="hero-dot <?= $i === 0 ? 'active' : '' ?>"
                        data-hero-dot="<?= $i ?>"
                        aria-label="Slide <?= $i + 1 ?>"
                    ></button>

                <?php endforeach; ?>

            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     SHOP BY CATEGORY
========================================================== -->

<section class="section">

    <div class="container">

        <div class="section-head">

            <div>

                <h2>
                    Shop by Category
                </h2>

                <p>
                    Find the right furniture for every room.
                </p>

            </div>

            <a
                class="view-all"
                href="<?= BASE_URL ?>/products.php"
            >
                View all →
            </a>

        </div>


        <div class="category-grid">

            <?php foreach ($cats as $name => $c): ?>

                <a
                    class="category-card"
                    href="<?= BASE_URL ?>/products.php?category=<?= urlencode($name) ?>"
                >

                    <img
                        src="<?= e($c['img']) ?>"
                        alt="<?= e($name) ?>"
                        loading="lazy"
                    >

                    <div class="category-card-body">

                        <h3>
                            <?= e($name) ?>
                        </h3>

                        <p>
                            <?= e($c['desc']) ?>
                        </p>

                    </div>

                </a>

            <?php endforeach; ?>

        </div>


        <!-- =====================================================
             TRUST STRIP
        ====================================================== -->

        <div class="trust-strip">

            <div class="trust-item">

                <span>🚚</span>

                <div>

                    <strong>
                        Delivery options
                    </strong>

                    <small>
                        South African delivery
                    </small>

                </div>

            </div>


            <div class="trust-item">

                <span>✓</span>

                <div>

                    <strong>
                        Made to last
                    </strong>

                    <small>
                        Quality furniture
                    </small>

                </div>

            </div>


            <div class="trust-item">

                <span>🔒</span>

                <div>

                    <strong>
                        Secure payment
                    </strong>

                    <small>
                        Safe checkout
                    </small>

                </div>

            </div>


            <div class="trust-item">

                <span>💬</span>

                <div>

                    <strong>
                        Personal support
                    </strong>

                    <small>
                        WhatsApp assistance
                    </small>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =========================================================
     PROMO SECTION
========================================================== -->

<section
    class="section"
    style="padding-top:4px"
>

    <div class="container">

        <div class="promo">

            <div>

                <h3>
                    Refresh your space, one room at a time.
                </h3>

                <p>
                    Browse our furniture collection and find something
                    made for your home.
                </p>

            </div>


            <a
                class="btn-yellow"
                href="<?= BASE_URL ?>/products.php"
            >
                Browse all furniture
            </a>

        </div>

    </div>

</section>


<!-- =========================================================
     FEATURED PRODUCTS
========================================================== -->

<section class="section">

    <div class="container">

        <div class="section-head">

            <div>

                <h2>
                    Featured Products
                </h2>

                <p>
                    Selected pieces available now.
                </p>

            </div>

            <a
                class="view-all"
                href="<?= BASE_URL ?>/products.php"
            >
                View all →
            </a>

        </div>


        <div class="product-grid">

            <?php

            $res = $conn->query(
                "SELECT *
                 FROM products
                 WHERE status = 'active'
                 ORDER BY id DESC
                 LIMIT 8"
            );

            ?>


            <?php if ($res && $res->num_rows): ?>

                <?php while ($p = $res->fetch_assoc()): ?>

                    <?php

                    /*
                    |--------------------------------------------------------------------------
                    | PRODUCT IMAGE
                    |--------------------------------------------------------------------------
                    */

                    $img = !empty($p['image'])
                        ? BASE_URL . '/' . ltrim($p['image'], '/')
                        : 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80';


                    /*
                    |--------------------------------------------------------------------------
                    | PYS FURNITURE WHATSAPP MESSAGE
                    |--------------------------------------------------------------------------
                    */

                    $msg =
                        "Hello PYS Furniture, "
                        . "I am interested in "
                        . $p['name']
                        . " (R "
                        . number_format((float) $p['price'], 2)
                        . "). "
                        . "Please provide more information.";


                    /*
                    |--------------------------------------------------------------------------
                    | PYS FURNITURE WHATSAPP NUMBER
                    |--------------------------------------------------------------------------
                    |
                    | +278373636
                    | WhatsApp format: 278373636
                    |
                    */

                    $wa =
                        'https://wa.me/27738373636?text='
                        . rawurlencode($msg);

                    ?>


                    <!-- =================================================
                         PRODUCT CARD
                    ================================================== -->

                    <article class="product-card">


                        <!-- PRODUCT IMAGE -->

                        <a
                            class="product-image-wrap"
                            href="<?= BASE_URL ?>/products.php?q=<?= urlencode($p['name']) ?>"
                        >

                            <img
                                src="<?= e($img) ?>"
                                alt="<?= e($p['name']) ?>"
                                loading="lazy"
                                onerror="this.src='https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80'"
                            >


                            <?php if ((int) $p['stock'] > 0): ?>

                                <span class="product-badge">
                                    Available
                                </span>

                            <?php endif; ?>

                        </a>


                        <!-- PRODUCT DETAILS -->

                        <div class="product-info">


                            <div class="product-category">

                                <?= e($p['category']) ?>

                            </div>


                            <div class="product-name">

                                <?= e($p['name']) ?>

                            </div>


                            <div class="product-price">

                                R <?= number_format((float) $p['price'], 2) ?>


                                <?php if ((int) $p['stock'] > 0): ?>

                                    <span class="product-stock">
                                        In stock
                                    </span>

                                <?php else: ?>

                                    <span
                                        class="product-stock"
                                        style="color:#b42318"
                                    >
                                        Out of stock
                                    </span>

                                <?php endif; ?>

                            </div>


                            <!-- =================================================
                                 PRODUCT ACTIONS
                            ================================================== -->

                            <div class="product-actions">


                                <?php if ((int) $p['stock'] > 0): ?>

                                    <a
                                        class="btn-cart"
                                        href="<?= BASE_URL ?>/add_to_cart.php?id=<?= (int) $p['id'] ?>"
                                    >
                                        Add to Cart
                                    </a>

                                <?php endif; ?>


                                <!-- PYS FURNITURE WHATSAPP -->

                                <a
                                    class="btn-wa"
                                    href="<?= e($wa) ?>"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    WhatsApp
                                </a>

                            </div>

                        </div>

                    </article>


                <?php endwhile; ?>


            <?php else: ?>


                <!-- NO PRODUCTS -->

                <div class="empty-state">

                    <h3>
                        No featured products yet
                    </h3>

                    <p>
                        Add active products from the admin dashboard.
                    </p>

                </div>


            <?php endif; ?>

        </div>

    </div>

</section>


<!-- =========================================================
     HERO SLIDER JAVASCRIPT
========================================================== -->

<script>

(function () {

    const slides = [
        ...document.querySelectorAll('.hero-slide')
    ];

    const dots = [
        ...document.querySelectorAll('.hero-dot')
    ];

    let n = 0;
    let timer;


    function show(i) {

        if (!slides.length) {
            return;
        }

        n = (i + slides.length) % slides.length;


        slides.forEach((s, j) => {

            s.classList.toggle(
                'active',
                j === n
            );

        });


        dots.forEach((d, j) => {

            d.classList.toggle(
                'active',
                j === n
            );

        });

    }


    function restart() {

        clearInterval(timer);

        timer = setInterval(
            () => show(n + 1),
            5000
        );

    }


    document
        .querySelector('[data-hero-next]')
        ?.addEventListener('click', () => {

            show(n + 1);
            restart();

        });


    document
        .querySelector('[data-hero-prev]')
        ?.addEventListener('click', () => {

            show(n - 1);
            restart();

        });


    dots.forEach((d, i) => {

        d.addEventListener('click', () => {

            show(i);
            restart();

        });

    });


    restart();

})();

</script>


<?php

include __DIR__ . '/includes/footer.php';

?>