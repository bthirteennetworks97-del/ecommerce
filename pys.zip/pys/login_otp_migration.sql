-- Square Furniture Manufacture - Login OTP migration
-- Run once in phpMyAdmin against furniture_db.

CREATE TABLE IF NOT EXISTS `auth_otps` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(190) NOT NULL,
  `purpose` enum('login','email_verify') NOT NULL DEFAULT 'login',
  `otp_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_auth_otp_user_purpose` (`user_id`,`purpose`,`id`),
  KEY `idx_auth_otp_expiry` (`expires_at`),
  KEY `idx_auth_otp_email` (`email`,`purpose`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
