<?php
declare(strict_types=1);

require_once '../includes/init.php';
header('Content-Type: application/json; charset=utf-8');

$result = $conn->query("SELECT id, name, description, category, price, stock, image FROM products WHERE status='active' ORDER BY id DESC");
$data = [];

while ($product = $result->fetch_assoc()) {
    $data[] = $product;
}

echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_SLASHES);
