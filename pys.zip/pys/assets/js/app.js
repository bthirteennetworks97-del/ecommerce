document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{
    if(!confirm(el.dataset.confirm)) e.preventDefault();
  }));
  const toggle=document.querySelector('[data-mobile-menu]');
  const nav=document.querySelector('[data-mobile-nav]');
  if(toggle&&nav) toggle.addEventListener('click',()=>nav.classList.toggle('open'));
});
