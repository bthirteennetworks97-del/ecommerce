(() => {
    'use strict';

    /*
    |--------------------------------------------------------------------------
    | Configuration
    |--------------------------------------------------------------------------
    */

    const BASE_URL =
        window.SQUARE_FURNITURE_BASE_URL ||
        '/pys';

    const ENDPOINTS = {
        account:
            `${BASE_URL}/customer/account.php`,

        orders:
            `${BASE_URL}/customer/orders.php`,

        orderDetails:
            `${BASE_URL}/customer/order_details.php`,

        profile:
            `${BASE_URL}/customer/profile.php`,

        sendEmailChangeOtp:
            `${BASE_URL}/customer/send_email_change_otp.php`,

        verifyEmailChangeOtp:
            `${BASE_URL}/customer/verify_email_change_otp.php`,

        password:
            `${BASE_URL}/customer/password.php`,

        sendOtp:
            `${BASE_URL}/customer/send_otp.php`,

        verifyOtp:
            `${BASE_URL}/customer/verify_otp.php`,

        cartRemove:
            `${BASE_URL}/customer/cart_remove.php`,

        cartUpdate:
            `${BASE_URL}/customer/cart_update.php`,

        logout:
            `${BASE_URL}/customer/logout.php`
    };

    /*
    |--------------------------------------------------------------------------
    | State
    |--------------------------------------------------------------------------
    */

    const state = {
        currentSection: 'profile',
        previousSection: null,
        currentOrderId: null,
        cartCount: 0,
        cartTotal: 0,
        drawerOpen: false,
        loading: false
    };

    /*
    |--------------------------------------------------------------------------
    | DOM Helpers
    |--------------------------------------------------------------------------
    */

    const $ = (selector, parent = document) =>
        parent.querySelector(selector);

    const $$ = (selector, parent = document) =>
        Array.from(parent.querySelectorAll(selector));

    /*
    |--------------------------------------------------------------------------
    | HTML Escape
    |--------------------------------------------------------------------------
    */

    function escapeHTML(value) {
        const div = document.createElement('div');

        div.textContent =
            value === null ||
            value === undefined
                ? ''
                : String(value);

        return div.innerHTML;
    }

    /*
    |--------------------------------------------------------------------------
    | CSRF Token
    |--------------------------------------------------------------------------
    */

    function getCsrfToken() {

        const input =
            document.querySelector(
                'input[name="csrf_token"]'
            );

        if (input && input.value) {
            return input.value;
        }

        const meta =
            document.querySelector(
                'meta[name="csrf-token"]'
            );

        if (meta && meta.content) {
            return meta.content;
        }

        if (
            window.SQUARE_FURNITURE_CSRF_TOKEN
        ) {
            return window.SQUARE_FURNITURE_CSRF_TOKEN;
        }

        return '';
    }

    /*
    |--------------------------------------------------------------------------
    | Fetch Helper
    |--------------------------------------------------------------------------
    */

    async function request(
        url,
        options = {}
    ) {

        const method =
            options.method || 'GET';

        const headers = {
            'X-Requested-With':
                'XMLHttpRequest',

            'Accept':
                'application/json',

            ...(options.headers || {})
        };

        /*
        |--------------------------------------------------------------------------
        | CSRF Header
        |--------------------------------------------------------------------------
        */

        const csrfToken =
            getCsrfToken();

        if (
            method !== 'GET' &&
            csrfToken
        ) {
            headers['X-CSRF-Token'] =
                csrfToken;
        }

        const fetchOptions = {
            credentials: 'same-origin',
            ...options,
            method,
            headers
        };

        /*
        |--------------------------------------------------------------------------
        | Request
        |--------------------------------------------------------------------------
        */

        let response;

        try {

            response =
                await fetch(
                    url,
                    fetchOptions
                );

        } catch (error) {

            throw new Error(
                'Network error. Please check your connection and try again.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Response Text
        |--------------------------------------------------------------------------
        */

        const text =
            await response.text();

        let data = null;

        try {

            data =
                text
                    ? JSON.parse(text)
                    : null;

        } catch (error) {

            throw new Error(
                'The server returned an invalid response.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Authentication Redirect
        |--------------------------------------------------------------------------
        */

        if (
            response.status === 401 &&
            data &&
            data.redirect
        ) {

            closeDrawer();

            window.location.href =
                data.redirect;

            throw new Error(
                data.message ||
                'Please log in again.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Error Response
        |--------------------------------------------------------------------------
        */

        if (
            !response.ok ||
            !data ||
            data.success === false
        ) {

            throw new Error(
                data?.message ||
                'Something went wrong. Please try again.'
            );
        }

        return data;
    }

    /*
    |--------------------------------------------------------------------------
    | FormData Helper
    |--------------------------------------------------------------------------
    */

    function createFormData(form) {

        const formData =
            new FormData(form);

        const csrfToken =
            getCsrfToken();

        if (
            csrfToken &&
            !formData.has('csrf_token')
        ) {
            formData.append(
                'csrf_token',
                csrfToken
            );
        }

        return formData;
    }

    /*
    |--------------------------------------------------------------------------
    | Drawer Elements
    |--------------------------------------------------------------------------
    */

    function getDrawer() {
        return $(
            '#customerAccountDrawer'
        );
    }

    function getOverlay() {
        return $(
            '#customerAccountOverlay'
        );
    }

    function getContent() {
        return $(
            '#customerAccountContent'
        );
    }

    function getTitle() {
        return $(
            '#customerAccountTitle'
        );
    }

    function getLoading() {
        return $(
            '#customerAccountLoading'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Ensure Drawer Exists
    |--------------------------------------------------------------------------
    */

    function ensureDrawer() {

        let drawer =
            getDrawer();

        if (drawer) {
            return drawer;
        }

        /*
        |--------------------------------------------------------------------------
        | Create Drawer
        |--------------------------------------------------------------------------
        */

        const wrapper =
            document.createElement('div');

        wrapper.innerHTML = `
            <div
                id="customerAccountOverlay"
                class="customer-account-overlay"
                aria-hidden="true"
            ></div>

            <aside
                id="customerAccountDrawer"
                class="customer-account-drawer"
                aria-hidden="true"
                role="dialog"
                aria-modal="true"
                aria-labelledby="customerAccountTitle"
            >

                <div class="customer-account-header">

                    <button
                        type="button"
                        id="customerAccountBack"
                        class="customer-account-back"
                        aria-label="Go back"
                        hidden
                    >
                        <span aria-hidden="true">←</span>
                    </button>

                    <div class="customer-account-heading">

                        <span
                            class="customer-account-eyebrow"
                        >
                            SQUARE FURNITURE
                        </span>

                        <h2
                            id="customerAccountTitle"
                        >
                            My Account
                        </h2>

                    </div>

                    <button
                        type="button"
                        id="customerAccountClose"
                        class="customer-account-close"
                        aria-label="Close account"
                    >
                        <span aria-hidden="true">×</span>
                    </button>

                </div>

                <div
                    id="customerAccountLoading"
                    class="customer-account-loading"
                    hidden
                >
                    <span class="customer-account-spinner"></span>
                    <span>Loading...</span>
                </div>

                <div
                    id="customerAccountContent"
                    class="customer-account-content"
                ></div>

            </aside>
        `;

        document.body.appendChild(
            wrapper
        );

        drawer =
            getDrawer();

        bindDrawerEvents();

        return drawer;
    }

    /*
    |--------------------------------------------------------------------------
    | Open Drawer
    |--------------------------------------------------------------------------
    */

    function openDrawer(
        section = 'profile'
    ) {

        const drawer =
            ensureDrawer();

        const overlay =
            getOverlay();

        if (!drawer) {
            return;
        }

        state.drawerOpen = true;

        drawer.setAttribute(
            'aria-hidden',
            'false'
        );

        if (overlay) {
            overlay.setAttribute(
                'aria-hidden',
                'false'
            );
        }

        document.body.classList.add(
            'customer-account-open'
        );

        /*
        |--------------------------------------------------------------------------
        | Prevent Background Scroll
        |--------------------------------------------------------------------------
        */

        document.body.style.overflow =
            'hidden';

        /*
        |--------------------------------------------------------------------------
        | Load Section
        |--------------------------------------------------------------------------
        */

        loadCustomerAccountSection(
            section
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Close Drawer
    |--------------------------------------------------------------------------
    */

    function closeDrawer() {

        const drawer =
            getDrawer();

        const overlay =
            getOverlay();

        if (!drawer) {
            return;
        }

        state.drawerOpen = false;

        drawer.setAttribute(
            'aria-hidden',
            'true'
        );

        if (overlay) {
            overlay.setAttribute(
                'aria-hidden',
                'true'
            );
        }

        document.body.classList.remove(
            'customer-account-open'
        );

        document.body.style.overflow =
            '';

        state.currentOrderId =
            null;
    }

    /*
    |--------------------------------------------------------------------------
    | Drawer Loading
    |--------------------------------------------------------------------------
    */

    function setLoading(
        loading = true
    ) {

        state.loading =
            loading;

        const loadingElement =
            getLoading();

        const content =
            getContent();

        if (loadingElement) {
            loadingElement.hidden =
                !loading;
        }

        if (content) {
            content.classList.toggle(
                'is-loading',
                loading
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Set Drawer Title
    |--------------------------------------------------------------------------
    */

    function setTitle(title) {

        const titleElement =
            getTitle();

        if (titleElement) {
            titleElement.textContent =
                title;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Back Button
    |--------------------------------------------------------------------------
    */

    function updateBackButton(
        show
    ) {

        const button =
            $('#customerAccountBack');

        if (!button) {
            return;
        }

        button.hidden =
            !show;
    }

    /*
    |--------------------------------------------------------------------------
    | Load Main Account
    |--------------------------------------------------------------------------
    */

    async function loadCustomerAccountSection(
        section = 'profile'
    ) {

        ensureDrawer();

        const validSections = [
            'profile',
            'settings',
            'orders',
            'cart',
            'address',
            'password',
            'verification'
        ];

        if (
            !validSections.includes(
                section
            )
        ) {
            section =
                'profile';
        }

        state.currentSection =
            section;

        state.previousSection =
            null;

        state.currentOrderId =
            null;

        updateBackButton(false);

        setLoading(true);

        try {

            /*
            |--------------------------------------------------------------------------
            | Account Endpoint
            |--------------------------------------------------------------------------
            */

            const url =
                `${ENDPOINTS.account}?section=${encodeURIComponent(section)}&ajax=1`;

            const response =
                await fetch(
                    url,
                    {
                        method: 'GET',
                        credentials: 'same-origin',
                        headers: {
                            'X-Requested-With':
                                'XMLHttpRequest',

                            'Accept':
                                'text/html'
                        }
                    }
                );

            /*
            |--------------------------------------------------------------------------
            | Authentication
            |--------------------------------------------------------------------------
            */

            if (
                    response.status === 401
                ) 
            {

                    closeDrawer();

                    window.location.href =
                        `${BASE_URL}/auth/login.php`;

                    return;
           }
            const html =
                await response.text();

            if (!response.ok) {
                throw new Error(
                    'Unable to load your account.'
                );
            }

            const content =
                getContent();

            if (content) {
                content.innerHTML =
                    html;
            }

            setTitle(
                getSectionTitle(section)
            );

            bindContentEvents();

            updateAccountCounts();

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setLoading(false);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Section Titles
    |--------------------------------------------------------------------------
    */

    function getSectionTitle(
        section
    ) {

        const titles = {
            profile:
                'My Account',

            settings:
                'Profile Settings',

            orders:
                'My Orders',

            cart:
                'My Cart',

            address:
                'Delivery Details',

            password:
                'Change Password',

            verification:
                'Email Verification'
        };

        return (
            titles[section] ||
            'My Account'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Load Orders
    |--------------------------------------------------------------------------
    */

    async function loadOrders(
        page = 1,
        status = ''
    ) {

        state.previousSection =
            'profile';

        state.currentSection =
            'orders';

        state.currentOrderId =
            null;

        updateBackButton(false);

        setTitle(
            'My Orders'
        );

        setLoading(true);

        try {

            let url =
                `${ENDPOINTS.orders}?page=${encodeURIComponent(page)}`;

            if (status) {
                url +=
                    `&status=${encodeURIComponent(status)}`;
            }

            const data =
                await request(url);

            // The orders endpoint returns pagination data. Normalize it
            // into the shape used by the renderer so clicking Orders never
            // exposes the raw JSON response to the customer UI.
            const pagination = data.pagination || {};
            const total = Number(pagination.total_orders || 0);
            const pageSize = Number(pagination.limit || 5);
            const currentPage = Number(pagination.page || page);
            const orderList = data.orders || [];
            const showingFrom = total > 0
                ? ((currentPage - 1) * pageSize) + 1
                : 0;
            const showingTo = total > 0
                ? Math.min(currentPage * pageSize, total)
                : 0;

            const summary = {
                total,
                page: currentPage,
                total_pages: Number(pagination.total_pages || 0),
                showing_from: showingFrom,
                showing_to: showingTo
            };

            renderOrders(
                orderList,
                summary,
                data.filter || status || ''
            );

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setLoading(false);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Render Orders
    |--------------------------------------------------------------------------
    */

    function renderOrders(
        orders,
        summary,
        currentFilter
    ) {

        const content =
            getContent();

        if (!content) {
            return;
        }

        let html = `
            <div class="account-orders">

                <div class="orders-toolbar">

                    <div class="orders-summary">
                        ${
                            summary.total > 0
                                ? `Showing ${summary.showing_from}
                                   – ${summary.showing_to}
                                   of ${summary.total} orders`
                                : 'No orders found'
                        }
                    </div>

                    <select
                        class="orders-status-filter"
                        id="ordersStatusFilter"
                        aria-label="Filter orders"
                    >
                        <option value="">All Orders</option>
                        <option value="pending"
                            ${currentFilter === 'pending' ? 'selected' : ''}>
                            Pending
                        </option>
                        <option value="paid"
                            ${currentFilter === 'paid' ? 'selected' : ''}>
                            Paid
                        </option>
                        <option value="processing"
                            ${currentFilter === 'processing' ? 'selected' : ''}>
                            Processing
                        </option>
                        <option value="shipped"
                            ${currentFilter === 'shipped' ? 'selected' : ''}>
                            Shipped
                        </option>
                        <option value="delivered"
                            ${currentFilter === 'delivered' ? 'selected' : ''}>
                            Delivered
                        </option>
                        <option value="cancelled"
                            ${currentFilter === 'cancelled' ? 'selected' : ''}>
                            Cancelled
                        </option>
                    </select>

                </div>
        `;

        /*
        |--------------------------------------------------------------------------
        | No Orders
        |--------------------------------------------------------------------------
        */

        if (!orders.length) {

            html += `
                <div class="account-empty-state">

                    <div class="account-empty-icon">
                        🛍
                    </div>

                    <h3>No orders yet</h3>

                    <p>
                        Your completed purchases will
                        appear here.
                    </p>

                    <button
                        type="button"
                        class="account-primary-button"
                        data-account-action="shop"
                    >
                        Continue Shopping
                    </button>

                </div>
            `;

        } else {

            html += `
                <div class="orders-list">
            `;

            orders.forEach(order => {

                html += `
                    <article
                        class="account-order-card"
                        data-order-id="${order.id}"
                    >

                        <div class="order-card-top">

                            <div>

                                <span
                                    class="order-card-label"
                                >
                                    ORDER
                                </span>

                                <strong>
                                    ${escapeHTML(
                                        order.order_number
                                    )}
                                </strong>

                            </div>

                            <span
                                class="order-status order-status-${escapeHTML(
                                    order.status
                                )}"
                            >
                                ${escapeHTML(
                                    order.status_label
                                )}
                            </span>

                        </div>

                        <div class="order-card-middle">

                            <div>
                                <span>Placed</span>
                                <strong>
                                    ${escapeHTML(
                                        order.created_at_formatted || order.created_at || ''
                                    )}
                                </strong>
                            </div>

                            <div>
                                <span>Items</span>
                                <strong>
                                    ${escapeHTML(
                                        order.total_quantity ?? order.items?.quantity ?? 0
                                    )}
                                </strong>
                            </div>

                            <div>
                                <span>Total</span>
                                <strong>
                                    ${escapeHTML(
                                        order.total_formatted
                                    )}
                                </strong>
                            </div>

                        </div>

                        <div class="order-card-bottom">

                            <button
                                type="button"
                                class="account-secondary-button"
                                data-order-id="${order.id}"
                                data-account-action="order-details"
                            >
                                View Order
                            </button>

                        </div>

                    </article>
                `;

            });

            html += `
                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | Pagination
        |--------------------------------------------------------------------------
        */

        if (
            summary.total_pages &&
            summary.total_pages > 1
        ) {

            html += `
                <div class="orders-pagination">
            `;

            if (
                summary.page > 1
            ) {

                html += `
                    <button
                        type="button"
                        class="pagination-button"
                        data-orders-page="${summary.page - 1}"
                    >
                        ← Previous
                    </button>
                `;

            }

            html += `
                <span class="pagination-current">
                    Page ${summary.page}
                    of ${summary.total_pages}
                </span>
            `;

            if (
                summary.page <
                summary.total_pages
            ) {

                html += `
                    <button
                        type="button"
                        class="pagination-button"
                        data-orders-page="${summary.page + 1}"
                    >
                        Next →
                    </button>
                `;

            }

            html += `
                </div>
            `;
        }

        html += `
            </div>
        `;

        content.innerHTML =
            html;

        bindContentEvents();
    }

    /*
    |--------------------------------------------------------------------------
    | Load Order Details
    |--------------------------------------------------------------------------
    */

    async function loadOrderDetails(
        orderId
    ) {

        orderId =
            parseInt(
                orderId,
                10
            );

        if (
            !orderId ||
            orderId <= 0
        ) {
            showError(
                'Invalid order.'
            );

            return;
        }

        state.previousSection =
            'orders';

        state.currentOrderId =
            orderId;

        updateBackButton(true);

        setTitle(
            'Order Details'
        );

        setLoading(true);

        try {

            const url =
                `${ENDPOINTS.orderDetails}?id=${encodeURIComponent(orderId)}`;

            const data =
                await request(url);

            renderOrderDetails(
                data.order
            );

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setLoading(false);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Render Order Details
    |--------------------------------------------------------------------------
    */

    function renderOrderDetails(
        order
    ) {

        const content =
            getContent();

        if (!content) {
            return;
        }

        if (!order) {

            showError(
                'Order information is unavailable.'
            );

            return;
        }

        let html = `
            <div class="order-details">

                <div class="order-details-header">

                    <div>

                        <span class="order-card-label">
                            ORDER
                        </span>

                        <h3>
                            ${escapeHTML(
                                order.order_number
                            )}
                        </h3>

                        <p>
                            ${escapeHTML(
                                order.created_at_formatted
                            )}
                        </p>

                    </div>

                    <span
                        class="order-status order-status-${escapeHTML(
                            order.status
                        )}"
                    >
                        ${escapeHTML(
                            order.status_label
                        )}
                    </span>

                </div>

                <div class="order-status-message">

                    <strong>
                        ${escapeHTML(
                            order.status_label
                        )}
                    </strong>

                    <p>
                        ${escapeHTML(
                            order.status_description
                        )}
                    </p>

                </div>
        `;

        /*
        |--------------------------------------------------------------------------
        | Timeline
        |--------------------------------------------------------------------------
        */

        if (
            order.status !==
            'cancelled'
        ) {

            html += `
                <div class="order-timeline">

                    <h4>
                        Order Progress
                    </h4>

                    <div class="order-timeline-list">
            `;

            (order.timeline || [])
                .forEach(step => {

                    html += `
                        <div
                            class="order-timeline-step
                            order-timeline-${escapeHTML(
                                step.state
                            )}"
                        >

                            <div
                                class="order-timeline-dot"
                            ></div>

                            <div
                                class="order-timeline-content"
                            >

                                <strong>
                                    ${escapeHTML(
                                        step.label
                                    )}
                                </strong>

                                <span>
                                    ${escapeHTML(
                                        step.description
                                    )}
                                </span>

                            </div>

                        </div>
                    `;

                });

            html += `
                    </div>
                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | Products
        |--------------------------------------------------------------------------
        */

        html += `
            <section class="order-products">

                <h4>
                    Items in Your Order
                </h4>
        `;

        if (
            order.items &&
            order.items.length
        ) {

            order.items.forEach(item => {

                const image =
                    item.product_image
                        ? `
                            <img
                                src="${escapeHTML(
                                    item.product_image
                                )}"
                                alt="${escapeHTML(
                                    item.product_name
                                )}"
                                loading="lazy"
                            >
                          `
                        : `
                            <div
                                class="order-product-placeholder"
                            >
                                SF
                            </div>
                          `;

                html += `
                    <div
                        class="order-product-item"
                    >

                        <div
                            class="order-product-image"
                        >
                            ${image}
                        </div>

                        <div
                            class="order-product-info"
                        >

                            <strong>
                                ${escapeHTML(
                                    item.product_name
                                )}
                            </strong>

                            <span>
                                Qty:
                                ${escapeHTML(
                                    item.quantity
                                )}
                            </span>

                            <span>
                                ${escapeHTML(
                                    item.price_formatted
                                )}
                                each
                            </span>

                        </div>

                        <strong
                            class="order-product-total"
                        >
                            ${escapeHTML(
                                item.line_total_formatted
                            )}
                        </strong>

                    </div>
                `;

            });

        } else {

            html += `
                <p class="account-muted">
                    No item information is available.
                </p>
            `;
        }

        html += `
            </section>
        `;

        /*
        |--------------------------------------------------------------------------
        | Customer / Delivery
        |--------------------------------------------------------------------------
        */

        html += `
            <section class="order-info-grid">

                <div class="order-info-box">

                    <h4>
                        Customer
                    </h4>

                    <p>
                        <strong>
                            ${escapeHTML(
                                order.customer?.name || ''
                            )}
                        </strong>
                    </p>

                    <p>
                        ${escapeHTML(
                            order.customer?.email || ''
                        )}
                    </p>

                    <p>
                        ${escapeHTML(
                            order.customer?.phone || ''
                        )}
                    </p>

                </div>

                <div class="order-info-box">

                    <h4>
                        Delivery
                    </h4>

                    <p>
                        ${escapeHTML(
                            order.delivery?.full_address || ''
                        )}
                    </p>

                </div>

            </section>
        `;

        /*
        |--------------------------------------------------------------------------
        | Payment
        |--------------------------------------------------------------------------
        */

        html += `
            <section class="order-payment-box">

                <div>
                    <span>
                        Items
                    </span>

                    <strong>
                        ${escapeHTML(
                            order.total_quantity
                        )}
                    </strong>
                </div>

                <div>
                    <span>
                        Order Total
                    </span>

                    <strong>
                        ${escapeHTML(
                            order.total_formatted
                        )}
                    </strong>
                </div>
        `;

        if (
            order.payment_ref
        ) {

            html += `
                <div>
                    <span>
                        Payment Reference
                    </span>

                    <strong>
                        ${escapeHTML(
                            order.payment_ref
                        )}
                    </strong>
                </div>
            `;
        }

        html += `
            </section>

            <button
                type="button"
                class="account-secondary-button account-full-button"
                data-account-action="back-orders"
            >
                ← Back to My Orders
            </button>

        </div>
        `;

        content.innerHTML =
            html;

        bindContentEvents();
    }

    /*
    |--------------------------------------------------------------------------
    | Cart Update
    |--------------------------------------------------------------------------
    */

    async function updateCartQuantity(
        productId,
        quantity
    ) {

        productId =
            parseInt(
                productId,
                10
            );

        quantity =
            parseInt(
                quantity,
                10
            );

        if (
            !productId ||
            productId <= 0
        ) {
            return;
        }

        if (
            Number.isNaN(quantity)
        ) {
            quantity = 1;
        }

        const formData =
            new FormData();

        formData.append(
            'product_id',
            String(productId)
        );

        formData.append(
            'quantity',
            String(quantity)
        );

        const csrfToken =
            getCsrfToken();

        if (csrfToken) {
            formData.append(
                'csrf_token',
                csrfToken
            );
        }

        try {

            const data =
                await request(
                    ENDPOINTS.cartUpdate,
                    {
                        method: 'POST',
                        body: formData
                    }
                );

            state.cartCount =
                parseInt(
                    data.cart_count || 0,
                    10
                );

            state.cartTotal =
                parseFloat(
                    data.cart_total || 0
                );

            /*
            |--------------------------------------------------------------------------
            | Update Cart UI
            |--------------------------------------------------------------------------
            */

            updateCartCountBadges();

            updateCartItemUI(
                data
            );

            updateCartTotalUI(
                data.cart_total
            );

            showToast(
                'Cart updated.',
                'success'
            );

        } catch (error) {

            showError(
                error.message
            );

            /*
            |--------------------------------------------------------------------------
            | Reload Cart
            |--------------------------------------------------------------------------
            */

            loadCustomerAccountSection(
                'cart'
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Update Cart Item UI
    |--------------------------------------------------------------------------
    */

    function updateCartItemUI(
        data
    ) {

        const productId =
            String(
                data.product_id
            );

        const item =
            document.querySelector(
                `[data-cart-product-id="${CSS.escape(productId)}"]`
            );

        if (!item) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Quantity
        |--------------------------------------------------------------------------
        */

        const quantityElement =
            item.querySelector(
                '[data-cart-quantity]'
            );

        if (quantityElement) {
            quantityElement.textContent =
                data.quantity;
        }

        /*
        |--------------------------------------------------------------------------
        | Line Total
        |--------------------------------------------------------------------------
        */

        const lineTotalElement =
            item.querySelector(
                '[data-cart-line-total]'
            );

        if (lineTotalElement) {

            lineTotalElement.textContent =
                formatCurrency(
                    data.line_total
                );
        }

        /*
        |--------------------------------------------------------------------------
        | Buttons
        |--------------------------------------------------------------------------
        */

        const decreaseButton =
            item.querySelector(
                '[data-cart-action="decrease"]'
            );

        if (decreaseButton) {
            decreaseButton.disabled =
                parseInt(data.quantity, 10) <= 1;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Remove Cart Item
    |--------------------------------------------------------------------------
    */

    async function removeCartItem(
        productId,
        element = null
    ) {

        productId =
            parseInt(
                productId,
                10
            );

        if (
            !productId ||
            productId <= 0
        ) {
            return;
        }

        if (element) {
            element.disabled =
                true;
        }

        const formData =
            new FormData();

        formData.append(
            'product_id',
            String(productId)
        );

        const csrfToken =
            getCsrfToken();

        if (csrfToken) {
            formData.append(
                'csrf_token',
                csrfToken
            );
        }

        try {

            const data =
                await request(
                    ENDPOINTS.cartRemove,
                    {
                        method: 'POST',
                        body: formData
                    }
                );

            state.cartCount =
                parseInt(
                    data.cart_count || 0,
                    10
                );

            state.cartTotal =
                parseFloat(
                    data.cart_total || 0
                );

            updateCartCountBadges();

            updateCartTotalUI(
                data.cart_total
            );

            /*
            |--------------------------------------------------------------------------
            | Remove Card
            |--------------------------------------------------------------------------
            */

            const item =
                document.querySelector(
                    `[data-cart-product-id="${CSS.escape(String(productId))}"]`
                );

            if (item) {

                item.classList.add(
                    'cart-item-removing'
                );

                setTimeout(() => {

                    item.remove();

                    checkEmptyCart();

                }, 250);
            }

            showToast(
                'Item removed from your cart.',
                'success'
            );

        } catch (error) {

            if (element) {
                element.disabled =
                    false;
            }

            showError(
                error.message
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Check Empty Cart
    |--------------------------------------------------------------------------
    */

    function checkEmptyCart() {

        const content =
            getContent();

        if (!content) {
            return;
        }

        const items =
            $$('.customer-cart-item', content);

        if (
            items.length === 0
        ) {

            content.innerHTML = `
                <div class="account-empty-state">

                    <div class="account-empty-icon">
                        🛒
                    </div>

                    <h3>
                        Your cart is empty
                    </h3>

                    <p>
                        Add something beautiful
                        to your cart.
                    </p>

                    <button
                        type="button"
                        class="account-primary-button"
                        data-account-action="shop"
                    >
                        Continue Shopping
                    </button>

                </div>
            `;

            bindContentEvents();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Update Cart Total
    |--------------------------------------------------------------------------
    */

    function updateCartTotalUI(
        total
    ) {

        const formatted =
            formatCurrency(
                total
            );

        $$(
            '[data-cart-total]'
        ).forEach(element => {

            element.textContent =
                formatted;

        });
    }

    /*
    |--------------------------------------------------------------------------
    | Format Currency
    |--------------------------------------------------------------------------
    */

    function formatCurrency(
        amount
    ) {

        const number =
            parseFloat(
                amount || 0
            );

        return (
            'R ' +
            number.toLocaleString(
                'en-ZA',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Profile / Address Form
    |--------------------------------------------------------------------------
    */

    async function submitProfile(
        form
    ) {

        const submitButton =
            form.querySelector(
                '[type="submit"]'
            );

        setButtonLoading(
            submitButton,
            true,
            'Saving...'
        );

        try {

            const data =
                await request(
                    ENDPOINTS.profile,
                    {
                        method: 'POST',
                        body:
                            createFormData(form)
                    }
                );

            showToast(
                data.message ||
                'Your details were saved.',
                'success'
            );

            /*
            |--------------------------------------------------------------------------
            | Refresh Section
            |--------------------------------------------------------------------------
            */

            setTimeout(() => {

                loadCustomerAccountSection(
                    state.currentSection
                );

            }, 400);

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setButtonLoading(
                submitButton,
                false
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Password Form
    |--------------------------------------------------------------------------
    */

    async function submitPassword(
        form
    ) {

        const submitButton =
            form.querySelector(
                '[type="submit"]'
            );

        setButtonLoading(
            submitButton,
            true,
            'Updating...'
        );

        try {

            const data =
                await request(
                    ENDPOINTS.password,
                    {
                        method: 'POST',
                        body:
                            createFormData(form)
                    }
                );

            form.reset();

            showToast(
                data.message ||
                'Password changed successfully.',
                'success'
            );

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setButtonLoading(
                submitButton,
                false
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Email Change - Request OTP
    |--------------------------------------------------------------------------
    */

    async function submitEmailChangeRequest(
        form
    ) {

        const submitButton =
            form.querySelector('[type="submit"]');

        setButtonLoading(
            submitButton,
            true,
            'Sending...'
        );

        try {

            const data =
                await request(
                    ENDPOINTS.sendEmailChangeOtp,
                    {
                        method: 'POST',
                        body: createFormData(form)
                    }
                );

            showToast(
                data.message ||
                'Verification code sent to the new email address.',
                'success'
            );

            const verifyForm =
                document.querySelector(
                    '#emailChangeVerifyForm'
                );

            if (verifyForm) {
                verifyForm.hidden = false;

                const codeInput =
                    verifyForm.querySelector(
                        'input[name="otp"]'
                    );

                if (codeInput) {
                    codeInput.focus();
                }
            }

            startEmailChangeCountdown(60);

        } catch (error) {

            showError(error.message);

        } finally {

            setButtonLoading(
                submitButton,
                false
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Email Change - Verify OTP
    |--------------------------------------------------------------------------
    */

    async function submitEmailChangeVerification(
        form
    ) {

        const submitButton =
            form.querySelector('[type="submit"]');

        setButtonLoading(
            submitButton,
            true,
            'Verifying...'
        );

        try {

            const data =
                await request(
                    ENDPOINTS.verifyEmailChangeOtp,
                    {
                        method: 'POST',
                        body: createFormData(form)
                    }
                );

            showToast(
                data.message ||
                'Your email address has been changed successfully.',
                'success'
            );

            setTimeout(() => {
                loadCustomerAccountSection('settings');
            }, 500);

        } catch (error) {

            showError(error.message);

        } finally {

            setButtonLoading(
                submitButton,
                false
            );
        }
    }


    let emailChangeTimer = null;

    function startEmailChangeCountdown(
        seconds
    ) {

        const button =
            document.querySelector(
                '[data-email-change-send]'
            );

        if (!button) {
            return;
        }

        if (emailChangeTimer) {
            clearInterval(emailChangeTimer);
        }

        let remaining = parseInt(seconds, 10);

        button.disabled = true;

        const originalText =
            button.dataset.originalText ||
            'Send Verification Code';

        button.dataset.originalText = originalText;

        const update = () => {

            if (remaining <= 0) {

                clearInterval(emailChangeTimer);
                emailChangeTimer = null;

                button.disabled = false;
                button.textContent = originalText;

                return;
            }

            button.textContent =
                `Resend Code (${remaining}s)`;

            remaining--;
        };

        update();

        emailChangeTimer =
            setInterval(update, 1000);
    }


    /*
    |--------------------------------------------------------------------------
    | Send OTP
    |--------------------------------------------------------------------------
    */

    async function sendOTP(
        button = null
    ) {

        if (button) {

            setButtonLoading(
                button,
                true,
                'Sending...'
            );
        }

        const formData =
            new FormData();

        const csrfToken =
            getCsrfToken();

        if (csrfToken) {
            formData.append(
                'csrf_token',
                csrfToken
            );
        }

        try {

            const data =
                await request(
                    ENDPOINTS.sendOtp,
                    {
                        method: 'POST',
                        body: formData
                    }
                );

            showToast(
                data.message ||
                'Verification code sent.',
                'success'
            );

            /*
            |--------------------------------------------------------------------------
            | Start Countdown
            |--------------------------------------------------------------------------
            */

            startOTPCountdown(
                60
            );

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            if (button) {

                setButtonLoading(
                    button,
                    false
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | OTP Countdown
    |--------------------------------------------------------------------------
    */

    let otpTimer = null;

    function startOTPCountdown(
        seconds
    ) {

        const button =
            document.querySelector(
                '[data-account-action="send-otp"]'
            );

        if (!button) {
            return;
        }

        if (otpTimer) {
            clearInterval(
                otpTimer
            );
        }

        let remaining =
            parseInt(
                seconds,
                10
            );

        button.disabled =
            true;

        const originalText =
            button.dataset.originalText ||
            'Send Verification Code';

        button.dataset.originalText =
            originalText;

        const update =
            () => {

                if (
                    remaining <= 0
                ) {

                    clearInterval(
                        otpTimer
                    );

                    otpTimer =
                        null;

                    button.disabled =
                        false;

                    button.textContent =
                        originalText;

                    return;
                }

                button.textContent =
                    `Resend Code (${remaining}s)`;

                remaining--;
            };

        update();

        otpTimer =
            setInterval(
                update,
                1000
            );
    }

    /*
    |--------------------------------------------------------------------------
    | Verify OTP
    |--------------------------------------------------------------------------
    */

    async function verifyOTP(
        form
    ) {

        const submitButton =
            form.querySelector(
                '[type="submit"]'
            );

        setButtonLoading(
            submitButton,
            true,
            'Verifying...'
        );

        try {

            const data =
                await request(
                    ENDPOINTS.verifyOtp,
                    {
                        method: 'POST',
                        body:
                            createFormData(form)
                    }
                );

            showToast(
                data.message ||
                'Your email has been verified.',
                'success'
            );

            setTimeout(() => {

                loadCustomerAccountSection(
                    'verification'
                );

            }, 500);

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            setButtonLoading(
                submitButton,
                false
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Logout
    |--------------------------------------------------------------------------
    */

    async function logout(
        button = null
    ) {

        if (
            !window.confirm(
                'Are you sure you want to log out?'
            )
        ) {
            return;
        }

        if (button) {

            setButtonLoading(
                button,
                true,
                'Logging out...'
            );
        }

        const formData =
            new FormData();

        const csrfToken =
            getCsrfToken();

        if (csrfToken) {
            formData.append(
                'csrf_token',
                csrfToken
            );
        }

        try {

            const data =
                await request(
                    ENDPOINTS.logout,
                    {
                        method: 'POST',
                        body: formData
                    }
                );

            showToast(
                data.message ||
                'You have been logged out.',
                'success'
            );

            /*
            |--------------------------------------------------------------------------
            | Close Drawer
            |--------------------------------------------------------------------------
            */

            closeDrawer();

            /*
            |--------------------------------------------------------------------------
            | Update Account UI
            |--------------------------------------------------------------------------
            */

            updateLoggedOutUI();

            /*
            |--------------------------------------------------------------------------
            | Refresh Page
            |--------------------------------------------------------------------------
            */

            setTimeout(() => {

                window.location.reload();

            }, 700);

        } catch (error) {

            showError(
                error.message
            );

        } finally {

            if (button) {

                setButtonLoading(
                    button,
                    false
                );
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Logged Out UI
    |--------------------------------------------------------------------------
    */

    function updateLoggedOutUI() {

        $$(
            '[data-customer-account]'
        ).forEach(element => {

            element.classList.remove(
                'customer-logged-in'
            );

        });
    }

    /*
    |--------------------------------------------------------------------------
    | Update Account Counts
    |--------------------------------------------------------------------------
    */

    function updateAccountCounts() {

        updateCartCountBadges();

        /*
        |--------------------------------------------------------------------------
        | Count elements already present
        |--------------------------------------------------------------------------
        */

        const cartItems =
            $$('.customer-cart-item');

        if (
            cartItems.length
        ) {

            let count = 0;

            cartItems.forEach(item => {

                const quantity =
                    parseInt(
                        item.querySelector(
                            '[data-cart-quantity]'
                        )?.textContent || 0,
                        10
                    );

                count +=
                    Number.isNaN(quantity)
                        ? 0
                        : quantity;
            });

            state.cartCount =
                count;

            updateCartCountBadges();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Cart Count Badges
    |--------------------------------------------------------------------------
    */

    function updateCartCountBadges() {

        $$(
            '[data-cart-count]'
        ).forEach(element => {

            element.textContent =
                state.cartCount;

            element.classList.toggle(
                'has-items',
                state.cartCount > 0
            );
        });

        $$(
            '.cart-count'
        ).forEach(element => {

            element.textContent =
                state.cartCount;

        });
    }

    /*
    |--------------------------------------------------------------------------
    | Button Loading
    |--------------------------------------------------------------------------
    */

    function setButtonLoading(
        button,
        loading,
        loadingText = 'Loading...'
    ) {

        if (!button) {
            return;
        }

        if (loading) {

            if (
                !button.dataset.originalText
            ) {

                button.dataset.originalText =
                    button.textContent;
            }

            button.disabled =
                true;

            button.classList.add(
                'is-loading'
            );

            button.innerHTML = `
                <span class="button-spinner"></span>
                ${escapeHTML(
                    loadingText
                )}
            `;

        } else {

            button.disabled =
                false;

            button.classList.remove(
                'is-loading'
            );

            if (
                button.dataset.originalText
            ) {

                button.textContent =
                    button.dataset.originalText;

            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Toast Notifications
    |--------------------------------------------------------------------------
    */

    function showToast(
        message,
        type = 'info'
    ) {

        if (!message) {
            return;
        }

        let container =
            document.querySelector(
                '#customerAccountToastContainer'
            );

        if (!container) {

            container =
                document.createElement(
                    'div'
                );

            container.id =
                'customerAccountToastContainer';

            container.className =
                'customer-account-toast-container';

            document.body.appendChild(
                container
            );
        }

        const toast =
            document.createElement(
                'div'
            );

        toast.className =
            `customer-account-toast customer-account-toast-${type}`;

        toast.setAttribute(
            'role',
            'status'
        );

        toast.innerHTML = `
            <span class="toast-message">
                ${escapeHTML(message)}
            </span>

            <button
                type="button"
                class="toast-close"
                aria-label="Close notification"
            >
                ×
            </button>
        `;

        container.appendChild(
            toast
        );

        requestAnimationFrame(() => {

            toast.classList.add(
                'is-visible'
            );

        });

        const close =
            () => {

                toast.classList.remove(
                    'is-visible'
                );

                setTimeout(() => {

                    toast.remove();

                }, 250);
            };

        toast.querySelector(
            '.toast-close'
        )?.addEventListener(
            'click',
            close
        );

        setTimeout(
            close,
            4500
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Error Notification
    |--------------------------------------------------------------------------
    */

    function showError(
        message
    ) {

        showToast(
            message ||
            'Something went wrong.',
            'error'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Bind Drawer Events
    |--------------------------------------------------------------------------
    */

    function bindDrawerEvents() {

        const overlay =
            getOverlay();

        const close =
            $('[data-close-customer-account], #customerAccountClose');

        const back =
            $('[data-account-back], #customerAccountBack');

        if (overlay) {

            overlay.addEventListener(
                'click',
                closeDrawer
            );
        }

        if (close) {

            close.addEventListener(
                'click',
                closeDrawer
            );
        }

        if (back) {

            back.addEventListener(
                'click',
                handleBack
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Back Navigation
    |--------------------------------------------------------------------------
    */

    function handleBack() {

        if (
            state.currentOrderId &&
            state.previousSection ===
                'orders'
        ) {

            loadOrders();

            return;
        }

        if (
            state.previousSection
        ) {

            loadCustomerAccountSection(
                state.previousSection
            );

            return;
        }

        loadCustomerAccountSection(
            'profile'
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Bind Content Events
    |--------------------------------------------------------------------------
    */

    function bindContentEvents() {

        const content =
            getContent();

        if (!content) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Account Navigation
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-account-section]',
            content
        ).forEach(button => {

            button.addEventListener(
                'click',
                () => {

                    const section =
                        button.dataset.accountSection;

                    if (section) {

                        if (
                            section ===
                            'orders'
                        ) {

                            loadOrders();

                        } else {

                            loadCustomerAccountSection(
                                section
                            );
                        }
                    }
                }
            );
        });

        /*
        |--------------------------------------------------------------------------
        | Generic Account Actions
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-account-action]',
            content
        ).forEach(element => {

            element.addEventListener(
                'click',
                handleAccountAction
            );
        });

        /*
        |--------------------------------------------------------------------------
        | Forms
        |--------------------------------------------------------------------------
        */

        $$(
            'form',
            content
        ).forEach(form => {

            const action =
                form.dataset.accountForm;

            if (
                action ===
                'profile'
            ) {

                form.addEventListener(
                    'submit',
                    event => {

                        event.preventDefault();

                        submitProfile(
                            form
                        );
                    }
                );
            }

            if (
                action ===
                'email-change-request'
            ) {

                form.addEventListener(
                    'submit',
                    event => {

                        event.preventDefault();

                        submitEmailChangeRequest(
                            form
                        );
                    }
                );
            }

            if (
                action ===
                'email-change-verify'
            ) {

                form.addEventListener(
                    'submit',
                    event => {

                        event.preventDefault();

                        submitEmailChangeVerification(
                            form
                        );
                    }
                );
            }

            if (
                action ===
                'password'
            ) {

                form.addEventListener(
                    'submit',
                    event => {

                        event.preventDefault();

                        submitPassword(
                            form
                        );
                    }
                );
            }

            if (
                action ===
                'verify-otp'
            ) {

                form.addEventListener(
                    'submit',
                    event => {

                        event.preventDefault();

                        verifyOTP(
                            form
                        );
                    }
                );
            }
        });

        /*
        |--------------------------------------------------------------------------
        | OTP Send
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-account-action="send-otp"]',
            content
        ).forEach(button => {

            button.addEventListener(
                'click',
                () => {

                    sendOTP(
                        button
                    );
                }
            );
        });

        /*
        |--------------------------------------------------------------------------
        | Cart Quantity Controls
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-cart-action]',
            content
        ).forEach(button => {

            const action =
                button.dataset.cartAction;

            if (
                action ===
                'increase' ||
                action ===
                'decrease'
            ) {

                button.addEventListener(
                    'click',
                    () => {

                        handleCartQuantity(
                            button,
                            action
                        );
                    }
                );
            }

        });

        /*
        |--------------------------------------------------------------------------
        | Cart Remove
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-cart-action="remove"]',
            content
        ).forEach(button => {

            button.addEventListener(
                'click',
                () => {

                    const productId =
                        button.dataset.productId;

                    removeCartItem(
                        productId,
                        button
                    );
                }
            );
        });

        /*
        |--------------------------------------------------------------------------
        | Order Status Filter
        |--------------------------------------------------------------------------
        */

        const statusFilter =
            $(
                '#ordersStatusFilter',
                content
            );

        if (statusFilter) {

            statusFilter.addEventListener(
                'change',
                () => {

                    loadOrders(
                        1,
                        statusFilter.value
                    );
                }
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Order Pagination
        |--------------------------------------------------------------------------
        */

        $$(
            '[data-orders-page]',
            content
        ).forEach(button => {

            button.addEventListener(
                'click',
                () => {

                    const page =
                        parseInt(
                            button.dataset.ordersPage,
                            10
                        ) || 1;

                    const filter =
                        $(
                            '#ordersStatusFilter',
                            content
                        )?.value || '';

                    loadOrders(
                        page,
                        filter
                    );
                }
            );
        });

        /*
        |--------------------------------------------------------------------------
        | OTP Input
        |--------------------------------------------------------------------------
        */

        const otpInput =
            $(
                'input[name="otp"]',
                content
            );

        if (otpInput) {

            otpInput.addEventListener(
                'input',
                () => {

                    otpInput.value =
                        otpInput.value
                            .replace(
                                /\D/g,
                                ''
                            )
                            .slice(
                                0,
                                6
                            );
                }
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Handle Account Action
    |--------------------------------------------------------------------------
    */

    function handleAccountAction(
        event
    ) {

        const element =
            event.currentTarget;

        const action =
            element.dataset.accountAction;

        switch (action) {

            case 'orders':
                loadOrders();
                break;

            case 'profile':
                loadCustomerAccountSection(
                    'profile'
                );
                break;

            case 'cart':
                loadCustomerAccountSection(
                    'cart'
                );
                break;

            case 'address':
                loadCustomerAccountSection(
                    'address'
                );
                break;

            case 'password':
                loadCustomerAccountSection(
                    'password'
                );
                break;

            case 'verification':
                loadCustomerAccountSection(
                    'verification'
                );
                break;

            case 'order-details':
                loadOrderDetails(
                    element.dataset.orderId
                );
                break;

            case 'back-orders':
                loadOrders();
                break;

            case 'logout':
                logout(element);
                break;

            case 'shop':

                closeDrawer();

                /*
                |--------------------------------------------------------------------------
                | Scroll to Products
                |--------------------------------------------------------------------------
                */

                const products =
                    document.querySelector(
                        '#products, .products-section, .featured-products'
                    );

                if (products) {

                    products.scrollIntoView({
                        behavior: 'smooth'
                    });

                }

                break;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Cart Quantity Handler
    |--------------------------------------------------------------------------
    */

    function handleCartQuantity(
        button,
        action
    ) {

        const productId =
            button.dataset.productId;

        const item =
            button.closest(
                '[data-cart-product-id]'
            );

        if (!item) {
            return;
        }

        const quantityElement =
            item.querySelector(
                '[data-cart-quantity]'
            );

        let quantity =
            parseInt(
                quantityElement?.textContent ||
                item.dataset.quantity ||
                1,
                10
            );

        if (
            Number.isNaN(quantity)
        ) {
            quantity = 1;
        }

        if (
            action ===
            'increase'
        ) {
            quantity++;
        }

        if (
            action ===
            'decrease'
        ) {
            quantity--;
        }

        if (quantity < 1) {
            quantity = 1;
        }

        updateCartQuantity(
            productId,
            quantity
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Keyboard Accessibility
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'keydown',
        event => {

            if (
                event.key ===
                'Escape' &&
                state.drawerOpen
            ) {

                closeDrawer();
            }
        }
    );

    /*
    |--------------------------------------------------------------------------
    | Account Trigger Detection
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'click',
        event => {

            const trigger =
                event.target.closest(
                    '[data-open-customer-account]'
                );

            if (!trigger) {
                return;
            }

            event.preventDefault();

            const section =
                trigger.dataset.accountSection ||
                'profile';

            openDrawer(
                section
            );
        }
    );

    /*
    |--------------------------------------------------------------------------
    | Public API
    |--------------------------------------------------------------------------
    */

    window.openCustomerAccount =
        openDrawer;

    window.closeCustomerAccount =
        closeDrawer;

    window.loadCustomerAccountSection =
        loadCustomerAccountSection;

    window.loadCustomerOrders =
        loadOrders;

    window.openCustomerOrder =
        loadOrderDetails;

    window.updateCustomerCart =
        updateCartQuantity;

    window.removeCustomerCartItem =
        removeCartItem;

    window.sendCustomerOTP =
        sendOTP;

    /*
    |--------------------------------------------------------------------------
    | Initialise
    |--------------------------------------------------------------------------
    */

    document.addEventListener(
        'DOMContentLoaded',
        () => {

            /*
            |--------------------------------------------------------------------------
            | Bind existing drawer
            |--------------------------------------------------------------------------
            */

            if (
                getDrawer()
            ) {
                bindDrawerEvents();
            }

            /*
            |--------------------------------------------------------------------------
            | Existing Account Button
            |--------------------------------------------------------------------------
            */

            $$(
                '[data-open-customer-account]'
            ).forEach(trigger => {

                trigger.setAttribute(
                    'aria-haspopup',
                    'dialog'
                );
            });

        }
    );

})();
