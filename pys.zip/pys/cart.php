<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/init.php';

$page_title = 'Cart - ' . APP_NAME;

$cart = $_SESSION['cart'] ?? [];


/*
|--------------------------------------------------------------------------
| Update Cart
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    foreach ($_POST['qty'] ?? [] as $id => $qty) {

        $id  = (int) $id;
        $qty = max(0, (int) $qty);

        if ($qty === 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id] = $qty;
        }
    }

    redirect('cart.php');
}


/*
|--------------------------------------------------------------------------
| Load Header
|--------------------------------------------------------------------------
*/

include __DIR__ . '/includes/header.php';

?>

<style>

/* =========================================================
   CART PAGE
========================================================= */

.cart-page {
    padding: 45px 0 70px;
}

.cart-header {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 30px;
}

.cart-header h1 {
    margin: 0 0 7px;
    font-size: clamp(30px, 4vw, 44px);
    line-height: 1.1;
    font-weight: 800;
}

.cart-header p {
    margin: 0;
    color: #777;
}


/* =========================================================
   CART LAYOUT
========================================================= */

.cart-layout {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 340px;
    gap: 25px;
    align-items: start;
}


/* =========================================================
   CART ITEMS
========================================================= */

.cart-items {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.cart-item {
    display: grid;
    grid-template-columns: 105px minmax(0, 1fr) auto;
    gap: 18px;
    align-items: center;
    padding: 16px;
    background: #fff;
    border: 1px solid #e8e4dc;
    border-radius: 14px;
    transition: box-shadow .2s ease, transform .2s ease;
}

.cart-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, .06);
}

.cart-item-image {
    width: 105px;
    height: 105px;
    object-fit: cover;
    border-radius: 10px;
    display: block;
    background: #f2f0eb;
}

.cart-item-details {
    min-width: 0;
}

.cart-item-category {
    color: #918778;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
    margin-bottom: 5px;
}

.cart-item-name {
    margin: 0 0 6px;
    font-size: 17px;
    font-weight: 750;
    line-height: 1.3;
}

.cart-item-price {
    color: #555;
    font-size: 14px;
}

.cart-item-price strong {
    color: #171717;
}


/* =========================================================
   QUANTITY
========================================================= */

.cart-item-controls {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 12px;
}

.quantity-box {
    display: flex;
    align-items: center;
    gap: 8px;
}

.quantity-box label {
    font-size: 11px;
    color: #777;
    font-weight: 600;
}

.quantity-input {
    width: 72px;
    height: 38px;
    padding: 0 8px;
    text-align: center;
    border: 1px solid #dcd6cc;
    border-radius: 8px;
    outline: none;
    background: #fff;
}

.quantity-input:focus {
    border-color: #999;
}

.stock-text {
    color: #888;
    font-size: 11px;
}


/* =========================================================
   ITEM TOTAL
========================================================= */

.cart-item-total {
    text-align: right;
    min-width: 110px;
}

.cart-item-total small {
    display: block;
    color: #888;
    font-size: 11px;
    margin-bottom: 3px;
}

.cart-item-total strong {
    font-size: 17px;
}


/* =========================================================
   ORDER SUMMARY
========================================================= */

.cart-summary {
    position: sticky;
    top: 20px;
    background: #fff;
    border: 1px solid #e5dfd4;
    border-radius: 15px;
    padding: 24px;
}

.cart-summary h3 {
    margin: 0 0 20px;
    font-size: 21px;
    font-weight: 800;
}

.summary-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 10px 0;
    color: #555;
    font-size: 14px;
}

.summary-row.total {
    border-top: 1px solid #e6e1d8;
    margin-top: 8px;
    padding-top: 18px;
    color: #171717;
}

.summary-row.total span {
    font-size: 16px;
    font-weight: 700;
}

.summary-row.total strong {
    font-size: 24px;
    font-weight: 800;
}


/* =========================================================
   CHECKOUT BUTTON
========================================================= */

.checkout-button {
    width: 100%;
    min-height: 50px;
    margin-top: 18px;
    border: 0;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #171717;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    font-weight: 700;
    transition: .2s ease;
}

.checkout-button:hover {
    background: #333;
    color: #fff;
    transform: translateY(-1px);
}

.update-button {
    width: 100%;
    min-height: 44px;
    margin-top: 10px;
    border: 1px solid #d8d2c8;
    border-radius: 9px;
    background: #fff;
    color: #222;
    font-weight: 650;
    cursor: pointer;
    transition: .2s ease;
}

.update-button:hover {
    background: #f5f2ec;
}

.continue-shopping {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 43px;
    padding: 0 17px;
    border: 1px solid #d8d2c8;
    border-radius: 9px;
    color: #222;
    background: #fff;
    text-decoration: none;
    font-size: 13px;
    font-weight: 650;
    transition: .2s ease;
}

.continue-shopping:hover {
    background: #f5f2ec;
    color: #222;
}


/* =========================================================
   SUMMARY NOTE
========================================================= */

.cart-note {
    display: flex;
    gap: 9px;
    margin-top: 18px;
    padding-top: 17px;
    border-top: 1px solid #eee9e0;
    color: #777;
    font-size: 12px;
    line-height: 1.5;
}

.cart-note span {
    font-size: 16px;
}


/* =========================================================
   EMPTY CART
========================================================= */

.empty-cart {
    max-width: 620px;
    margin: 30px auto 0;
    padding: 60px 25px;
    text-align: center;
    background: #fff;
    border: 1px solid #e8e4dc;
    border-radius: 16px;
}

.empty-cart-icon {
    width: 65px;
    height: 65px;
    margin: 0 auto 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: #f4f1eb;
    font-size: 28px;
}

.empty-cart h3 {
    margin: 0 0 8px;
    font-size: 24px;
}

.empty-cart p {
    margin: 0 0 22px;
    color: #777;
}

.browse-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 45px;
    padding: 0 20px;
    border-radius: 9px;
    background: #171717;
    color: #fff;
    text-decoration: none;
    font-weight: 700;
}

.browse-button:hover {
    background: #333;
    color: #fff;
}


/* =========================================================
   UNAVAILABLE
========================================================= */

.cart-warning {
    margin-top: 20px;
    padding: 15px 17px;
    border-radius: 10px;
    background: #fff8e6;
    border: 1px solid #f0d99a;
    color: #745b1a;
    font-size: 14px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .cart-layout {
        grid-template-columns: 1fr;
    }

    .cart-summary {
        position: static;
    }

}


@media (max-width: 650px) {

    .cart-page {
        padding: 25px 0 50px;
    }

    .cart-header {
        align-items: flex-start;
        flex-direction: column;
        margin-bottom: 22px;
    }

    .cart-header .continue-shopping {
        width: 100%;
    }

    .cart-item {
        grid-template-columns: 80px minmax(0, 1fr);
        gap: 12px;
        padding: 12px;
    }

    .cart-item-image {
        width: 80px;
        height: 80px;
    }

    .cart-item-name {
        font-size: 14px;
    }

    .cart-item-price {
        font-size: 12px;
    }

    .cart-item-controls {
        grid-column: 1 / -1;
        display: grid;
        grid-template-columns: 1fr auto;
        align-items: center;
        gap: 10px;
        padding-top: 8px;
        border-top: 1px solid #eee9e0;
    }

    .quantity-box {
        justify-content: flex-start;
    }

    .cart-item-total {
        min-width: auto;
    }

    .cart-item-total small {
        display: none;
    }

    .cart-item-total strong {
        font-size: 15px;
    }

}


@media (max-width: 430px) {

    .cart-summary {
        padding: 18px;
    }

    .summary-row.total strong {
        font-size: 21px;
    }

}

</style>


<div class="container cart-page">


    <!-- =====================================================
         CART HEADER
    ====================================================== -->

    <div class="cart-header">

        <div>

            <h1>
                Your Cart
            </h1>

            <p>
                Review your selected furniture before checkout.
            </p>

        </div>


        <a
            href="<?= BASE_URL ?>/products.php"
            class="continue-shopping"
        >
            Continue Shopping
        </a>

    </div>


    <?php if (!$cart): ?>


        <!-- =================================================
             EMPTY CART
        ================================================== -->

        <div class="empty-cart">

            <div class="empty-cart-icon">
                🛒
            </div>

            <h3>
                Your cart is empty
            </h3>

            <p>
                You haven't added any furniture to your cart yet.
            </p>

            <a
                href="<?= BASE_URL ?>/products.php"
                class="browse-button"
            >
                Browse Products
            </a>

        </div>


    <?php else: ?>


        <form method="post">

            <?= csrf_field() ?>


            <?php

            $grand_total = 0;
            $valid_items = 0;

            ?>


            <div class="cart-layout">


                <!-- =================================================
                     CART ITEMS
                ================================================== -->

                <div class="cart-items">

                    <?php foreach ($cart as $id => $qty): ?>

                        <?php

                        $id  = (int) $id;
                        $qty = (int) $qty;

                        $stmt = $conn->prepare(
                            "SELECT *
                             FROM products
                             WHERE id = ?
                             AND status = 'active'"
                        );

                        if (!$stmt) {
                            continue;
                        }

                        $stmt->bind_param('i', $id);
                        $stmt->execute();

                        $p = $stmt
                            ->get_result()
                            ->fetch_assoc();

                        $stmt->close();


                        if (!$p) {
                            continue;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Stock
                        |--------------------------------------------------------------------------
                        */

                        $stock = max(
                            0,
                            (int) ($p['stock'] ?? 0)
                        );


                        if ($stock === 0) {
                            continue;
                        }


                        if ($qty > $stock) {

                            $qty = $stock;

                            $_SESSION['cart'][$id] = $qty;
                        }


                        if ($qty <= 0) {
                            continue;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Price
                        |--------------------------------------------------------------------------
                        */

                        $price = (float) $p['price'];

                        $total = $price * $qty;

                        $grand_total += $total;

                        $valid_items++;


                        /*
                        |--------------------------------------------------------------------------
                        | Image
                        |--------------------------------------------------------------------------
                        */

                        $image = !empty($p['image'])
                            ? BASE_URL . '/' . ltrim($p['image'], '/')
                            : 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=500&q=80';

                        ?>


                        <!-- =================================================
                             CART ITEM
                        ================================================== -->

                        <article class="cart-item">


                            <!-- PRODUCT IMAGE -->

                            <img
                                class="cart-item-image"
                                src="<?= e($image) ?>"
                                alt="<?= e($p['name']) ?>"
                                onerror="this.src='https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=500&q=80'"
                            >


                            <!-- PRODUCT DETAILS -->

                            <div class="cart-item-details">

                                <div class="cart-item-category">

                                    <?= e($p['category']) ?>

                                </div>


                                <h3 class="cart-item-name">

                                    <?= e($p['name']) ?>

                                </h3>


                                <div class="cart-item-price">

                                    Unit price:

                                    <strong>
                                        R <?= number_format($price, 2) ?>
                                    </strong>

                                </div>

                            </div>


                            <!-- CONTROLS / TOTAL -->

                            <div class="cart-item-controls">


                                <div class="quantity-box">

                                    <label
                                        for="qty-<?= $id ?>"
                                    >
                                        Qty
                                    </label>

                                    <input
                                        id="qty-<?= $id ?>"
                                        class="quantity-input"
                                        type="number"
                                        min="0"
                                        max="<?= $stock ?>"
                                        name="qty[<?= $id ?>]"
                                        value="<?= $qty ?>"
                                    >

                                </div>


                                <div class="stock-text">

                                    <?= $stock ?> available

                                </div>


                                <div class="cart-item-total">

                                    <small>
                                        Item total
                                    </small>

                                    <strong>
                                        R <?= number_format($total, 2) ?>
                                    </strong>

                                </div>

                            </div>

                        </article>


                    <?php endforeach; ?>


                    <?php if ($valid_items === 0): ?>

                        <div class="cart-warning">

                            The products currently in your cart are unavailable.

                            <a
                                href="<?= BASE_URL ?>/products.php"
                                class="alert-link"
                            >
                                Browse available products
                            </a>.

                        </div>

                    <?php endif; ?>


                </div>


                <?php if ($valid_items > 0): ?>


                    <!-- =================================================
                         ORDER SUMMARY
                    ================================================== -->

                    <aside class="cart-summary">

                        <h3>
                            Order Summary
                        </h3>


                        <div class="summary-row">

                            <span>
                                Items
                            </span>

                            <strong>
                                <?= $valid_items ?>
                            </strong>

                        </div>


                        <div class="summary-row">

                            <span>
                                Subtotal
                            </span>

                            <strong>
                                R <?= number_format($grand_total, 2) ?>
                            </strong>

                        </div>


                        <div class="summary-row">

                            <span>
                                Delivery
                            </span>

                            <strong>
                                Calculated at checkout
                            </strong>

                        </div>


                        <div class="summary-row total">

                            <span>
                                Total
                            </span>

                            <strong>
                                R <?= number_format($grand_total, 2) ?>
                            </strong>

                        </div>


                        <a
                            href="<?= BASE_URL ?>/checkout/index.php"
                            class="checkout-button"
                        >
                            Proceed to Checkout
                        </a>


                        <button
                            type="submit"
                            class="update-button"
                        >
                            Update Cart
                        </button>


                        <div class="cart-note">

                            <span>🔒</span>

                            <div>
                                Secure checkout and safe payment.
                                Need help? Contact PYS Furniture
                                for assistance.
                            </div>

                        </div>

                    </aside>


                <?php endif; ?>


            </div>


            <?php if ($valid_items > 0): ?>

                <div style="margin-top:20px;">

                    <a
                        href="<?= BASE_URL ?>/products.php"
                        class="continue-shopping"
                    >
                        ← Continue Shopping
                    </a>

                </div>

            <?php endif; ?>


        </form>


    <?php endif; ?>


</div>


<?php

include __DIR__ . '/includes/footer.php';

?>