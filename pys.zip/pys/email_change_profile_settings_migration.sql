-- Square Furniture Manufacture
-- Profile settings: email-change OTP support
-- Run once on an existing database.

ALTER TABLE auth_otps
    MODIFY purpose ENUM('login','email_verify','email_change')
    NOT NULL DEFAULT 'login';

CREATE INDEX idx_auth_otps_email_change
    ON auth_otps (user_id, purpose, created_at);
