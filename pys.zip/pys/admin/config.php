<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Application
|--------------------------------------------------------------------------
*/

define('APP_NAME', 'Square Furniture Manufacture');

/*
| Your XAMPP project is:
| C:\xampp\htdocs\pys\
|
| Therefore the website URL is:
| http://localhost/pys/
*/
define('BASE_URL', '/pys');

define('CURRENCY', 'ZAR');


/*
|--------------------------------------------------------------------------
| Database
|--------------------------------------------------------------------------
*/

define('DB_HOST', 'localhost');
define('DB_NAME', 'furniture_db');
define('DB_USER', 'root');
define('DB_PASS', '');


/*
|--------------------------------------------------------------------------
| Administrator
|--------------------------------------------------------------------------
*/

define('ADMIN_EMAIL', 'admin@squarefurniture.co.za');


/*
|--------------------------------------------------------------------------
| PayFast
|--------------------------------------------------------------------------
*/

define('PAYFAST_SANDBOX', true);

define(
    'PAYFAST_MERCHANT_ID',
    'YOUR_PAYFAST_MERCHANT_ID'
);

define(
    'PAYFAST_MERCHANT_KEY',
    'YOUR_PAYFAST_MERCHANT_KEY'
);

define(
    'PAYFAST_PASSPHRASE',
    'YOUR_PAYFAST_PASSPHRASE'
);


/*
|--------------------------------------------------------------------------
| Timezone
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Africa/Johannesburg');