<?php
require_once __DIR__ . '/header.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '' || mb_strlen($name) > 120) $errors[] = 'Enter a name (up to 120 characters).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $errors[] = 'Enter a valid email address.';
    if (strlen($password) < 12) $errors[] = 'Password must be at least 12 characters.';
    if ($password !== $confirm) $errors[] = 'The passwords do not match.';

    if (!$errors) {
        $check = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->bind_param('s', $email);
        $check->execute();
        if ($check->get_result()->fetch_assoc()) {
            $errors[] = 'An account with that email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $phone = '';
            $address = '';
            $role = 'admin';
            $isAdmin = 1;
            $verified = 1;
            $status = 'active';
            $insert = $conn->prepare('INSERT INTO users (name,email,phone,address,password,role,is_admin,email_verified,status) VALUES (?,?,?,?,?,?,?,?,?)');
            $insert->bind_param('ssssssiis', $name, $email, $phone, $address, $hash, $role, $isAdmin, $verified, $status);
            if ($insert->execute()) {
                $newId = (int)$conn->insert_id;
                log_activity($conn, (int)($_SESSION['user_id'] ?? 0), 'Created administrator account #' . $newId);
                flash('success', 'New administrator account created successfully.');
                redirect('users.php');
            }
            $errors[] = 'Could not create the administrator. Please try again.';
        }
    }
}

$users = $conn->query("SELECT id,name,email,role,status,last_login FROM users ORDER BY id DESC");
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0">Customers &amp; users</h1>
</div>
<?php foreach (flashes() as [$type, $message]): ?>
  <div class="alert alert-<?=e($type)?>"><?=e($message)?></div>
<?php endforeach; ?>
<div class="card border-0 shadow-sm mb-4"><div class="card-body p-4">
  <h2 class="h5 mb-3">Create a new administrator</h2>
  <p class="text-muted">This creates an active admin account. Use a unique email and a strong password of at least 12 characters.</p>
  <?php if ($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $error): ?><li><?=e($error)?></li><?php endforeach; ?></ul></div><?php endif; ?>
  <form method="post" autocomplete="off">
    <?=csrf_field()?>
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label" for="name">Full name</label><input class="form-control" id="name" name="name" maxlength="120" required value="<?=e($_POST['name'] ?? '')?>"></div>
      <div class="col-md-6"><label class="form-label" for="email">Email address</label><input class="form-control" id="email" name="email" type="email" maxlength="190" required value="<?=e($_POST['email'] ?? '')?>"></div>
      <div class="col-md-6"><label class="form-label" for="password">Password</label><input class="form-control" id="password" name="password" type="password" minlength="12" required autocomplete="new-password"></div>
      <div class="col-md-6"><label class="form-label" for="confirm_password">Confirm password</label><input class="form-control" id="confirm_password" name="confirm_password" type="password" minlength="12" required autocomplete="new-password"></div>
    </div>
    <button class="btn btn-dark mt-3" type="submit">Create administrator</button>
  </form>
</div></div>
<div class="card border-0 shadow-sm"><div class="card-body"><h2 class="h5 mb-3">All accounts</h2><div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last login</th></tr></thead><tbody>
<?php while ($u = $users->fetch_assoc()): ?><tr><td><?= (int)$u['id'] ?></td><td><?=e($u['name'])?></td><td><?=e($u['email'])?></td><td><?=e($u['role'])?></td><td><?=e($u['status'])?></td><td><?=e($u['last_login'] ?? '-')?></td></tr><?php endwhile; ?>
</tbody></table></div></div></div>
<?php include __DIR__ . '/footer.php'; ?>
