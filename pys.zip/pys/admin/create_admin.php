<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
*/

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}

/*
|--------------------------------------------------------------------------
| New administrator
|--------------------------------------------------------------------------
*/

$name = 'New Admin';
$email = 'bthirteennetworks97@gmail.com';
$phone = '0631110307';
$password = 'ChangeMe123!@';

/*
|--------------------------------------------------------------------------
| Check whether email already exists
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare(
    'SELECT id, role, status FROM users WHERE email = ? LIMIT 1'
);

$stmt->execute([$email]);

$existingUser = $stmt->fetch();

if ($existingUser) {
    die(
        '<h2>Account already exists</h2>' .
        '<p>Email: ' . htmlspecialchars($email) . '</p>' .
        '<p>User ID: ' . (int)$existingUser['id'] . '</p>' .
        '<p>Role: ' . htmlspecialchars($existingUser['role']) . '</p>' .
        '<p>Status: ' . htmlspecialchars($existingUser['status']) . '</p>'
    );
}

/*
|--------------------------------------------------------------------------
| Secure password hash
|--------------------------------------------------------------------------
*/

$passwordHash = password_hash($password, PASSWORD_DEFAULT);

/*
|--------------------------------------------------------------------------
| Create administrator
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    INSERT INTO users
    (
        name,
        email,
        phone,
        address,
        password,
        role,
        is_admin,
        email_verified,
        status
    )
    VALUES
    (
        :name,
        :email,
        :phone,
        :address,
        :password,
        'admin',
        1,
        1,
        'active'
    )
");

$stmt->execute([
    ':name'     => $name,
    ':email'    => $email,
    ':phone'    => $phone,
    ':address'  => '',
    ':password' => $passwordHash,
]);

echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<title>Admin Created</title>';
echo '</head>';
echo '<body>';

echo '<h2>Administrator created successfully</h2>';

echo '<p><strong>Email:</strong> '
    . htmlspecialchars($email)
    . '</p>';

echo '<p><strong>Password:</strong> '
    . htmlspecialchars($password)
    . '</p>';

echo '<p><strong>Role:</strong> Admin</p>';
echo '<p><strong>Status:</strong> Active</p>';

echo '<hr>';

echo '<p><strong>IMPORTANT:</strong> Delete this file immediately after creating the account.</p>';

echo '<p>';
echo '<a href="' . BASE_URL . '/admin/login.php">';
echo 'Go to Admin Login';
echo '</a>';
echo '</p>';

echo '</body>';
echo '</html>';