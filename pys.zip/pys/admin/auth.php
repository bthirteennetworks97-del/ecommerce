<?php
require_once __DIR__ . '/../includes/init.php';
if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    flash('danger', 'Please sign in with an administrator account.');
    redirect('login.php');
}
// Re-check the account on every admin request so a suspended/deleted admin loses access.
$adminCheckId=(int)$_SESSION['user_id'];
$adminCheck=$conn->prepare("SELECT id FROM users WHERE id=? AND role='admin' AND status='active' LIMIT 1");
$adminCheck->bind_param('i',$adminCheckId);$adminCheck->execute();
if(!$adminCheck->get_result()->fetch_assoc()){
    $_SESSION=[];
    if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}
    session_destroy();
    header('Location: login.php');exit;
}
