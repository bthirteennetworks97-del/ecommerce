ADMIN UPGRADE NOTES

- The hardcoded create_admin.php bootstrap script has been removed because it contained a fixed password and exposed credentials.
- Do not recreate a public admin-creation script. Create/promote an administrator through a controlled, local database operation and use a unique password.
- Admin routes now re-check that the signed-in account still exists, has role=admin, and is active.
- Admin profile and password pages are included. Password changes require the current password and a minimum 12-character password containing letters and numbers.
- Admin actions use the existing CSRF helpers and activity log.
- This project currently stores product categories as a fixed MySQL ENUM (Bedroom, Kitchen, Living Room, Outdoor). A fully dynamic category manager requires a planned schema migration and corresponding storefront/API changes; this upgrade does not silently alter that schema.
- Site-wide settings and OTP/email-management dashboards are not yet implemented; no settings/OTP schema was added without a migration plan.
- Before production deployment, change database credentials, configure HTTPS, set secure session cookies, and ensure backups exist.
