<?php
require_once 'auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('products.php');
verify_csrf();

$id = (int)($_POST['id'] ?? 0);
if ($id < 1) {
    flash('danger', 'Invalid product.');
    redirect('products.php');
}

$stmt = $conn->prepare('SELECT name, image FROM products WHERE id=? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
if (!$product) {
    flash('danger', 'Product not found.');
    redirect('products.php');
}

try {
    $stmt = $conn->prepare('DELETE FROM products WHERE id=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    if ($stmt->affected_rows < 1) throw new RuntimeException('Product could not be deleted.');

    if (!empty($product['image']) && $product['image'] !== 'uploads/products/default.jpg') {
        $path = __DIR__ . '/../' . $product['image'];
        if (is_file($path)) @unlink($path);
    }
    log_activity($conn, (int)$_SESSION['user_id'], 'Deleted product #' . $id . ': ' . $product['name']);
    flash('success', 'Product deleted successfully.');
} catch (Throwable $e) {
    // order_items references products, so products already used in orders may be protected by the FK.
    flash('danger', 'This product cannot be permanently deleted because it is linked to an existing order. Edit it and set its status to Inactive instead.');
}
redirect('products.php');
