<?php
require_once 'auth.php';

$categories = ['Bedroom', 'Kitchen', 'Living', 'Out-door', 'Dining', 'Office'];
$id = (int)($_GET['id'] ?? 0);
if ($id < 1) redirect('products.php');

$stmt = $conn->prepare('SELECT * FROM products WHERE id=? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
if (!$product) {
    flash('danger', 'Product not found.');
    redirect('products.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string)($_POST['name'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $category = trim((string)($_POST['category'] ?? ''));
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
    $image = $product['image'] ?: 'uploads/products/default.jpg';

    if ($name === '') $errors[] = 'Product name is required.';
    if (!in_array($category, $categories, true)) $errors[] = 'Please select a valid category.';
    if ($price < 0) $errors[] = 'Price cannot be negative.';
    if ($stock < 0) $errors[] = 'Stock cannot be negative.';

    if (isset($_FILES['image']) && ($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'The product image could not be uploaded.';
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $errors[] = 'Product images must be 5 MB or smaller.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['image']['tmp_name']);
            $allowed = ['image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp'];
            if (!isset($allowed[$mime])) {
                $errors[] = 'Only JPG, PNG and WEBP images are allowed.';
            } else {
                $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
                $uploadDir = __DIR__ . '/../uploads/products/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
                    $oldImage = $image;
                    $image = 'uploads/products/' . $filename;
                    if (!$errors && $oldImage !== 'uploads/products/default.jpg') {
                        $oldPath = __DIR__ . '/../' . $oldImage;
                        if (is_file($oldPath)) @unlink($oldPath);
                    }
                } else {
                    $errors[] = 'The product image could not be saved.';
                }
            }
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare('UPDATE products SET name=?, description=?, category=?, price=?, stock=?, image=?, status=? WHERE id=?');
        $stmt->bind_param('sssdissi', $name, $description, $category, $price, $stock, $image, $status, $id);
        $stmt->execute();
        log_activity($conn, (int)$_SESSION['user_id'], 'Updated product #' . $id . ': ' . $name);
        flash('success', 'Product updated successfully.');
        redirect('products.php');
    }

    $product = array_merge($product, compact('name', 'description', 'category', 'price', 'stock', 'image', 'status'));
}

include 'header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div><h1 class="mb-1">Edit Product #<?= (int)$product['id'] ?></h1><p class="text-muted mb-0">Update product information, pricing, stock or image.</p></div>
    <a href="products.php" class="btn btn-outline-secondary">← Back to Products</a>
</div>
<?php foreach ($errors as $error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endforeach; ?>
<div class="card shadow-sm border-0">
    <div class="card-body p-4">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="row g-4">
                <div class="col-md-8">
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Product name</label><input class="form-control" name="name" maxlength="180" required value="<?= e($product['name']) ?>"></div>
                        <div class="col-md-4"><label class="form-label">Price (R)</label><input class="form-control" name="price" type="number" min="0" step="0.01" required value="<?= e((string)$product['price']) ?>"></div>
                        <div class="col-md-4"><label class="form-label">Stock</label><input class="form-control" name="stock" type="number" min="0" required value="<?= e((string)$product['stock']) ?>"></div>
                        <div class="col-md-4"><label class="form-label">Category</label><select class="form-select" name="category" required><?php foreach($categories as $cat): ?><option value="<?= e($cat) ?>" <?= $product['category']===$cat?'selected':'' ?>><?= e($cat) ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="status"><option value="active" <?= $product['status']==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $product['status']==='inactive'?'selected':'' ?>>Inactive</option></select></div>
                        <div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="7"><?= e($product['description']) ?></textarea></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Current image</label>
                    <div class="border rounded p-2 mb-3 bg-light"><img src="../<?= e($product['image'] ?: 'uploads/products/default.jpg') ?>" class="img-fluid rounded" style="max-height:300px;width:100%;object-fit:contain" alt="<?= e($product['name']) ?>"></div>
                    <label class="form-label">Replace image</label>
                    <input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/webp">
                    <div class="form-text">JPG, PNG or WEBP · max 5 MB</div>
                </div>
                <div class="col-12"><button class="btn btn-dark px-4">Save Changes</button> <a href="products.php" class="btn btn-light">Cancel</a></div>
            </div>
        </form>
    </div>
</div>
<?php include 'footer.php'; ?>
