<?php
require_once 'auth.php';

$categories = ['Bedroom', 'Kitchen', 'Living', 'Out-door', 'Dining', 'Office'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim((string)($_POST['name'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $category = trim((string)($_POST['category'] ?? ''));
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';

    if ($name === '') $errors[] = 'Product name is required.';
    if (!in_array($category, $categories, true)) $errors[] = 'Please select a valid category.';
    if ($price < 0) $errors[] = 'Price cannot be negative.';
    if ($stock < 0) $errors[] = 'Stock cannot be negative.';

    $image = 'uploads/products/default.jpg';
    if (isset($_FILES['image']) && ($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'The product image could not be uploaded.';
        } elseif ($_FILES['image']['size'] > 5 * 1024 * 1024) {
            $errors[] = 'Product images must be 5 MB or smaller.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['image']['tmp_name']);
            $allowed = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'image/webp' => 'webp',
            ];
            if (!isset($allowed[$mime])) {
                $errors[] = 'Only JPG, PNG and WEBP images are allowed.';
            } else {
                $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
                $uploadDir = __DIR__ . '/../uploads/products/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
                    $image = 'uploads/products/' . $filename;
                } else {
                    $errors[] = 'The product image could not be saved.';
                }
            }
        }
    }

    if (!$errors) {
        $stmt = $conn->prepare('INSERT INTO products (name, description, category, price, stock, image, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssdiss', $name, $description, $category, $price, $stock, $image, $status);
        $stmt->execute();
        log_activity($conn, (int)$_SESSION['user_id'], 'Added product: ' . $name);
        flash('success', 'Product added successfully.');
        redirect('products.php');
    }
}

include 'header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h1 class="mb-1">Product Management</h1>
        <p class="text-muted mb-0">Add, edit, activate, deactivate and delete products.</p>
    </div>
    <a href="dashboard.php" class="btn btn-outline-secondary">← Dashboard</a>
</div>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endforeach; ?>
<?php foreach (flashes() as [$type, $message]): ?>
    <div class="alert alert-<?= e($type) ?>"><?= e($message) ?></div>
<?php endforeach; ?>

<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-white py-3"><strong>➕ Add New Product</strong></div>
    <div class="card-body">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-lg-5">
                    <label class="form-label">Product name</label>
                    <input class="form-control" name="name" maxlength="180" required value="<?= e($_POST['name'] ?? '') ?>">
                </div>
                <div class="col-lg-2">
                    <label class="form-label">Price (R)</label>
                    <input class="form-control" name="price" type="number" min="0" step="0.01" required value="<?= e($_POST['price'] ?? '') ?>">
                </div>
                <div class="col-lg-2">
                    <label class="form-label">Stock</label>
                    <input class="form-control" name="stock" type="number" min="0" required value="<?= e($_POST['stock'] ?? '0') ?>">
                </div>
                <div class="col-lg-3">
                    <label class="form-label">Category</label>
                    <select class="form-select" name="category" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= e($cat) ?>" <?= (($_POST['category'] ?? '') === $cat) ? 'selected' : '' ?>><?= e($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-lg-8">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="3" maxlength="5000"><?= e($_POST['description'] ?? '') ?></textarea>
                </div>
                <div class="col-lg-4">
                    <label class="form-label">Product image</label>
                    <input class="form-control" type="file" name="image" accept="image/jpeg,image/png,image/webp">
                    <div class="form-text">JPG, PNG or WEBP · max 5 MB</div>
                </div>
                <div class="col-lg-3">
                    <label class="form-label">Status</label>
                    <select class="form-select" name="status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                <div class="col-lg-9 d-flex align-items-end">
                    <button class="btn btn-dark px-4">Add Product</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <strong>All Products</strong>
        <span class="text-muted small">Admin only</span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>ID</th><th>Image</th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $r = $conn->query('SELECT * FROM products ORDER BY id DESC');
            while ($p = $r->fetch_assoc()):
                $image = $p['image'] ?: 'uploads/products/default.jpg';
            ?>
                <tr>
                    <td>#<?= (int)$p['id'] ?></td>
                    <td><img src="../<?= e($image) ?>" width="70" height="55" class="rounded" alt=""></td>
                    <td><strong><?= e($p['name']) ?></strong><div class="small text-muted text-truncate" style="max-width:260px"><?= e($p['description']) ?></div></td>
                    <td><?= e($p['category']) ?></td>
                    <td>R <?= number_format((float)$p['price'], 2) ?></td>
                    <td><?= (int)$p['stock'] ?></td>
                    <td>
                        <span class="badge <?= $p['status'] === 'active' ? 'text-bg-success' : 'text-bg-secondary' ?>">
                            <?= e(ucfirst($p['status'])) ?>
                        </span>
                    </td>
                    <td class="text-end">
                        <a class="btn btn-sm btn-outline-dark" href="product_edit.php?id=<?= (int)$p['id'] ?>">Edit</a>
                        <form method="post" action="product_delete.php" class="d-inline" onsubmit="return confirm('Delete this product permanently? If it has existing orders, the database may prevent deletion.');">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>
