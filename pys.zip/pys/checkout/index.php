<?php
include '../includes/header.php';
if(!isset($_SESSION['user_id'])){flash('warning','Please log in before checkout.');redirect('../auth/login.php');}
$total=cart_total($conn);if($total<=0){redirect('../cart.php');}
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$name=trim($_POST['full_name']);$phone=trim($_POST['phone']);$address=trim($_POST['address']);$city=trim($_POST['city']);$postal=trim($_POST['postal_code']);
$stmt=$conn->prepare("INSERT INTO orders(user_id,total,full_name,phone,address,city,postal_code,status) VALUES(?,?,?,?,?,?,?,'pending')");$uid=$_SESSION['user_id'];$stmt->bind_param('idsssss',$uid,$total,$name,$phone,$address,$city,$postal);$stmt->execute();$orderId=$stmt->insert_id;
foreach($_SESSION['cart'] as $id=>$qty){$s=$conn->prepare("SELECT price FROM products WHERE id=?");$s->bind_param('i',$id);$s->execute();$p=$s->get_result()->fetch_assoc();if($p){$s2=$conn->prepare("INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)");$s2->bind_param('iiid',$orderId,$id,$qty,$p['price']);$s2->execute();}}
$_SESSION['pending_order']=$orderId;redirect('../payment/payfast.php');}
?>
<main class="checkout-page">
  <div class="checkout-heading"><span class="checkout-eyebrow">SQUARE FURNITURE</span><h1>Checkout</h1><p>Almost there — confirm your delivery details to continue.</p></div>
  <div class="checkout-layout">
    <section class="checkout-panel checkout-form-panel"><div class="checkout-panel-title"><span class="checkout-step">1</span><div><h2>Delivery information</h2><p>Where should we deliver your order?</p></div></div>
      <form method="post" class="checkout-form"><?=csrf_field()?>
        <label for="full_name">Full name</label><input id="full_name" class="form-control" name="full_name" autocomplete="name" placeholder="Enter your full name" required>
        <label for="phone">Phone number</label><input id="phone" class="form-control" name="phone" type="tel" autocomplete="tel" placeholder="e.g. 082 123 4567" required>
        <label for="address">Delivery address</label><textarea id="address" class="form-control" name="address" autocomplete="street-address" rows="3" placeholder="Street address and area" required></textarea>
        <div class="checkout-fields"><div><label for="city">City</label><input id="city" class="form-control" name="city" autocomplete="address-level2" placeholder="City" required></div><div><label for="postal_code">Postal code</label><input id="postal_code" class="form-control" name="postal_code" autocomplete="postal-code" placeholder="Postal code" required></div></div>
        <button class="checkout-submit" type="submit">Continue to secure payment <span aria-hidden="true">→</span></button>
        <div class="checkout-secure"><span>🔒</span> Your details are submitted securely.</div>
      </form>
    </section>
    <aside class="checkout-panel checkout-summary"><div class="summary-title"><span>ORDER SUMMARY</span><span class="summary-bag">🛍</span></div><p class="summary-caption">Your purchase total</p><div class="summary-total">R <?=number_format($total,2)?></div><div class="summary-divider"></div><div class="summary-line"><span>Subtotal</span><strong>R <?=number_format($total,2)?></strong></div><div class="summary-line"><span>Delivery</span><span>Calculated if applicable</span></div><div class="summary-note">You'll proceed to our secure payment step after confirming your delivery information.</div><a class="back-to-cart" href="../cart.php">← Return to cart</a></aside>
  </div>
</main>
<?php include '../includes/footer.php'; ?>
