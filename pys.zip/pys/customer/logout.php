<?php
declare(strict_types=1);

/**
 * Square Furniture
 * Customer Logout Endpoint
 *
 * File:
 * /customer/logout.php
 *
 * Purpose:
 * - Securely logs out the current customer.
 * - Destroys the authentication session.
 * - Clears the session cookie.
 * - Returns JSON for AJAX requests.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json; charset=utf-8');


try {

    /* =========================================================
       REQUEST METHOD
    ========================================================= */

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

        http_response_code(405);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);

        exit;
    }


    /* =========================================================
       VERIFY CSRF TOKEN
    ========================================================= */

    if (function_exists('verify_csrf')) {

        verify_csrf();

    } else {

        /*
         * Fallback CSRF verification in case the existing
         * init.php does not provide verify_csrf().
         */

        $session_token =
            $_SESSION['csrf_token'] ?? '';

        $submitted_token =
            $_POST['csrf_token']
            ?? $_SERVER['HTTP_X_CSRF_TOKEN']
            ?? '';

        if (
            empty($session_token)
            || empty($submitted_token)
            || !hash_equals(
                (string) $session_token,
                (string) $submitted_token
            )
        ) {

            http_response_code(403);

            echo json_encode([
                'success' => false,
                'message' => 'Security verification failed.'
            ]);

            exit;
        }
    }


    /* =========================================================
       REMEMBER CURRENT USER FOR OPTIONAL LOGGING
    ========================================================= */

    $user_id =
        isset($_SESSION['user_id'])
            ? (int) $_SESSION['user_id']
            : 0;


    /* =========================================================
       OPTIONAL ACTIVITY LOG
       
       This does not prevent logout if the activity_logs
       table has a different structure.
    ========================================================= */

    if ($user_id > 0) {

        try {

            /*
             * Only attempt this if the table has the expected
             * basic structure.
             */
            $log_stmt = $conn->prepare(
                "INSERT INTO activity_logs
                    (user_id, action, created_at)
                 VALUES
                    (?, 'customer_logout', NOW())"
            );

            if ($log_stmt) {

                $log_stmt->bind_param(
                    'i',
                    $user_id
                );

                $log_stmt->execute();
                $log_stmt->close();
            }

        } catch (Throwable $log_error) {

            /*
             * Logging failure must never prevent logout.
             */
            error_log(
                'Customer logout activity log failed: '
                . $log_error->getMessage()
            );
        }
    }


    /* =========================================================
       CLEAR SESSION DATA
    ========================================================= */

    /*
     * Remove all session variables.
     */
    $_SESSION = [];


    /* =========================================================
       DESTROY SESSION COOKIE
    ========================================================= */

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            (bool) $params['secure'],
            (bool) $params['httponly']
        );
    }


    /* =========================================================
       DESTROY SESSION
    ========================================================= */

    session_destroy();


    /* =========================================================
       START A CLEAN SESSION
       
       This allows the homepage to continue using a fresh
       session for cart/CSRF functionality.
    ========================================================= */

    session_start();


    /*
     * Generate a fresh CSRF token.
     */
    $_SESSION['csrf_token'] =
        bin2hex(random_bytes(32));


    /* =========================================================
       RESPONSE
    ========================================================= */

    echo json_encode([

        'success' => true,

        'message' =>
            'You have been successfully signed out.',

        'logged_in' =>
            false,

        'redirect' =>
            BASE_URL . '/',

        'csrf_token' =>
            $_SESSION['csrf_token']

    ], JSON_UNESCAPED_SLASHES);


} catch (Throwable $e) {

    error_log(
        'Customer Logout Error: '
        . $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to sign you out right now.'
    ]);
}