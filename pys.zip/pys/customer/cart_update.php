<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Cart - Update Quantity
|--------------------------------------------------------------------------
| Location:
| C:\xampp\htdocs\pys\customer\cart_update.php
|
| Updates the quantity of one product in the current customer's cart.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';


/*
|--------------------------------------------------------------------------
| JSON Response
|--------------------------------------------------------------------------
*/

function cart_update_response(
    bool $success,
    string $message,
    int $statusCode = 200,
    array $extra = []
): never {

    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        ),
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    cart_update_response(
        false,
        'Please log in to manage your cart.',
        401
    );
}


/*
|--------------------------------------------------------------------------
| POST Only
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    cart_update_response(
        false,
        'Invalid request method.',
        405
    );
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    cart_update_response(
        false,
        'Your security token has expired. Please refresh the page and try again.',
        419
    );
}


/*
|--------------------------------------------------------------------------
| Product ID
|--------------------------------------------------------------------------
*/

$productId = filter_input(
    INPUT_POST,
    'product_id',
    FILTER_VALIDATE_INT
);


/*
|--------------------------------------------------------------------------
| Quantity
|--------------------------------------------------------------------------
*/

$quantity = filter_input(
    INPUT_POST,
    'quantity',
    FILTER_VALIDATE_INT
);


if (
    $productId === false ||
    $productId === null ||
    $productId < 1
) {

    cart_update_response(
        false,
        'Invalid product.',
        422
    );
}


if (
    $quantity === false ||
    $quantity === null
) {

    cart_update_response(
        false,
        'Invalid quantity.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Cart Initialization
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['cart']) ||
    !is_array($_SESSION['cart'])
) {

    $_SESSION['cart'] = [];
}


/*
|--------------------------------------------------------------------------
| Quantity Zero = Remove
|--------------------------------------------------------------------------
*/

if ($quantity <= 0) {

    unset(
        $_SESSION['cart'][$productId]
    );

    cart_update_response(
        true,
        'Product removed from your cart.',
        200,
        [
            'product_id' => $productId,
            'quantity' => 0
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Get Product And Stock
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        price,
        stock,
        status
    FROM products
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'i',
    $productId
);

$stmt->execute();

$product = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Product Not Found
|--------------------------------------------------------------------------
*/

if (!$product) {

    unset(
        $_SESSION['cart'][$productId]
    );

    cart_update_response(
        false,
        'This product no longer exists.',
        404
    );
}


/*
|--------------------------------------------------------------------------
| Product Status
|--------------------------------------------------------------------------
*/

if (($product['status'] ?? '') !== 'active') {

    unset(
        $_SESSION['cart'][$productId]
    );

    cart_update_response(
        false,
        'This product is no longer available.',
        409
    );
}


/*
|--------------------------------------------------------------------------
| Stock
|--------------------------------------------------------------------------
*/

$stock = max(
    0,
    (int) ($product['stock'] ?? 0)
);


if ($stock < 1) {

    unset(
        $_SESSION['cart'][$productId]
    );

    cart_update_response(
        false,
        'This product is currently out of stock.',
        409
    );
}


/*
|--------------------------------------------------------------------------
| Prevent Quantity Above Stock
|--------------------------------------------------------------------------
*/

if ($quantity > $stock) {

    $quantity = $stock;

    $message =
        'Only ' .
        $stock .
        ' item' .
        ($stock === 1 ? '' : 's') .
        ' available.';

} else {

    $message =
        'Cart quantity updated successfully.';
}


/*
|--------------------------------------------------------------------------
| Save Quantity
|--------------------------------------------------------------------------
*/

$_SESSION['cart'][$productId] = $quantity;


/*
|--------------------------------------------------------------------------
| Calculate Line Total
|--------------------------------------------------------------------------
*/

$price = (float) $product['price'];

$lineTotal = $price * $quantity;


/*
|--------------------------------------------------------------------------
| Calculate Entire Cart
|--------------------------------------------------------------------------
*/

$cartCount = 0;

$cartTotal = 0.00;

foreach ($_SESSION['cart'] as $id => $qty) {

    $id = (int) $id;
    $qty = (int) $qty;

    if ($id < 1 || $qty < 1) {
        continue;
    }

    $stmt = $conn->prepare("
        SELECT
            price,
            stock,
            status
        FROM products
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        'i',
        $id
    );

    $stmt->execute();

    $cartProduct = $stmt
        ->get_result()
        ->fetch_assoc();

    $stmt->close();

    if (!$cartProduct) {

        unset(
            $_SESSION['cart'][$id]
        );

        continue;
    }

    if (($cartProduct['status'] ?? '') !== 'active') {

        unset(
            $_SESSION['cart'][$id]
        );

        continue;
    }

    $availableStock = max(
        0,
        (int) ($cartProduct['stock'] ?? 0)
    );

    if ($availableStock < 1) {

        unset(
            $_SESSION['cart'][$id]
        );

        continue;
    }

    if ($qty > $availableStock) {

        $qty = $availableStock;

        $_SESSION['cart'][$id] = $qty;
    }

    $itemPrice = (float) $cartProduct['price'];

    $cartCount += $qty;

    $cartTotal += $itemPrice * $qty;
}


/*
|--------------------------------------------------------------------------
| Success
|--------------------------------------------------------------------------
*/

cart_update_response(
    true,
    $message,
    200,
    [
        'product_id' => $productId,
        'quantity' => $quantity,
        'stock' => $stock,
        'price' => number_format(
            $price,
            2,
            '.',
            ''
        ),
        'line_total' => number_format(
            $lineTotal,
            2,
            '.',
            ''
        ),
        'cart_count' => $cartCount,
        'cart_total' => number_format(
            $cartTotal,
            2,
            '.',
            ''
        )
    ]
);
