<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Password Change
|--------------------------------------------------------------------------
| Location:
| C:\xampp\htdocs\pys\customer\password.php
|
| Changes the password of the currently logged-in customer.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';


/*
|--------------------------------------------------------------------------
| JSON Response Helper
|--------------------------------------------------------------------------
*/

function password_response(
    bool $success,
    string $message,
    int $statusCode = 200
): never {
    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        [
            'success' => $success,
            'message' => $message
        ],
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    password_response(
        false,
        'Please log in to change your password.',
        401
    );
}

$userId = (int) $_SESSION['user_id'];


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    password_response(
        false,
        'Invalid request method.',
        405
    );
}


/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    password_response(
        false,
        'Your security token has expired. Please refresh the page and try again.',
        419
    );
}


/*
|--------------------------------------------------------------------------
| Read Password Fields
|--------------------------------------------------------------------------
*/

$currentPassword = (string) (
    $_POST['current_password'] ?? ''
);

$newPassword = (string) (
    $_POST['new_password'] ?? ''
);

$confirmPassword = (string) (
    $_POST['confirm_password'] ?? ''
);


/*
|--------------------------------------------------------------------------
| Required Fields
|--------------------------------------------------------------------------
*/

if (
    $currentPassword === '' ||
    $newPassword === '' ||
    $confirmPassword === ''
) {

    password_response(
        false,
        'Please complete all password fields.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| New Password Length
|--------------------------------------------------------------------------
*/

if (strlen($newPassword) < 8) {

    password_response(
        false,
        'Your new password must contain at least 8 characters.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Maximum Password Length
|--------------------------------------------------------------------------
*/

if (strlen($newPassword) > 255) {

    password_response(
        false,
        'Your new password is too long.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Confirm Password
|--------------------------------------------------------------------------
*/

if (!hash_equals($newPassword, $confirmPassword)) {

    password_response(
        false,
        'The new passwords do not match.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Password Strength
|--------------------------------------------------------------------------
|
| Requires:
| - At least one letter
| - At least one number
|
|--------------------------------------------------------------------------
*/

if (!preg_match('/[A-Za-z]/', $newPassword)) {

    password_response(
        false,
        'Your new password must contain at least one letter.',
        422
    );
}


if (!preg_match('/[0-9]/', $newPassword)) {

    password_response(
        false,
        'Your new password must contain at least one number.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Retrieve Current User
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        password,
        status
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$user = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Account Not Found
|--------------------------------------------------------------------------
*/

if (!$user) {

    unset($_SESSION['user_id']);

    password_response(
        false,
        'Your account could not be found. Please log in again.',
        401
    );
}


/*
|--------------------------------------------------------------------------
| Account Status
|--------------------------------------------------------------------------
*/

if (($user['status'] ?? '') !== 'active') {

    password_response(
        false,
        'Your account is currently unavailable.',
        403
    );
}


/*
|--------------------------------------------------------------------------
| Verify Current Password
|--------------------------------------------------------------------------
*/

$storedPassword = (string) (
    $user['password'] ?? ''
);

if (
    $storedPassword === '' ||
    !password_verify($currentPassword, $storedPassword)
) {

    password_response(
        false,
        'Your current password is incorrect.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Prevent Password Reuse
|--------------------------------------------------------------------------
*/

if (password_verify($newPassword, $storedPassword)) {

    password_response(
        false,
        'Your new password must be different from your current password.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Generate Secure Password Hash
|--------------------------------------------------------------------------
*/

$newPasswordHash = password_hash(
    $newPassword,
    PASSWORD_DEFAULT
);


if ($newPasswordHash === false) {

    password_response(
        false,
        'Unable to securely process your new password.',
        500
    );
}


/*
|--------------------------------------------------------------------------
| Update Password
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    UPDATE users
    SET password = ?
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'si',
    $newPasswordHash,
    $userId
);

$stmt->execute();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Regenerate Session ID
|--------------------------------------------------------------------------
|
| Helps protect the authenticated session after a credential change.
|--------------------------------------------------------------------------
*/

session_regenerate_id(true);


/*
|--------------------------------------------------------------------------
| Success
|--------------------------------------------------------------------------
*/

password_response(
    true,
    'Your password has been changed successfully.'
);
