<?php
declare(strict_types=1);

/**
 * Square Furniture
 * Customer Cart AJAX Endpoint
 *
 * File:
 * /customer/cart.php
 *
 * Purpose:
 * - Loads the current customer's session cart.
 * - Validates products against the database.
 * - Calculates quantities and totals server-side.
 * - Returns JSON for the account drawer.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json; charset=utf-8');

try {

    /* =========================================================
       AUTHENTICATION
    ========================================================= */

    if (empty($_SESSION['user_id'])) {

        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Please sign in to view your cart.'
        ]);

        exit;
    }

    $user_id = (int) $_SESSION['user_id'];


    /* =========================================================
       REQUEST METHOD
    ========================================================= */

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

        http_response_code(405);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);

        exit;
    }


    /* =========================================================
       VERIFY USER
    ========================================================= */

    $user_stmt = $conn->prepare(
        "SELECT
            id,
            name,
            email,
            status
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    $user_stmt->bind_param(
        'i',
        $user_id
    );

    $user_stmt->execute();

    $user_result = $user_stmt->get_result();

    $user = $user_result->fetch_assoc();

    $user_stmt->close();


    if (!$user) {

        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Your account could not be found.'
        ]);

        exit;
    }


    if ($user['status'] !== 'active') {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' => 'Your account is currently unavailable.'
        ]);

        exit;
    }


    /* =========================================================
       INITIALISE CART
    ========================================================= */

    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }


    /*
     * Normalise cart structure.
     *
     * Supports the common session structure:
     *
     * $_SESSION['cart'][product_id] = quantity;
     *
     * It also tolerates numeric/string keys.
     */

    $raw_cart = $_SESSION['cart'];

    $normalised_cart = [];

    foreach ($raw_cart as $product_id => $quantity) {

        $product_id = (int) $product_id;
        $quantity = (int) $quantity;

        if ($product_id <= 0 || $quantity <= 0) {
            continue;
        }

        /*
         * Prevent unreasonable session quantities.
         */
        $quantity = min($quantity, 999);

        $normalised_cart[$product_id] = $quantity;
    }


    /*
     * Replace malformed session data with
     * the clean version.
     */
    $_SESSION['cart'] = $normalised_cart;


    /* =========================================================
       EMPTY CART
    ========================================================= */

    if (empty($normalised_cart)) {

        echo json_encode([

            'success' => true,

            'customer' => [
                'id' => $user_id,
                'name' => (string) $user['name'],
                'email' => (string) $user['email']
            ],

            'items' => [],

            'summary' => [
                'item_lines' => 0,
                'quantity' => 0,
                'subtotal' => 0,
                'subtotal_formatted' => 'R 0.00'
            ],

            'cart_count' => 0,

            'cart_total' => 0,

            'cart_total_formatted' => 'R 0.00'

        ], JSON_UNESCAPED_SLASHES);

        exit;
    }


    /* =========================================================
       LOAD PRODUCTS
    ========================================================= */

    $product_ids = array_keys($normalised_cart);

    $placeholders = implode(
        ',',
        array_fill(
            0,
            count($product_ids),
            '?'
        )
    );

    /*
     * Dynamic integer binding.
     */
    $types = str_repeat(
        'i',
        count($product_ids)
    );

    $product_stmt = $conn->prepare(
        "SELECT
            id,
            name,
            price,
            image,
            stock,
            status
         FROM products
         WHERE id IN ($placeholders)"
    );

    $product_stmt->bind_param(
        $types,
        ...$product_ids
    );

    $product_stmt->execute();

    $product_result =
        $product_stmt->get_result();


    /* =========================================================
       BUILD PRODUCT MAP
    ========================================================= */

    $products = [];

    while ($product = $product_result->fetch_assoc()) {

        $products[
            (int) $product['id']
        ] = $product;
    }

    $product_stmt->close();


    /* =========================================================
       BUILD CART ITEMS
    ========================================================= */

    $items = [];

    $cart_count = 0;

    $cart_total = 0.00;


    foreach ($normalised_cart as $product_id => $requested_quantity) {

        /*
         * Product no longer exists.
         *
         * Remove stale product from session cart.
         */
        if (!isset($products[$product_id])) {

            unset(
                $_SESSION['cart'][$product_id]
            );

            continue;
        }


        $product = $products[$product_id];


        /*
         * Only active products should remain
         * in the customer cart.
         */
        if ($product['status'] !== 'active') {

            unset(
                $_SESSION['cart'][$product_id]
            );

            continue;
        }


        $price =
            max(
                0,
                (float) $product['price']
            );


        /*
         * Stock handling.
         *
         * If stock is NULL, treat it as unlimited.
         */
        $stock = $product['stock'];

        if ($stock !== null) {
            $stock = max(
                0,
                (int) $stock
            );
        }


        /*
         * Do not allow quantity greater than stock.
         */
        $quantity = $requested_quantity;

        if ($stock !== null) {

            $quantity = min(
                $quantity,
                $stock
            );
        }


        /*
         * If stock is zero, remove the product.
         */
        if ($quantity <= 0) {

            unset(
                $_SESSION['cart'][$product_id]
            );

            continue;
        }


        /*
         * Keep corrected quantity in session.
         */
        $_SESSION['cart'][$product_id] =
            $quantity;


        $line_total =
            $price * $quantity;


        $cart_count += $quantity;

        $cart_total += $line_total;


        $items[] = [

            'product_id' =>
                $product_id,

            'name' =>
                (string) $product['name'],

            'image' =>
                $product['image'] !== null
                    ? (string) $product['image']
                    : null,

            'price' =>
                $price,

            'price_formatted' =>
                'R ' . number_format(
                    $price,
                    2,
                    '.',
                    ','
                ),

            'quantity' =>
                $quantity,

            'stock' =>
                $stock,

            'line_total' =>
                $line_total,

            'line_total_formatted' =>
                'R ' . number_format(
                    $line_total,
                    2,
                    '.',
                    ','
                ),

            'can_increase' =>
                $stock === null
                || $quantity < $stock,

            'can_decrease' =>
                $quantity > 1
        ];
    }


    /* =========================================================
       ROUND TOTAL
    ========================================================= */

    $cart_total =
        round(
            $cart_total,
            2
        );


    /* =========================================================
       RESPONSE
    ========================================================= */

    echo json_encode([

        'success' => true,

        'customer' => [

            'id' =>
                $user_id,

            'name' =>
                (string) $user['name'],

            'email' =>
                (string) $user['email']
        ],


        'items' =>
            $items,


        'summary' => [

            'item_lines' =>
                count($items),

            'quantity' =>
                $cart_count,

            'subtotal' =>
                $cart_total,

            'subtotal_formatted' =>
                'R ' . number_format(
                    $cart_total,
                    2,
                    '.',
                    ','
                )
        ],


        'cart_count' =>
            $cart_count,

        'cart_total' =>
            $cart_total,

        'cart_total_formatted' =>
            'R ' . number_format(
                $cart_total,
                2,
                '.',
                ','
            )

    ], JSON_UNESCAPED_SLASHES);


} catch (Throwable $e) {

    error_log(
        'Customer Cart Error: '
        . $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to load your cart right now.'
    ]);
}