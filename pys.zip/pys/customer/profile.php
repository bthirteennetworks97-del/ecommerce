<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Profile
|--------------------------------------------------------------------------
| Location:
| C:\xampp\htdocs\pys\customer\profile.php
|
| Updates:
| - Phone number
| - Delivery address
|
| Uses the existing users table.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';


/*
|--------------------------------------------------------------------------
| JSON Response Helper
|--------------------------------------------------------------------------
*/

function profile_response(
    bool $success,
    string $message,
    int $statusCode = 200
): never {
    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        [
            'success' => $success,
            'message' => $message
        ],
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    profile_response(
        false,
        'Please log in to update your profile.',
        401
    );
}

$userId = (int) $_SESSION['user_id'];


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    profile_response(
        false,
        'Invalid request method.',
        405
    );
}


/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
|
| Uses the same verify_csrf() function already used elsewhere
| in your Square Furniture website.
|
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    profile_response(
        false,
        'Your security token has expired. Please refresh the page and try again.',
        419
    );
}


/*
|--------------------------------------------------------------------------
| Read Input
|--------------------------------------------------------------------------
*/

$phone = trim(
    (string) ($_POST['phone'] ?? '')
);

$address = trim(
    (string) ($_POST['address'] ?? '')
);


/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
*/

if (mb_strlen($phone) > 30) {

    profile_response(
        false,
        'Phone number must not exceed 30 characters.',
        422
    );
}


if (mb_strlen($address) > 1000) {

    profile_response(
        false,
        'Address must not exceed 1000 characters.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Phone Validation
|--------------------------------------------------------------------------
|
| Allows:
| 082 123 4567
| +27 82 123 4567
| 082-123-4567
| (082) 123 4567
|
|--------------------------------------------------------------------------
*/

if ($phone !== '') {

    if (!preg_match('/^[0-9+\-\s().]{7,30}$/', $phone)) {

        profile_response(
            false,
            'Please enter a valid phone number.',
            422
        );
    }
}


/*
|--------------------------------------------------------------------------
| Address Validation
|--------------------------------------------------------------------------
*/

if ($address !== '') {

    if (mb_strlen($address) < 5) {

        profile_response(
            false,
            'Please enter a complete delivery address.',
            422
        );
    }
}


/*
|--------------------------------------------------------------------------
| Make Sure Customer Still Exists
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        status
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$user = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();


if (!$user) {

    unset($_SESSION['user_id']);

    profile_response(
        false,
        'Your account could not be found. Please log in again.',
        401
    );
}


/*
|--------------------------------------------------------------------------
| Check Account Status
|--------------------------------------------------------------------------
*/

if (($user['status'] ?? '') !== 'active') {

    profile_response(
        false,
        'Your account is currently unavailable.',
        403
    );
}


/*
|--------------------------------------------------------------------------
| Update Profile
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    UPDATE users
    SET
        phone = ?,
        address = ?
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'ssi',
    $phone,
    $address,
    $userId
);

$stmt->execute();

$updated = $stmt->affected_rows;

$stmt->close();


/*
|--------------------------------------------------------------------------
| Success
|--------------------------------------------------------------------------
|
| affected_rows may be 0 when the submitted values are identical,
| so that is still considered a successful save.
|--------------------------------------------------------------------------
*/

profile_response(
    true,
    $updated > 0
        ? 'Your contact details have been updated successfully.'
        : 'Your contact details are already up to date.'
);