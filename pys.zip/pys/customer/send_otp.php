<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Email Verification - Send OTP
|--------------------------------------------------------------------------
| Location:
| C:\xampp\htdocs\pys\customer\send_otp.php
|
| Uses:
| - users
| - email_verification_otps
|
| Sends a 6-digit verification code to the logged-in customer's
| registered email address.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';


/*
|--------------------------------------------------------------------------
| JSON Response
|--------------------------------------------------------------------------
*/

function otp_response(
    bool $success,
    string $message,
    int $statusCode = 200
): never {

    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        [
            'success' => $success,
            'message' => $message
        ],
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    otp_response(
        false,
        'Please log in to verify your email address.',
        401
    );
}

$userId = (int) $_SESSION['user_id'];


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    otp_response(
        false,
        'Invalid request method.',
        405
    );
}


/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    otp_response(
        false,
        'Your security token has expired. Please refresh the page and try again.',
        419
    );
}


/*
|--------------------------------------------------------------------------
| Get Customer
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        email,
        email_verified,
        status
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$user = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Customer Not Found
|--------------------------------------------------------------------------
*/

if (!$user) {

    unset($_SESSION['user_id']);

    otp_response(
        false,
        'Your account could not be found. Please log in again.',
        401
    );
}


/*
|--------------------------------------------------------------------------
| Account Status
|--------------------------------------------------------------------------
*/

if (($user['status'] ?? '') !== 'active') {

    otp_response(
        false,
        'Your account is currently unavailable.',
        403
    );
}


/*
|--------------------------------------------------------------------------
| Already Verified
|--------------------------------------------------------------------------
*/

if ((int) ($user['email_verified'] ?? 0) === 1) {

    otp_response(
        true,
        'Your email address is already verified.'
    );
}


/*
|--------------------------------------------------------------------------
| Validate Email
|--------------------------------------------------------------------------
*/

$email = trim((string) ($user['email'] ?? ''));

if (
    $email === '' ||
    !filter_var($email, FILTER_VALIDATE_EMAIL)
) {

    otp_response(
        false,
        'Your account does not have a valid email address.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Rate Limiting
|--------------------------------------------------------------------------
|
| Minimum 60 seconds between OTP requests.
|
|--------------------------------------------------------------------------
*/

$lastOtpTime = $_SESSION['last_otp_sent_at'] ?? 0;

if (
    is_numeric($lastOtpTime) &&
    (time() - (int) $lastOtpTime) < 60
) {

    $remaining = 60 -
        (time() - (int) $lastOtpTime);

    otp_response(
        false,
        'Please wait ' . $remaining . ' seconds before requesting another code.',
        429
    );
}


/*
|--------------------------------------------------------------------------
| Remove Old / Expired OTP Records
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    DELETE FROM email_verification_otps
    WHERE user_id = ?
      AND (
          used_at IS NOT NULL
          OR expires_at < NOW()
      )
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Limit Recent OTP Requests
|--------------------------------------------------------------------------
|
| Maximum 5 OTP records created during the last hour.
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM email_verification_otps
    WHERE user_id = ?
      AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$result = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();

$recentOtpCount = (int) ($result['total'] ?? 0);

if ($recentOtpCount >= 5) {

    otp_response(
        false,
        'Too many verification codes have been requested. Please try again later.',
        429
    );
}


/*
|--------------------------------------------------------------------------
| Generate Secure 6-Digit OTP
|--------------------------------------------------------------------------
*/

try {

    $otp = (string) random_int(
        100000,
        999999
    );

} catch (Throwable $e) {

    otp_response(
        false,
        'Unable to generate a verification code. Please try again later.',
        500
    );
}


/*
|--------------------------------------------------------------------------
| Hash OTP
|--------------------------------------------------------------------------
|
| Never store the actual OTP in the database.
|--------------------------------------------------------------------------
*/

$otpHash = password_hash(
    $otp,
    PASSWORD_DEFAULT
);

if ($otpHash === false) {

    otp_response(
        false,
        'Unable to securely create the verification code.',
        500
    );
}


/*
|--------------------------------------------------------------------------
| Expiration
|--------------------------------------------------------------------------
*/

$expiresAt = date(
    'Y-m-d H:i:s',
    time() + (10 * 60)
);


/*
|--------------------------------------------------------------------------
| Invalidate Previous Active Codes
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    UPDATE email_verification_otps
    SET used_at = NOW()
    WHERE user_id = ?
      AND used_at IS NULL
");

$stmt->bind_param(
    'i',
    $userId
);

$stmt->execute();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Store New OTP
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    INSERT INTO email_verification_otps
    (
        user_id,
        otp_hash,
        expires_at
    )
    VALUES
    (
        ?,
        ?,
        ?
    )
");

$stmt->bind_param(
    'iss',
    $userId,
    $otpHash,
    $expiresAt
);

$stmt->execute();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Send through Brevo transactional email API
|--------------------------------------------------------------------------
*/

$emailContent = square_furniture_verification_email(
    $customerName,
    $otp
);

$mail = send_brevo_email(
    $email,
    $customerName,
    APP_NAME . ' - Email Verification Code',
    $emailContent['html'],
    $emailContent['text']
);

if (!$mail['success']) {

    $stmt = $conn->prepare("
        DELETE FROM email_verification_otps
        WHERE user_id = ?
          AND otp_hash = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        'is',
        $userId,
        $otpHash
    );

    $stmt->execute();
    $stmt->close();

    otp_response(
        false,
        'The verification email could not be sent. Please try again later.',
        500
    );
}


/*
|--------------------------------------------------------------------------
| Store Request Time in Session
|--------------------------------------------------------------------------
*/

$_SESSION['last_otp_sent_at'] = time();


/*
|--------------------------------------------------------------------------
| Success
|--------------------------------------------------------------------------
*/

otp_response(
    true,
    'A verification code has been sent to your registered email address.'
);