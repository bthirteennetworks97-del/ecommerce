<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Email Change - Verify OTP
|--------------------------------------------------------------------------
| The existing email is changed only after the OTP for the new email
| is successfully verified.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';

function email_change_verify_response(bool $success, string $message, int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'success' => $success,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

if (empty($_SESSION['user_id'])) {
    email_change_verify_response(false, 'Please log in to verify your new email address.', 401);
}

$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    email_change_verify_response(false, 'Invalid request method.', 405);
}

try {
    verify_csrf();
} catch (Throwable $e) {
    email_change_verify_response(false, 'Your security token has expired. Please refresh the page and try again.', 419);
}

$otp = preg_replace('/\D+/', '', (string) ($_POST['otp'] ?? ''));

if (strlen($otp) !== 6) {
    email_change_verify_response(false, 'Enter the 6-digit verification code.', 422);
}

$conn->begin_transaction();

try {
    $stmt = $conn->prepare("
        SELECT id, name, email, status
        FROM users
        WHERE id = ?
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$user) {
        throw new RuntimeException('ACCOUNT_NOT_FOUND');
    }

    if (($user['status'] ?? '') !== 'active') {
        throw new RuntimeException('ACCOUNT_UNAVAILABLE');
    }

    /*
    |--------------------------------------------------------------------------
    | Lock the newest active email-change OTP.
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare("
        SELECT id, email, otp_hash, expires_at, attempts, used_at
        FROM auth_otps
        WHERE user_id = ?
          AND purpose = 'email_change'
          AND used_at IS NULL
        ORDER BY id DESC
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $otpRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$otpRow) {
        throw new RuntimeException('NO_OTP');
    }

    $otpId = (int) $otpRow['id'];
    $attempts = (int) ($otpRow['attempts'] ?? 0);

    if ($attempts >= 5) {
        $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $otpId);
        $stmt->execute();
        $stmt->close();

        throw new RuntimeException('TOO_MANY_ATTEMPTS');
    }

    if (empty($otpRow['expires_at']) || strtotime((string) $otpRow['expires_at']) < time()) {
        $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $otpId);
        $stmt->execute();
        $stmt->close();

        throw new RuntimeException('EXPIRED');
    }

    if (!password_verify($otp, (string) $otpRow['otp_hash'])) {
        $newAttempts = $attempts + 1;

        if ($newAttempts >= 5) {
            $stmt = $conn->prepare("
                UPDATE auth_otps
                SET attempts = ?, used_at = NOW()
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->bind_param('ii', $newAttempts, $otpId);
        } else {
            $stmt = $conn->prepare("
                UPDATE auth_otps
                SET attempts = ?
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->bind_param('ii', $newAttempts, $otpId);
        }

        $stmt->execute();
        $stmt->close();

        throw new RuntimeException($newAttempts >= 5 ? 'TOO_MANY_ATTEMPTS' : 'INVALID_OTP');
    }

    $newEmail = strtolower(trim((string) ($otpRow['email'] ?? '')));

    if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('INVALID_EMAIL');
    }

    /*
    |--------------------------------------------------------------------------
    | Re-check uniqueness while the transaction is open.
    |--------------------------------------------------------------------------
    */
    $stmt = $conn->prepare("
        SELECT id
        FROM users
        WHERE email = ?
          AND id <> ?
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->bind_param('si', $newEmail, $userId);
    $stmt->execute();
    $duplicate = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($duplicate) {
        throw new RuntimeException('EMAIL_TAKEN');
    }

    $stmt = $conn->prepare("
        UPDATE users
        SET email = ?, email_verified = 1
        WHERE id = ?
        LIMIT 1
    ");
    $stmt->bind_param('si', $newEmail, $userId);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("
        UPDATE auth_otps
        SET used_at = NOW()
        WHERE user_id = ?
          AND purpose = 'email_change'
          AND used_at IS NULL
    ");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    unset($_SESSION['email_change_otp_sent_at']);

    if (function_exists('log_activity')) {
        try {
            log_activity($conn, $userId, 'customer_email_changed');
        } catch (Throwable $logError) {
            // Do not undo a successful email change because audit logging failed.
        }
    }

    email_change_verify_response(true, 'Your email address has been changed and verified successfully.');

} catch (Throwable $e) {
    $conn->rollback();

    $messages = [
        'ACCOUNT_NOT_FOUND' => ['Your account could not be found. Please log in again.', 401],
        'ACCOUNT_UNAVAILABLE' => ['Your account is currently unavailable.', 403],
        'NO_OTP' => ['No active email-change verification code was found. Please request a new code.', 404],
        'TOO_MANY_ATTEMPTS' => ['Too many incorrect attempts. Please request a new verification code.', 429],
        'EXPIRED' => ['This verification code has expired. Please request a new code.', 410],
        'INVALID_OTP' => ['The verification code is incorrect.', 422],
        'INVALID_EMAIL' => ['The pending email address is invalid. Please request a new code.', 422],
        'EMAIL_TAKEN' => ['That email address is already registered to another account.', 409],
    ];

    [$message, $status] = $messages[$e->getMessage()] ?? ['Unable to change your email address right now.', 500];

    email_change_verify_response(false, $message, $status);
}
