<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Cart - Remove Item
|--------------------------------------------------------------------------
| Location:
| C:\xampp\htdocs\pys\customer\cart_remove.php
|
| Removes one product from the current customer's session cart.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';


/*
|--------------------------------------------------------------------------
| JSON Response Helper
|--------------------------------------------------------------------------
*/

function cart_remove_response(
    bool $success,
    string $message,
    int $statusCode = 200,
    array $extra = []
): never {

    http_response_code($statusCode);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        ),
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    cart_remove_response(
        false,
        'Please log in to manage your cart.',
        401
    );
}


/*
|--------------------------------------------------------------------------
| Only POST Requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    cart_remove_response(
        false,
        'Invalid request method.',
        405
    );
}


/*
|--------------------------------------------------------------------------
| CSRF Protection
|--------------------------------------------------------------------------
*/

try {

    verify_csrf();

} catch (Throwable $e) {

    cart_remove_response(
        false,
        'Your security token has expired. Please refresh the page and try again.',
        419
    );
}


/*
|--------------------------------------------------------------------------
| Product ID
|--------------------------------------------------------------------------
*/

$productId = filter_input(
    INPUT_POST,
    'product_id',
    FILTER_VALIDATE_INT
);


if (
    $productId === false ||
    $productId === null ||
    $productId < 1
) {

    cart_remove_response(
        false,
        'Invalid product.',
        422
    );
}


/*
|--------------------------------------------------------------------------
| Make Sure Cart Exists
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['cart']) ||
    !is_array($_SESSION['cart'])
) {

    $_SESSION['cart'] = [];

    cart_remove_response(
        true,
        'Your cart is already empty.',
        200,
        [
            'cart_count' => 0,
            'cart_total' => 0
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Normalize Cart Keys
|--------------------------------------------------------------------------
|
| Handles carts where product IDs may have been stored as strings.
|--------------------------------------------------------------------------
*/

$cart = [];

foreach ($_SESSION['cart'] as $id => $quantity) {

    $id = (int) $id;
    $quantity = (int) $quantity;

    if ($id > 0 && $quantity > 0) {
        $cart[$id] = $quantity;
    }
}


/*
|--------------------------------------------------------------------------
| Check Product Is In Cart
|--------------------------------------------------------------------------
*/

if (!array_key_exists($productId, $cart)) {

    $_SESSION['cart'] = $cart;

    cart_remove_response(
        false,
        'This product is not in your cart.',
        404
    );
}


/*
|--------------------------------------------------------------------------
| Remove Product
|--------------------------------------------------------------------------
*/

unset(
    $cart[$productId]
);


/*
|--------------------------------------------------------------------------
| Save Updated Cart
|--------------------------------------------------------------------------
*/

$_SESSION['cart'] = $cart;


/*
|--------------------------------------------------------------------------
| Calculate Cart Count
|--------------------------------------------------------------------------
*/

$cartCount = 0;

foreach ($cart as $quantity) {

    $cartCount += max(
        0,
        (int) $quantity
    );
}


/*
|--------------------------------------------------------------------------
| Calculate Cart Total
|--------------------------------------------------------------------------
|
| Prices are retrieved from the database rather than trusting
| anything sent by the browser.
|--------------------------------------------------------------------------
*/

$cartTotal = 0.00;

if (!empty($cart)) {

    $productIds = array_keys($cart);

    $placeholders = implode(
        ',',
        array_fill(
            0,
            count($productIds),
            '?'
        )
    );

    $types = str_repeat(
        'i',
        count($productIds)
    );

    $sql = "
        SELECT
            id,
            price
        FROM products
        WHERE id IN ($placeholders)
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        $types,
        ...$productIds
    );

    $stmt->execute();

    $result = $stmt->get_result();

    while ($product = $result->fetch_assoc()) {

        $id = (int) $product['id'];

        $price = (float) $product['price'];

        $quantity = (int) ($cart[$id] ?? 0);

        $cartTotal += $price * $quantity;
    }

    $stmt->close();
}


/*
|--------------------------------------------------------------------------
| Success
|--------------------------------------------------------------------------
*/

cart_remove_response(
    true,
    'Product removed from your cart.',
    200,
    [
        'product_id' => $productId,
        'cart_count' => $cartCount,
        'cart_total' => number_format(
            $cartTotal,
            2,
            '.',
            ''
        )
    ]
);