<?php
declare(strict_types=1);

/**
 * Square Furniture
 * Customer Order Details AJAX Endpoint
 *
 * File:
 * /customer/order_details.php
 *
 * Purpose:
 * - Loads one order for the logged-in customer.
 * - Loads all products belonging to that order.
 * - Displays delivery and payment information.
 * - Returns JSON for the customer account drawer.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json; charset=utf-8');


try {

    /* =========================================================
       AUTHENTICATION
    ========================================================= */

    if (empty($_SESSION['user_id'])) {

        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Please sign in to view this order.'
        ]);

        exit;
    }


    $user_id = (int) $_SESSION['user_id'];


    /* =========================================================
       REQUEST METHOD
    ========================================================= */

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {

        http_response_code(405);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);

        exit;
    }


    /* =========================================================
       ORDER ID
    ========================================================= */

    $order_id = isset($_GET['id'])
        ? (int) $_GET['id']
        : 0;

    /*
     * Also support order_id for compatibility.
     */
    if ($order_id <= 0 && isset($_GET['order_id'])) {
        $order_id = (int) $_GET['order_id'];
    }


    if ($order_id <= 0) {

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid order number.'
        ]);

        exit;
    }


    /* =========================================================
       VERIFY CUSTOMER ACCOUNT
    ========================================================= */

    $user_stmt = $conn->prepare(
        "SELECT
            id,
            name,
            email,
            status
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    $user_stmt->bind_param(
        'i',
        $user_id
    );

    $user_stmt->execute();

    $user_result = $user_stmt->get_result();
    $user = $user_result->fetch_assoc();

    $user_stmt->close();


    if (!$user) {

        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Your account could not be found.'
        ]);

        exit;
    }


    if ($user['status'] !== 'active') {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' => 'Your account is currently unavailable.'
        ]);

        exit;
    }


    /* =========================================================
       LOAD ORDER
       
       IMPORTANT:
       user_id is checked here so a customer cannot access
       another customer's order by changing ?id=
    ========================================================= */

    $order_stmt = $conn->prepare(
        "SELECT
            id,
            user_id,
            total,
            full_name,
            phone,
            address,
            city,
            postal_code,
            status,
            payment_ref,
            created_at
         FROM orders
         WHERE id = ?
         AND user_id = ?
         LIMIT 1"
    );

    $order_stmt->bind_param(
        'ii',
        $order_id,
        $user_id
    );

    $order_stmt->execute();

    $order_result = $order_stmt->get_result();
    $order = $order_result->fetch_assoc();

    $order_stmt->close();


    if (!$order) {

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'message' => 'Order not found or you do not have permission to view it.'
        ]);

        exit;
    }


    /* =========================================================
       STATUS LABELS
    ========================================================= */

    $status_labels = [
        'pending' => 'Pending',
        'paid' => 'Paid',
        'processing' => 'Processing',
        'shipped' => 'Shipped',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled'
    ];


    $status = strtolower(
        (string) $order['status']
    );

    $status_label =
        $status_labels[$status]
        ?? ucfirst($status);


    /* =========================================================
       LOAD ORDER ITEMS
    ========================================================= */

    $items_stmt = $conn->prepare(
        "SELECT
            oi.id,
            oi.product_id,
            oi.quantity,
            oi.price,
            p.name AS product_name,
            p.image AS product_image,
            p.status AS product_status
         FROM order_items oi
         LEFT JOIN products p
            ON p.id = oi.product_id
         WHERE oi.order_id = ?
         ORDER BY oi.id ASC"
    );

    $items_stmt->bind_param(
        'i',
        $order_id
    );

    $items_stmt->execute();

    $items_result = $items_stmt->get_result();


    $items = [];

    while ($item = $items_result->fetch_assoc()) {

        $quantity = max(
            0,
            (int) $item['quantity']
        );

        $price = (float) $item['price'];

        $line_total = $price * $quantity;


        $items[] = [

            'id' =>
                (int) $item['id'],

            'product_id' =>
                (int) $item['product_id'],

            'product_name' =>
                $item['product_name'] !== null
                    ? (string) $item['product_name']
                    : 'Product no longer available',

            'product_image' =>
                $item['product_image'] !== null
                    ? (string) $item['product_image']
                    : null,

            'product_available' =>
                $item['product_id'] !== null
                && $item['product_status'] === 'active',

            'quantity' =>
                $quantity,

            'price' =>
                $price,

            'price_formatted' =>
                'R ' . number_format(
                    $price,
                    2,
                    '.',
                    ','
                ),

            'line_total' =>
                $line_total,

            'line_total_formatted' =>
                'R ' . number_format(
                    $line_total,
                    2,
                    '.',
                    ','
                )
        ];
    }

    $items_stmt->close();


    /* =========================================================
       STATUS TIMELINE
    ========================================================= */

    $timeline_statuses = [
        'pending',
        'paid',
        'processing',
        'shipped',
        'delivered'
    ];

    $timeline = [];

    $current_status_index =
        array_search(
            $status,
            $timeline_statuses,
            true
        );

    /*
     * Cancelled orders have a separate timeline.
     */
    if ($status === 'cancelled') {

        $timeline[] = [
            'status' => 'pending',
            'label' => 'Order Placed',
            'completed' => true,
            'current' => false
        ];

        $timeline[] = [
            'status' => 'cancelled',
            'label' => 'Order Cancelled',
            'completed' => true,
            'current' => true
        ];

    } else {

        foreach (
            $timeline_statuses
            as $index => $timeline_status
        ) {

            $label_map = [
                'pending' => 'Order Placed',
                'paid' => 'Payment Confirmed',
                'processing' => 'Being Prepared',
                'shipped' => 'Order Shipped',
                'delivered' => 'Delivered'
            ];

            $completed =
                $current_status_index !== false
                && $index <= $current_status_index;

            $current =
                $timeline_status === $status;

            $timeline[] = [
                'status' =>
                    $timeline_status,

                'label' =>
                    $label_map[$timeline_status],

                'completed' =>
                    $completed,

                'current' =>
                    $current
            ];
        }
    }


    /* =========================================================
       ADDRESS
    ========================================================= */

    $delivery_address = trim(
        (string) $order['address']
    );

    $delivery_city = trim(
        (string) $order['city']
    );

    $delivery_postal_code = trim(
        (string) $order['postal_code']
    );


    $formatted_address = $delivery_address;

    if ($delivery_city !== '') {

        $formatted_address .=
            ($formatted_address !== '' ? ', ' : '')
            . $delivery_city;
    }

    if ($delivery_postal_code !== '') {

        $formatted_address .=
            ($formatted_address !== '' ? ', ' : '')
            . $delivery_postal_code;
    }


    /* =========================================================
       ORDER DATE
    ========================================================= */

    $created_timestamp =
        strtotime(
            (string) $order['created_at']
        );

    $created_formatted =
        $created_timestamp !== false
            ? date(
                'd M Y, H:i',
                $created_timestamp
            )
            : (string) $order['created_at'];


    /* =========================================================
       PAYMENT INFORMATION
    ========================================================= */

    $payment_ref =
        $order['payment_ref'] !== null
            ? trim((string) $order['payment_ref'])
            : '';

    $payment_status = match ($status) {

        'paid',
        'processing',
        'shipped',
        'delivered'
            => 'Payment confirmed',

        'cancelled'
            => 'Order cancelled',

        default
            => 'Payment pending'
    };


    /* =========================================================
       ITEM SUMMARY
    ========================================================= */

    $total_quantity = 0;

    foreach ($items as $item) {

        $total_quantity +=
            (int) $item['quantity'];
    }


    /* =========================================================
       FINAL RESPONSE
    ========================================================= */

    echo json_encode([

        'success' => true,

        'customer' => [
            'id' =>
                $user_id,

            'name' =>
                (string) $user['name'],

            'email' =>
                (string) $user['email']
        ],


        'order' => [

            'id' =>
                $order_id,

            'order_number' =>
                'SF-' . str_pad(
                    (string) $order_id,
                    6,
                    '0',
                    STR_PAD_LEFT
                ),

            'total' =>
                (float) $order['total'],

            'total_formatted' =>
                'R ' . number_format(
                    (float) $order['total'],
                    2,
                    '.',
                    ','
                ),

            'status' =>
                $status,

            'status_label' =>
                $status_label,

            'created_at' =>
                (string) $order['created_at'],

            'created_formatted' =>
                $created_formatted,

            'payment_ref' =>
                $payment_ref !== ''
                    ? $payment_ref
                    : null,

            'payment_status' =>
                $payment_status,


            'customer_details' => [

                'name' =>
                    (string) $order['full_name'],

                'phone' =>
                    (string) $order['phone'],

                'email' =>
                    (string) $user['email']
            ],


            'delivery' => [

                'address' =>
                    $delivery_address,

                'city' =>
                    $delivery_city,

                'postal_code' =>
                    $delivery_postal_code,

                'formatted' =>
                    $formatted_address
            ],


            'summary' => [

                'item_lines' =>
                    count($items),

                'quantity' =>
                    $total_quantity
            ],


            'items' =>
                $items,


            'timeline' =>
                $timeline
        ]

    ], JSON_UNESCAPED_SLASHES);


} catch (Throwable $e) {

    error_log(
        'Customer Order Details Error: '
        . $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to load the order details right now.'
    ]);
}