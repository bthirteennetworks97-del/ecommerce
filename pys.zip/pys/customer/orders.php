<?php
declare(strict_types=1);

/**
 * Square Furniture
 * Customer Orders AJAX Endpoint
 *
 * File:
 * /customer/orders.php
 *
 * Returns the authenticated customer's orders as JSON.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

header('Content-Type: application/json; charset=utf-8');

try {

    /* =========================================================
       AUTHENTICATION
    ========================================================= */

    if (empty($_SESSION['user_id'])) {
        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Please sign in to view your orders.'
        ]);

        exit;
    }

    $user_id = (int) $_SESSION['user_id'];

    /* =========================================================
       REQUEST METHOD
    ========================================================= */

    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);

        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method.'
        ]);

        exit;
    }

    /* =========================================================
       PAGINATION
    ========================================================= */

    $page = isset($_GET['page'])
        ? max(1, (int) $_GET['page'])
        : 1;

    $limit = isset($_GET['limit'])
        ? (int) $_GET['limit']
        : 5;

    /*
     * Prevent excessively large queries.
     */
    $limit = max(1, min($limit, 20));

    $offset = ($page - 1) * $limit;


    /* =========================================================
       OPTIONAL STATUS FILTER
    ========================================================= */

    $allowed_statuses = [
        'pending',
        'paid',
        'processing',
        'shipped',
        'delivered',
        'cancelled'
    ];

    $status = isset($_GET['status'])
        ? trim((string) $_GET['status'])
        : '';

    if ($status !== '' && !in_array($status, $allowed_statuses, true)) {
        $status = '';
    }


    /* =========================================================
       VERIFY CUSTOMER STILL EXISTS
    ========================================================= */

    $user_stmt = $conn->prepare(
        "SELECT id, name, email, status
         FROM users
         WHERE id = ?
         LIMIT 1"
    );

    $user_stmt->bind_param('i', $user_id);
    $user_stmt->execute();

    $user_result = $user_stmt->get_result();
    $user = $user_result->fetch_assoc();

    $user_stmt->close();

    if (!$user) {
        http_response_code(401);

        echo json_encode([
            'success' => false,
            'message' => 'Your account could not be found.'
        ]);

        exit;
    }

    if ($user['status'] !== 'active') {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' => 'Your account is currently unavailable.'
        ]);

        exit;
    }


    /* =========================================================
       TOTAL ORDER COUNT
    ========================================================= */

    if ($status !== '') {

        $count_stmt = $conn->prepare(
            "SELECT COUNT(*) AS total
             FROM orders
             WHERE user_id = ?
             AND status = ?"
        );

        $count_stmt->bind_param(
            'is',
            $user_id,
            $status
        );

    } else {

        $count_stmt = $conn->prepare(
            "SELECT COUNT(*) AS total
             FROM orders
             WHERE user_id = ?"
        );

        $count_stmt->bind_param(
            'i',
            $user_id
        );
    }

    $count_stmt->execute();

    $count_result = $count_stmt->get_result();
    $count_row = $count_result->fetch_assoc();

    $total_orders = (int) ($count_row['total'] ?? 0);

    $count_stmt->close();


    /* =========================================================
       ORDER QUERY
    ========================================================= */

    if ($status !== '') {

        $order_stmt = $conn->prepare(
            "SELECT
                id,
                total,
                full_name,
                phone,
                address,
                city,
                postal_code,
                status,
                payment_ref,
                created_at
             FROM orders
             WHERE user_id = ?
             AND status = ?
             ORDER BY created_at DESC, id DESC
             LIMIT ? OFFSET ?"
        );

        $order_stmt->bind_param(
            'isii',
            $user_id,
            $status,
            $limit,
            $offset
        );

    } else {

        $order_stmt = $conn->prepare(
            "SELECT
                id,
                total,
                full_name,
                phone,
                address,
                city,
                postal_code,
                status,
                payment_ref,
                created_at
             FROM orders
             WHERE user_id = ?
             ORDER BY created_at DESC, id DESC
             LIMIT ? OFFSET ?"
        );

        $order_stmt->bind_param(
            'iii',
            $user_id,
            $limit,
            $offset
        );
    }

    $order_stmt->execute();

    $result = $order_stmt->get_result();


    /* =========================================================
       STATUS HELPERS
    ========================================================= */

    $status_labels = [
        'pending' => 'Pending',
        'paid' => 'Paid',
        'processing' => 'Processing',
        'shipped' => 'Shipped',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled'
    ];


    /* =========================================================
       BUILD ORDER DATA
    ========================================================= */

    $orders = [];

    while ($order = $result->fetch_assoc()) {

        $order_id = (int) $order['id'];

        $order_status = strtolower(
            (string) $order['status']
        );

        /*
         * Count products/items in this order.
         */
        $items_stmt = $conn->prepare(
            "SELECT
                COUNT(*) AS item_lines,
                COALESCE(SUM(quantity), 0) AS item_quantity
             FROM order_items
             WHERE order_id = ?"
        );

        $items_stmt->bind_param(
            'i',
            $order_id
        );

        $items_stmt->execute();

        $items_result = $items_stmt->get_result();
        $items = $items_result->fetch_assoc();

        $items_stmt->close();


        $orders[] = [
            'id' => $order_id,

            'order_number' =>
                'SF-' . str_pad(
                    (string) $order_id,
                    6,
                    '0',
                    STR_PAD_LEFT
                ),

            'total' => (float) $order['total'],

            'total_formatted' =>
                'R ' . number_format(
                    (float) $order['total'],
                    2,
                    '.',
                    ','
                ),

            'full_name' =>
                (string) $order['full_name'],

            'phone' =>
                (string) $order['phone'],

            'address' =>
                (string) $order['address'],

            'city' =>
                (string) $order['city'],

            'postal_code' =>
                (string) $order['postal_code'],

            'status' =>
                $order_status,

            'status_label' =>
                $status_labels[$order_status]
                ?? ucfirst($order_status),

            'payment_ref' =>
                $order['payment_ref'] !== null
                    ? (string) $order['payment_ref']
                    : null,

            'created_at' =>
                (string) $order['created_at'],

            'created_at_formatted' =>
                date('d M Y, H:i', strtotime((string) $order['created_at'])),

            'total_quantity' =>
                (int) ($items['item_quantity'] ?? 0),

            'items' => [
                'lines' =>
                    (int) ($items['item_lines'] ?? 0),

                'quantity' =>
                    (int) ($items['item_quantity'] ?? 0)
            ]
        ];
    }

    $order_stmt->close();


    /* =========================================================
       PAGINATION
    ========================================================= */

    $total_pages = $total_orders > 0
        ? (int) ceil($total_orders / $limit)
        : 0;


    /* =========================================================
       RESPONSE
    ========================================================= */

    echo json_encode([
        'success' => true,

        'customer' => [
            'id' => $user_id,
            'name' => (string) $user['name'],
            'email' => (string) $user['email']
        ],

        'orders' => $orders,

        'filter' => $status,

        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total_orders' => $total_orders,
            'total_pages' => $total_pages,
            'has_previous' => $page > 1,
            'has_next' => $page < $total_pages
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {

    error_log(
        'Customer Orders Error: ' .
        $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to load your orders right now.'
    ]);
}