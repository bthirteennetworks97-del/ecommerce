<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Customer Email Change - Send OTP
|--------------------------------------------------------------------------
| Sends a one-time verification code to the NEW email address.
| The current users.email value is not changed until verification succeeds.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';

function email_change_response(bool $success, string $message, int $statusCode = 200): never
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'success' => $success,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

if (empty($_SESSION['user_id'])) {
    email_change_response(false, 'Please log in to change your email address.', 401);
}

$userId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    email_change_response(false, 'Invalid request method.', 405);
}

try {
    verify_csrf();
} catch (Throwable $e) {
    email_change_response(false, 'Your security token has expired. Please refresh the page and try again.', 419);
}

$newEmail = strtolower(trim((string) ($_POST['new_email'] ?? '')));

if ($newEmail === '' || !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
    email_change_response(false, 'Please enter a valid new email address.', 422);
}

if (strlen($newEmail) > 190) {
    email_change_response(false, 'The new email address is too long.', 422);
}

$stmt = $conn->prepare("
    SELECT id, name, email, status
    FROM users
    WHERE id = ?
    LIMIT 1
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    unset($_SESSION['user_id']);
    email_change_response(false, 'Your account could not be found. Please log in again.', 401);
}

if (($user['status'] ?? '') !== 'active') {
    email_change_response(false, 'Your account is currently unavailable.', 403);
}

$currentEmail = strtolower(trim((string) ($user['email'] ?? '')));

if ($newEmail === $currentEmail) {
    email_change_response(false, 'The new email address must be different from your current email address.', 422);
}

/*
|--------------------------------------------------------------------------
| Check uniqueness before generating/sending the OTP.
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    SELECT id
    FROM users
    WHERE email = ?
      AND id <> ?
    LIMIT 1
");
$stmt->bind_param('si', $newEmail, $userId);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing) {
    email_change_response(false, 'That email address is already registered to another account.', 409);
}

/*
|--------------------------------------------------------------------------
| Rate limits:
| - 60 seconds between requests for this session/user
| - maximum 5 email-change OTPs per hour
|--------------------------------------------------------------------------
*/
$lastRequest = (int) ($_SESSION['email_change_otp_sent_at'] ?? 0);

if ($lastRequest > 0 && (time() - $lastRequest) < 60) {
    $remaining = 60 - (time() - $lastRequest);
    email_change_response(false, 'Please wait ' . $remaining . ' seconds before requesting another code.', 429);
}

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM auth_otps
    WHERE user_id = ?
      AND purpose = 'email_change'
      AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$countRow = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ((int) ($countRow['total'] ?? 0) >= 5) {
    email_change_response(false, 'Too many email verification codes have been requested. Please try again later.', 429);
}

/*
|--------------------------------------------------------------------------
| Invalidate previous email-change codes.
|--------------------------------------------------------------------------
*/
$stmt = $conn->prepare("
    UPDATE auth_otps
    SET used_at = NOW()
    WHERE user_id = ?
      AND purpose = 'email_change'
      AND used_at IS NULL
");
$stmt->bind_param('i', $userId);
$stmt->execute();
$stmt->close();

try {
    $otp = (string) random_int(100000, 999999);
} catch (Throwable $e) {
    email_change_response(false, 'Unable to generate a verification code. Please try again later.', 500);
}

$otpHash = password_hash($otp, PASSWORD_DEFAULT);

if ($otpHash === false) {
    email_change_response(false, 'Unable to securely create the verification code.', 500);
}

$expiresAt = date('Y-m-d H:i:s', time() + (10 * 60));

$stmt = $conn->prepare("
    INSERT INTO auth_otps
    (user_id, email, purpose, otp_hash, expires_at)
    VALUES (?, ?, 'email_change', ?, ?)
");
$stmt->bind_param('isss', $userId, $newEmail, $otpHash, $expiresAt);
$stmt->execute();
$otpId = $stmt->insert_id;
$stmt->close();

$emailContent = square_furniture_email_change_otp(
    (string) ($user['name'] ?? 'Customer'),
    $otp,
    $newEmail
);

$mail = send_brevo_email(
    $newEmail,
    (string) ($user['name'] ?? 'Customer'),
    APP_NAME . ' - Confirm Your New Email Address',
    $emailContent['html'],
    $emailContent['text']
);

if (!$mail['success']) {
    $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $otpId);
    $stmt->execute();
    $stmt->close();

    email_change_response(false, 'The verification email could not be sent. Please try again later.', 500);
}

$_SESSION['email_change_otp_sent_at'] = time();

email_change_response(
    true,
    'A verification code has been sent to your new email address. It expires in 10 minutes.'
);
