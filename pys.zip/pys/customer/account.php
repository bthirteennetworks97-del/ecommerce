<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Square Furniture - Customer Account
|--------------------------------------------------------------------------
| File:
| C:\xampp\htdocs\pys\customer\account.php
|
| This file is designed to be loaded into the right-side AJAX
| customer account drawer.
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/init.php';

$page_title = 'My Account - ' . APP_NAME;


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user_id'])) {

    http_response_code(401);

    echo '
    <div class="account-login-required">

        <div class="account-icon">🔐</div>

        <h3>Login Required</h3>

        <p>
            Please log in to access your customer account.
        </p>

        <a
            href="' . e(BASE_URL) . '/auth/login.php"
            class="btn btn-dark">
            Login
        </a>

        <a
            href="' . e(BASE_URL) . '/auth/register.php"
            class="btn btn-outline-dark">
            Create Account
        </a>

    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| Current Customer
|--------------------------------------------------------------------------
*/

$userId = (int) $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        email,
        phone,
        address,
        role,
        email_verified,
        status,
        created_at,
        last_login
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param('i', $userId);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Account Not Found
|--------------------------------------------------------------------------
*/

if (!$user) {

    unset($_SESSION['user_id']);

    http_response_code(401);

    echo '
    <div class="account-login-required">

        <div class="account-icon">⚠️</div>

        <h3>Account Not Found</h3>

        <p>
            Your account could not be found.
            Please log in again.
        </p>

        <a
            href="' . e(BASE_URL) . '/auth/login.php"
            class="btn btn-dark">
            Login
        </a>

    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| Suspended Account
|--------------------------------------------------------------------------
*/

if (($user['status'] ?? '') !== 'active') {

    echo '
    <div class="account-login-required">

        <div class="account-icon">🚫</div>

        <h3>Account Suspended</h3>

        <p>
            Your customer account is currently unavailable.
        </p>

        <button
            type="button"
            class="btn btn-dark"
            data-account-action="logout">
            Logout
        </button>

    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| Requested Section
|--------------------------------------------------------------------------
*/

$allowedSections = [
    'profile',
    'settings',
    'orders',
    'cart',
    'address',
    'password',
    'verification'
];

$section = (string) ($_GET['section'] ?? 'profile');

if (!in_array($section, $allowedSections, true)) {
    $section = 'profile';
}


/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function account_active(
    string $current,
    string $item
): string {
    return $current === $item ? ' active' : '';
}


/*
|--------------------------------------------------------------------------
| Order Count
|--------------------------------------------------------------------------
*/

$orderCount = 0;

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE user_id = ?
");

$stmt->bind_param('i', $userId);
$stmt->execute();

$orderResult = $stmt->get_result()->fetch_assoc();

$orderCount = (int) ($orderResult['total'] ?? 0);

$stmt->close();


/*
|--------------------------------------------------------------------------
| Cart Count
|--------------------------------------------------------------------------
*/

$cartCount = 0;

if (
    !empty($_SESSION['cart']) &&
    is_array($_SESSION['cart'])
) {

    foreach ($_SESSION['cart'] as $quantity) {

        $cartCount += max(
            0,
            (int) $quantity
        );
    }
}


/*
|--------------------------------------------------------------------------
| Email Verification
|--------------------------------------------------------------------------
*/

$emailVerified =
    (int) ($user['email_verified'] ?? 0) === 1;


/*
|--------------------------------------------------------------------------
| AJAX Mode
|--------------------------------------------------------------------------
*/

$isAjax =
    (isset($_GET['ajax']) && $_GET['ajax'] === '1')
    ||
    (isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
     strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');


/*
|--------------------------------------------------------------------------
| Normal Page Mode
|--------------------------------------------------------------------------
*/

if (!$isAjax) {

    include dirname(__DIR__) .
        '/includes/header.php';
}

?>

<?php if (!$isAjax): ?>

<div class="container py-5">

<?php endif; ?>


<div class="customer-account-wrapper">


    <!-- ==============================================================
         ACCOUNT HEADER
         ============================================================== -->

    <div class="customer-account-header">

        <div class="customer-avatar">

            <?= e(
                strtoupper(
                    substr(
                        (string) $user['name'],
                        0,
                        1
                    )
                )
            ) ?>

        </div>

        <div class="customer-account-heading">

            <h2>
                My Account
            </h2>

            <p>
                Welcome,
                <strong>
                    <?= e($user['name']) ?>
                </strong>
            </p>

        </div>

    </div>


    <!-- ==============================================================
         ACCOUNT NAVIGATION
         ============================================================== -->

    <div class="customer-account-navigation">


        <!-- PROFILE -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'profile'
            ) ?>"
            data-account-section="profile">

            <span class="account-nav-icon">
                👤
            </span>

            <span>
                Profile
            </span>

        </button>


        <!-- PROFILE SETTINGS -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'settings'
            ) ?>"
            data-account-section="settings">

            <span class="account-nav-icon">
                ⚙️
            </span>

            <span>
                Profile Settings
            </span>

        </button>


        <!-- ORDERS -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'orders'
            ) ?>"
            data-account-section="orders">

            <span class="account-nav-icon">
                📦
            </span>

            <span>
                My Orders
            </span>

            <?php if ($orderCount > 0): ?>

                <span class="account-badge">
                    <?= $orderCount ?>
                </span>

            <?php endif; ?>

        </button>


        <!-- CART -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'cart'
            ) ?>"
            data-account-section="cart">

            <span class="account-nav-icon">
                🛒
            </span>

            <span>
                My Cart
            </span>

            <?php if ($cartCount > 0): ?>

                <span class="account-badge">
                    <?= $cartCount ?>
                </span>

            <?php endif; ?>

        </button>


        <!-- ADDRESS -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'address'
            ) ?>"
            data-account-section="address">

            <span class="account-nav-icon">
                📍
            </span>

            <span>
                Address & Phone
            </span>

        </button>


        <!-- PASSWORD -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'password'
            ) ?>"
            data-account-section="password">

            <span class="account-nav-icon">
                🔑
            </span>

            <span>
                Change Password
            </span>

        </button>


        <!-- EMAIL VERIFICATION -->

        <button
            type="button"
            class="account-nav-item<?= account_active(
                $section,
                'verification'
            ) ?>"
            data-account-section="verification">

            <span class="account-nav-icon">
                ✉️
            </span>

            <span>
                Email Verification
            </span>

            <?php if ($emailVerified): ?>

                <span class="account-status verified">
                    Verified
                </span>

            <?php else: ?>

                <span class="account-status pending">
                    Pending
                </span>

            <?php endif; ?>

        </button>


        <!-- LOGOUT -->

        <button
            type="button"
            class="account-nav-item account-logout"
            data-account-action="logout">

            <span class="account-nav-icon">
                ↪
            </span>

            <span>
                Logout
            </span>

        </button>

    </div>


    <!-- ==============================================================
         ACCOUNT CONTENT
         ============================================================== -->

    <div
        id="customerAccountContent"
        class="customer-account-content">


        <?php if ($section === 'profile'): ?>


            <!-- ======================================================
                 PROFILE
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <div>

                        <span class="account-section-eyebrow">
                            PERSONAL INFORMATION
                        </span>

                        <h3>
                            My Profile
                        </h3>

                        <p>
                            Manage your customer information.
                        </p>

                    </div>

                </div>


                <div class="account-profile-card">

                    <div class="profile-avatar-large">

                        <?= e(
                            strtoupper(
                                substr(
                                    (string) $user['name'],
                                    0,
                                    1
                                )
                            )
                        ) ?>

                    </div>


                    <div class="profile-main">

                        <h4>
                            <?= e($user['name']) ?>
                        </h4>

                        <p>
                            <?= e($user['email']) ?>
                        </p>


                        <?php if ($emailVerified): ?>

                            <span class="verification-label verified">
                                ✓ Email verified
                            </span>

                        <?php else: ?>

                            <span class="verification-label pending">
                                ! Email not verified
                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="account-information-grid">


                    <div class="account-information-item">

                        <span class="information-label">
                            Full Name
                        </span>

                        <strong>
                            <?= e($user['name']) ?>
                        </strong>

                    </div>


                    <div class="account-information-item">

                        <span class="information-label">
                            Email Address
                        </span>

                        <strong>
                            <?= e($user['email']) ?>
                        </strong>

                    </div>


                    <div class="account-information-item">

                        <span class="information-label">
                            Phone Number
                        </span>

                        <strong>
                            <?= e(
                                $user['phone'] ?: 'Not added'
                            ) ?>
                        </strong>

                    </div>


                    <div class="account-information-item">

                        <span class="information-label">
                            Account Created
                        </span>

                        <strong>

                            <?php

                            if (!empty($user['created_at'])) {

                                echo e(
                                    date(
                                        'd F Y',
                                        strtotime(
                                            (string)
                                            $user['created_at']
                                        )
                                    )
                                );

                            } else {

                                echo '—';

                            }

                            ?>

                        </strong>

                    </div>

                </div>


                <button
                    type="button"
                    class="account-primary-button"
                    data-account-section="address">

                    Edit Address & Phone

                </button>

            </div>


        <?php elseif ($section === 'settings'): ?>


            <!-- ======================================================
                 PROFILE SETTINGS
                 ====================================================== -->

            <div class="account-section profile-settings-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        ACCOUNT SECURITY
                    </span>

                    <h3>
                        Profile Settings
                    </h3>

                    <p>
                        Manage your password, phone number and email address.
                    </p>

                </div>


                <!-- CHANGE PASSWORD -->

                <div class="account-card profile-settings-card">

                    <div class="profile-settings-card-heading">

                        <div class="profile-settings-icon" aria-hidden="true">
                            🔐
                        </div>

                        <div>
                            <h4>Change Password</h4>
                            <p>Use your current password to create a new secure password.</p>
                        </div>

                    </div>

                    <form
                        class="account-form"
                        method="post"
                        action="<?= e(BASE_URL) ?>/customer/password.php"
                        data-account-form="password">

                        <?= csrf_field() ?>

                        <div class="account-form-group">
                            <label for="settings_current_password">Current Password</label>
                            <input
                                type="password"
                                id="settings_current_password"
                                name="current_password"
                                autocomplete="current-password"
                                required>
                        </div>

                        <div class="account-form-group">
                            <label for="settings_new_password">New Password</label>
                            <input
                                type="password"
                                id="settings_new_password"
                                name="new_password"
                                minlength="8"
                                maxlength="255"
                                autocomplete="new-password"
                                required>
                            <small class="account-form-help">At least 8 characters, including a letter and a number.</small>
                        </div>

                        <div class="account-form-group">
                            <label for="settings_confirm_password">Confirm New Password</label>
                            <input
                                type="password"
                                id="settings_confirm_password"
                                name="confirm_password"
                                minlength="8"
                                maxlength="255"
                                autocomplete="new-password"
                                required>
                        </div>

                        <button type="submit" class="account-primary-button">
                            Change Password
                        </button>

                    </form>

                </div>


                <!-- CHANGE PHONE -->

                <div class="account-card profile-settings-card">

                    <div class="profile-settings-card-heading">

                        <div class="profile-settings-icon" aria-hidden="true">
                            📱
                        </div>

                        <div>
                            <h4>Change Phone Number</h4>
                            <p>Update the phone number used for customer contact and delivery.</p>
                        </div>

                    </div>

                    <form
                        class="account-form"
                        method="post"
                        action="<?= e(BASE_URL) ?>/customer/profile.php"
                        data-account-form="profile">

                        <?= csrf_field() ?>

                        <div class="account-form-group">
                            <label for="settings_phone">New Phone Number</label>
                            <input
                                type="tel"
                                id="settings_phone"
                                name="phone"
                                value="<?= e($user['phone'] ?? '') ?>"
                                placeholder="e.g. 082 123 4567"
                                maxlength="30"
                                autocomplete="tel"
                                required>
                            <small class="account-form-help">Use a valid South African or international phone format.</small>
                        </div>

                        <input type="hidden" name="address" value="<?= e($user['address'] ?? '') ?>">

                        <button type="submit" class="account-primary-button">
                            Save Phone Number
                        </button>

                    </form>

                </div>


                <!-- CHANGE EMAIL -->

                <div class="account-card profile-settings-card">

                    <div class="profile-settings-card-heading">

                        <div class="profile-settings-icon" aria-hidden="true">
                            ✉️
                        </div>

                        <div>
                            <h4>Change Email Address</h4>
                            <p>
                                A verification code is sent to the new email.
                                Your existing email stays unchanged until verification succeeds.
                            </p>
                        </div>

                    </div>

                    <form
                        id="emailChangeRequestForm"
                        class="account-form"
                        method="post"
                        action="<?= e(BASE_URL) ?>/customer/send_email_change_otp.php"
                        data-account-form="email-change-request">

                        <?= csrf_field() ?>

                        <div class="account-form-group">
                            <label for="settings_current_email">Current Email</label>
                            <input
                                type="email"
                                id="settings_current_email"
                                value="<?= e($user['email'] ?? '') ?>"
                                readonly
                                aria-readonly="true">
                        </div>

                        <div class="account-form-group">
                            <label for="settings_new_email">New Email Address</label>
                            <input
                                type="email"
                                id="settings_new_email"
                                name="new_email"
                                maxlength="190"
                                autocomplete="email"
                                placeholder="Enter your new email address"
                                required>
                        </div>

                        <button
                            type="submit"
                            class="account-primary-button"
                            data-email-change-send>
                            Send Verification Code
                        </button>

                    </form>


                    <form
                        id="emailChangeVerifyForm"
                        class="account-form email-change-verify-form"
                        method="post"
                        action="<?= e(BASE_URL) ?>/customer/verify_email_change_otp.php"
                        data-account-form="email-change-verify"
                        hidden>

                        <?= csrf_field() ?>

                        <div class="email-change-code-panel">

                            <strong>Enter your verification code</strong>

                            <p>
                                Check the new email inbox for the 6-digit code.
                                The code expires in 10 minutes and can only be used once.
                            </p>

                        </div>

                        <div class="account-form-group">
                            <label for="settings_email_otp">Verification Code</label>
                            <input
                                type="text"
                                id="settings_email_otp"
                                name="otp"
                                inputmode="numeric"
                                pattern="[0-9]{6}"
                                minlength="6"
                                maxlength="6"
                                autocomplete="one-time-code"
                                placeholder="000000"
                                required>
                        </div>

                        <button type="submit" class="account-primary-button">
                            Verify & Change Email
                        </button>

                    </form>

                </div>


                <!-- SECURITY STATUS -->

                <div class="account-card profile-settings-security">

                    <div class="profile-settings-security-title">
                        <span aria-hidden="true">🛡️</span>
                        Security
                    </div>

                    <ul>
                        <li>Verification codes expire after 10 minutes.</li>
                        <li>Each code can be used only once.</li>
                        <li>OTP codes are stored as secure password hashes.</li>
                        <li>Repeated OTP requests and failed attempts are rate-limited.</li>
                    </ul>

                </div>

            </div>


        <?php elseif ($section === 'orders'): ?>


            <!-- ======================================================
                 ORDERS
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        ORDER HISTORY
                    </span>

                    <h3>
                        My Orders
                    </h3>

                    <p>
                        View your previous Square Furniture orders.
                    </p>

                </div>


                <?php

                $stmt = $conn->prepare("
                    SELECT
                        id,
                        total,
                        status,
                        payment_ref,
                        created_at
                    FROM orders
                    WHERE user_id = ?
                    ORDER BY created_at DESC, id DESC
                ");

                $stmt->bind_param(
                    'i',
                    $userId
                );

                $stmt->execute();

                $ordersResult =
                    $stmt->get_result();

                ?>


                <?php if ($ordersResult->num_rows === 0): ?>


                    <div class="account-empty-state">

                        <div class="empty-icon">
                            📦
                        </div>

                        <h4>
                            No orders yet
                        </h4>

                        <p>
                            Your completed and current
                            orders will appear here.
                        </p>

                        <a
                            href="<?= e(BASE_URL) ?>/products.php"
                            class="account-primary-button">

                            Browse Products

                        </a>

                    </div>


                <?php else: ?>


                    <div class="account-orders-list">


                        <?php while (
                            $order =
                                $ordersResult->fetch_assoc()
                        ): ?>


                            <?php

                            $status = strtolower(
                                (string)
                                ($order['status'] ?? 'pending')
                            );

                            $statusClass =
                                preg_replace(
                                    '/[^a-z0-9_-]/',
                                    '',
                                    $status
                                );

                            ?>


                            <div class="account-order-card">


                                <div class="order-card-top">

                                    <div>

                                        <span class="order-label">
                                            Order
                                        </span>

                                        <strong>
                                            #<?= (int) $order['id'] ?>
                                        </strong>

                                    </div>


                                    <span
                                        class="order-status <?= e(
                                            $statusClass
                                        ) ?>">

                                        <?= e(
                                            ucfirst($status)
                                        ) ?>

                                    </span>

                                </div>


                                <div class="order-card-details">


                                    <div>

                                        <span>
                                            Date
                                        </span>

                                        <strong>

                                            <?php

                                            echo !empty(
                                                $order['created_at']
                                            )
                                                ? e(
                                                    date(
                                                        'd M Y',
                                                        strtotime(
                                                            (string)
                                                            $order['created_at']
                                                        )
                                                    )
                                                )
                                                : '—';

                                            ?>

                                        </strong>

                                    </div>


                                    <div>

                                        <span>
                                            Total
                                        </span>

                                        <strong>
                                            R
                                            <?= number_format(
                                                (float)
                                                $order['total'],
                                                2
                                            ) ?>
                                        </strong>

                                    </div>


                                    <div>

                                        <span>
                                            Payment
                                        </span>

                                        <strong>

                                            <?= !empty(
                                                $order['payment_ref']
                                            )
                                                ? 'Paid'
                                                : 'Pending' ?>

                                        </strong>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    class="account-secondary-button"
                                    data-order-id="<?= (int) $order['id'] ?>"
                                    data-account-section="order_details">

                                    View Order

                                </button>

                            </div>


                        <?php endwhile; ?>


                    </div>


                <?php endif; ?>


                <?php
                $stmt->close();
                ?>

            </div>


        <?php elseif ($section === 'cart'): ?>


            <!-- ======================================================
                 CART
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        SHOPPING BAG
                    </span>

                    <h3>
                        My Cart
                    </h3>

                    <p>
                        Review and manage products in your
                        shopping cart.
                    </p>

                </div>


                <?php

                $cart =
                    $_SESSION['cart'] ?? [];

                ?>


                <?php if (empty($cart)): ?>


                    <div class="account-empty-state">

                        <div class="empty-icon">
                            🛒
                        </div>

                        <h4>
                            Your cart is empty
                        </h4>

                        <p>
                            Add furniture to your cart
                            and it will appear here.
                        </p>

                        <a
                            href="<?= e(BASE_URL) ?>/products.php"
                            class="account-primary-button">

                            Continue Shopping

                        </a>

                    </div>


                <?php else: ?>


                    <div class="account-cart-list">


                        <?php

                        $cartTotal = 0;

                        foreach (
                            $cart
                            as $productId =>
                            $quantity
                        ):

                            $productId =
                                (int) $productId;

                            $quantity =
                                max(
                                    1,
                                    (int) $quantity
                                );


                            $stmt =
                                $conn->prepare("
                                    SELECT
                                        id,
                                        name,
                                        price,
                                        image,
                                        stock,
                                        status
                                    FROM products
                                    WHERE id = ?
                                    LIMIT 1
                                ");

                            $stmt->bind_param(
                                'i',
                                $productId
                            );

                            $stmt->execute();

                            $product =
                                $stmt
                                    ->get_result()
                                    ->fetch_assoc();

                            $stmt->close();


                            if (!$product) {
                                continue;
                            }


                            /*
                            |--------------------------------------------------
                            | Do not display inactive products in account cart
                            |--------------------------------------------------
                            */

                            if (
                                isset($product['status']) &&
                                $product['status'] !== 'active'
                            ) {
                                continue;
                            }


                            $lineTotal =
                                (float)
                                $product['price']
                                * $quantity;

                            $cartTotal +=
                                $lineTotal;


                            $image =
                                trim(
                                    (string)
                                    ($product['image'] ?? '')
                                );

                        ?>


                            <div
                                class="account-cart-item"
                                data-cart-product="<?= $productId ?>">


                                <div class="cart-product-image">

                                    <?php if ($image !== ''): ?>

                                        <img
                                            src="<?= e(
                                                BASE_URL .
                                                '/' .
                                                ltrim(
                                                    $image,
                                                    '/'
                                                )
                                            ) ?>"
                                            alt="<?= e(
                                                $product['name']
                                            ) ?>">

                                    <?php else: ?>

                                        <div class="cart-no-image">
                                            🛋️
                                        </div>

                                    <?php endif; ?>

                                </div>


                                <div class="cart-product-information">

                                    <h4>
                                        <?= e(
                                            $product['name']
                                        ) ?>
                                    </h4>


                                    <span>
                                        R
                                        <?= number_format(
                                            (float)
                                            $product['price'],
                                            2
                                        ) ?>
                                    </span>


                                    <div class="cart-quantity">


                                        <button
                                            type="button"
                                            class="cart-quantity-button"
                                            data-cart-action="decrease"
                                            data-product-id="<?= $productId ?>">

                                            −

                                        </button>


                                        <span>
                                            <?= $quantity ?>
                                        </span>


                                        <button
                                            type="button"
                                            class="cart-quantity-button"
                                            data-cart-action="increase"
                                            data-product-id="<?= $productId ?>">

                                            +

                                        </button>

                                    </div>

                                </div>


                                <div class="cart-product-actions">

                                    <strong>
                                        R
                                        <?= number_format(
                                            $lineTotal,
                                            2
                                        ) ?>
                                    </strong>


                                    <button
                                        type="button"
                                        class="cart-remove-button"
                                        data-cart-remove="<?= $productId ?>"
                                        aria-label="Remove product">

                                        Remove

                                    </button>

                                </div>

                            </div>


                        <?php endforeach; ?>


                        <div class="account-cart-total">

                            <span>
                                Cart Total
                            </span>

                            <strong>
                                R
                                <?= number_format(
                                    $cartTotal,
                                    2
                                ) ?>
                            </strong>

                        </div>


                        <a
                            href="<?= e(BASE_URL) ?>/checkout/index.php"
                            class="account-checkout-button">

                            Proceed to Checkout

                        </a>

                    </div>


                <?php endif; ?>

            </div>


        <?php elseif ($section === 'address'): ?>


            <!-- ======================================================
                 ADDRESS & PHONE
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        CONTACT DETAILS
                    </span>

                    <h3>
                        Address & Phone
                    </h3>

                    <p>
                        Keep your delivery and contact
                        information up to date.
                    </p>

                </div>


                <!--
                IMPORTANT:
                data-account-form="profile" is required.

                customer-account.js looks for:
                form.dataset.accountForm

                This prevents the browser from navigating
                directly to customer/profile.php.
                -->

                <form
                    id="customerAddressForm"
                    class="account-form"
                    method="post"
                    action="<?= e(BASE_URL) ?>/customer/profile.php"
                    data-account-form="profile">


                    <?= csrf_field() ?>


                    <div class="account-form-group">

                        <label for="account_phone">
                            Phone Number
                        </label>

                        <input
                            type="tel"
                            id="account_phone"
                            name="phone"
                            class="account-form-control"
                            value="<?= e(
                                $user['phone'] ?? ''
                            ) ?>"
                            placeholder="e.g. 082 123 4567"
                            maxlength="30"
                            autocomplete="tel">

                    </div>


                    <div class="account-form-group">

                        <label for="account_address">
                            Delivery Address
                        </label>

                        <textarea
                            id="account_address"
                            name="address"
                            class="account-form-control"
                            rows="5"
                            maxlength="1000"
                            placeholder="Enter your delivery address"><?= e(
                                $user['address'] ?? ''
                            ) ?></textarea>

                    </div>


                    <button
                        type="submit"
                        class="account-primary-button">

                        Save Contact Details

                    </button>

                </form>

            </div>


        <?php elseif ($section === 'password'): ?>


            <!-- ======================================================
                 PASSWORD
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        ACCOUNT SECURITY
                    </span>

                    <h3>
                        Change Password
                    </h3>

                    <p>
                        Choose a strong password that
                        you do not use elsewhere.
                    </p>

                </div>


                <form
                    id="customerPasswordForm"
                    class="account-form"
                    method="post"
                    action="<?= e(BASE_URL) ?>/customer/password.php"
                    data-account-form="password">


                    <?= csrf_field() ?>


                    <div class="account-form-group">

                        <label for="current_password">
                            Current Password
                        </label>

                        <input
                            type="password"
                            id="current_password"
                            name="current_password"
                            class="account-form-control"
                            required
                            autocomplete="current-password">

                    </div>


                    <div class="account-form-group">

                        <label for="new_password">
                            New Password
                        </label>

                        <input
                            type="password"
                            id="new_password"
                            name="new_password"
                            class="account-form-control"
                            required
                            minlength="8"
                            autocomplete="new-password">

                    </div>


                    <div class="account-form-group">

                        <label for="confirm_password">
                            Confirm New Password
                        </label>

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            class="account-form-control"
                            required
                            minlength="8"
                            autocomplete="new-password">

                    </div>


                    <div class="password-requirements">

                        <strong>
                            Password requirements
                        </strong>

                        <ul>

                            <li>
                                At least 8 characters
                            </li>

                            <li>
                                Use a combination
                                of letters and numbers
                            </li>

                            <li>
                                Do not reuse your old password
                            </li>

                        </ul>

                    </div>


                    <button
                        type="submit"
                        class="account-primary-button">

                        Update Password

                    </button>

                </form>

            </div>


        <?php elseif ($section === 'verification'): ?>


            <!-- ======================================================
                 EMAIL VERIFICATION
                 ====================================================== -->

            <div class="account-section">

                <div class="account-section-header">

                    <span class="account-section-eyebrow">
                        ACCOUNT SECURITY
                    </span>

                    <h3>
                        Email Verification
                    </h3>

                    <p>
                        Verify your email address to
                        help secure your account.
                    </p>

                </div>


                <?php if ($emailVerified): ?>


                    <div class="verification-success-card">

                        <div class="verification-large-icon">
                            ✓
                        </div>

                        <h4>
                            Email Verified
                        </h4>

                        <p>
                            Your email address
                            <strong>
                                <?= e($user['email']) ?>
                            </strong>
                            has been verified.
                        </p>

                    </div>


                <?php else: ?>


                    <div class="verification-pending-card">

                        <div class="verification-large-icon">
                            ✉️
                        </div>

                        <h4>
                            Verify Your Email
                        </h4>

                        <p>
                            We will send a six-digit
                            verification code to:
                        </p>

                        <strong>
                            <?= e($user['email']) ?>
                        </strong>


                        <button
                            type="button"
                            id="sendVerificationOtp"
                            class="account-primary-button"
                            data-account-action="send-otp">

                            Send Verification Code

                        </button>


                        <div
                            id="otpVerificationArea"
                            class="otp-verification-area"
                            style="display:none;">


                            <label for="verification_otp">
                                Enter Verification Code
                            </label>


                            <input
                                type="text"
                                id="verification_otp"
                                name="otp"
                                class="account-form-control otp-input"
                                maxlength="6"
                                inputmode="numeric"
                                autocomplete="one-time-code"
                                placeholder="000000">


                            <button
                                type="button"
                                id="verifyEmailOtp"
                                class="account-primary-button"
                                data-account-action="verify-otp">

                                Verify Email

                            </button>


                            <p
                                id="otpMessage"
                                class="otp-message">
                            </p>

                        </div>

                    </div>


                <?php endif; ?>

            </div>


        <?php endif; ?>


    </div>

</div>


<?php if (!$isAjax): ?>

</div>

<?php
include dirname(__DIR__) .
    '/includes/footer.php';
?>

<?php endif; ?>