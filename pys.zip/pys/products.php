<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/init.php';

$page_title = 'Shop Furniture - ' . APP_NAME;

/*
|--------------------------------------------------------------------------
| Search / Filters
|--------------------------------------------------------------------------
*/

$q = trim((string) ($_GET['q'] ?? ''));
$cat = trim((string) ($_GET['category'] ?? ''));
$sort = (string) ($_GET['sort'] ?? 'newest');

/*
|--------------------------------------------------------------------------
| Furniture Categories
|--------------------------------------------------------------------------
*/

$allowedCats = [
    'Dining',
    'Living',
    'Bedroom',
    'Kitchen',
    'Out-door',
    'Office'
];

if (!in_array($cat, $allowedCats, true)) {
    $cat = '';
}

/*
|--------------------------------------------------------------------------
| Sorting
|--------------------------------------------------------------------------
*/

$sortMap = [
    'newest'    => 'id DESC',
    'price_low' => 'price ASC',
    'price_high'=> 'price DESC',
    'name'      => 'name ASC'
];

$order = $sortMap[$sort] ?? $sortMap['newest'];

/*
|--------------------------------------------------------------------------
| Product Query
|--------------------------------------------------------------------------
*/

$sql = "SELECT * FROM products WHERE status = 'active'";

$types = '';
$vals = [];

if ($q !== '') {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";

    $types .= 'ss';

    $like = "%{$q}%";

    $vals[] = $like;
    $vals[] = $like;
}

if ($cat !== '') {
    $sql .= " AND category = ?";

    $types .= 's';
    $vals[] = $cat;
}

$sql .= " ORDER BY {$order}";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die('Unable to load products.');
}

if ($types !== '') {
    $stmt->bind_param($types, ...$vals);
}

$stmt->execute();

$res = $stmt->get_result();

/*
|--------------------------------------------------------------------------
| Page Header
|--------------------------------------------------------------------------
*/

include __DIR__ . '/includes/header.php';

?>

<style>
/* =========================================================
   PRODUCTS PAGE
========================================================= */

.shop-layout {
    display: grid;
    grid-template-columns: 220px minmax(0, 1fr);
    gap: 30px;
    padding: 35px 0 60px;
}

.shop-sidebar {
    background: #fff;
    border: 1px solid #e8e4dc;
    border-radius: 14px;
    padding: 22px;
    height: fit-content;
    position: sticky;
    top: 20px;
}

.shop-sidebar h4 {
    margin: 0 0 14px;
    font-size: 16px;
    font-weight: 700;
}

.shop-sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0 0 28px;
}

.shop-sidebar li {
    margin-bottom: 7px;
}

.shop-sidebar a {
    display: block;
    padding: 8px 10px;
    border-radius: 8px;
    color: inherit;
    text-decoration: none;
    transition: .2s ease;
}

.shop-sidebar a:hover {
    background: #f5f1e8;
}

.shop-sidebar p {
    margin: 8px 0;
    font-size: 14px;
    color: #555;
}

.shop-main {
    min-width: 0;
}

.shop-title {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 20px;
    margin-bottom: 20px;
}

.shop-title h1 {
    margin: 0 0 6px;
    font-size: clamp(28px, 4vw, 42px);
    line-height: 1.1;
}

.shop-title p {
    margin: 0;
    color: #777;
}

.view-all {
    white-space: nowrap;
    font-size: 14px;
    color: #777;
}

/* =========================================================
   SEARCH TOOLBAR
========================================================= */

.shop-toolbar {
    display: flex;
    gap: 10px;
    margin-bottom: 15px;
}

.shop-toolbar input,
.shop-toolbar select {
    height: 44px;
    border: 1px solid #ddd7cc;
    border-radius: 9px;
    background: #fff;
    padding: 0 13px;
    outline: none;
}

.shop-toolbar input {
    flex: 1;
    min-width: 0;
}

.shop-toolbar input:focus,
.shop-toolbar select:focus {
    border-color: #aaa;
}

.shop-toolbar button {
    border: 0;
    border-radius: 9px;
    padding: 0 20px;
    background: #171717;
    color: #fff;
    cursor: pointer;
    font-weight: 600;
}

.shop-toolbar button:hover {
    opacity: .9;
}

/* =========================================================
   FILTER BUTTONS
========================================================= */

.filter-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 24px;
}

.filter-chip {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 36px;
    padding: 0 15px;
    border: 1px solid #ddd7cc;
    border-radius: 999px;
    background: #fff;
    color: #333;
    text-decoration: none;
    font-size: 14px;
    transition: .2s ease;
}

.filter-chip:hover {
    background: #f4f0e7;
}

.filter-chip.active {
    background: #171717;
    color: #fff;
    border-color: #171717;
}

/* =========================================================
   PRODUCT GRID
========================================================= */

.product-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

.product-card {
    background: #fff;
    border: 1px solid #e8e4dc;
    border-radius: 13px;
    overflow: hidden;
    min-width: 0;
    transition: transform .2s ease, box-shadow .2s ease;
}

.product-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 28px rgba(0,0,0,.07);
}

.product-image-wrap {
    display: block;
    position: relative;
    aspect-ratio: 1 / .88;
    overflow: hidden;
    background: #f3f1ec;
}

.product-image-wrap img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
    transition: transform .35s ease;
}

.product-card:hover .product-image-wrap img {
    transform: scale(1.04);
}

.product-badge {
    position: absolute;
    top: 10px;
    left: 10px;
    background: #fff;
    color: #222;
    border-radius: 999px;
    padding: 5px 9px;
    font-size: 11px;
    font-weight: 700;
    box-shadow: 0 3px 10px rgba(0,0,0,.08);
}

.product-info {
    padding: 13px;
}

.product-category {
    color: #8a8174;
    text-transform: uppercase;
    letter-spacing: .06em;
    font-size: 10px;
    font-weight: 700;
    margin-bottom: 5px;
}

.product-name {
    font-size: 15px;
    font-weight: 700;
    line-height: 1.3;
    margin-bottom: 7px;
}

.product-price {
    font-size: 15px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
}

.product-stock {
    color: #18864b;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
}

/* =========================================================
   PRODUCT BUTTONS
========================================================= */

.product-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 7px;
    margin-top: 12px;
}

.product-actions a {
    min-height: 37px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    text-decoration: none;
    font-size: 12px;
    font-weight: 700;
    transition: .2s ease;
    text-align: center;
}

.btn-cart {
    background: #171717;
    color: #fff;
}

.btn-cart:hover {
    background: #333;
    color: #fff;
}

.btn-wa {
    background: #25D366;
    color: #fff;
}

.btn-wa:hover {
    background: #1db954;
    color: #fff;
}

/* =========================================================
   EMPTY STATE
========================================================= */

.empty-state {
    grid-column: 1 / -1;
    padding: 60px 20px;
    text-align: center;
    border: 1px dashed #d8d1c5;
    border-radius: 14px;
    background: #fff;
}

.empty-state h3 {
    margin-top: 0;
}

.empty-state p {
    color: #777;
}

.btn-yellow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    padding: 0 18px;
    border-radius: 8px;
    background: #171717;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 1100px) {
    .product-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}

@media (max-width: 850px) {
    .shop-layout {
        grid-template-columns: 1fr;
    }

    .shop-sidebar {
        position: static;
    }

    .shop-sidebar ul {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
    }

    .shop-sidebar li {
        margin: 0;
    }

    .shop-sidebar p {
        display: inline-block;
        margin-right: 12px;
    }

    .product-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 600px) {
    .shop-layout {
        padding-top: 20px;
    }

    .shop-title {
        align-items: flex-start;
        flex-direction: column;
        gap: 8px;
    }

    .shop-toolbar {
        flex-wrap: wrap;
    }

    .shop-toolbar input {
        flex-basis: 100%;
    }

    .shop-toolbar select {
        flex: 1;
    }

    .shop-toolbar button {
        height: 44px;
    }

    .product-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }

    .product-info {
        padding: 10px;
    }

    .product-name {
        font-size: 13px;
    }

    .product-price {
        font-size: 13px;
    }

    .product-actions {
        grid-template-columns: 1fr;
    }

    .product-actions a {
        min-height: 34px;
    }
}

@media (max-width: 380px) {
    .product-grid {
        grid-template-columns: 1fr;
    }

    .product-actions {
        grid-template-columns: 1fr 1fr;
    }
}
</style>

<div class="container">
  <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">


    <div class="shop-layout">

        <!-- =====================================================
             SIDEBAR
        ====================================================== -->

        <aside class="shop-sidebar">

            <h4>Departments</h4>

            <ul>

                <li>
                    <a href="<?= BASE_URL ?>/products.php">
                        All Furniture
                    </a>
                </li>

                <?php foreach ($allowedCats as $c): ?>

                    <li>
                        <a href="<?= BASE_URL ?>/products.php?category=<?= urlencode($c) ?>">
                            <?= e($c) ?>
                        </a>
                    </li>

                <?php endforeach; ?>

            </ul>

            <h4>Why shop with us?</h4>

            <p>✓ Quality furniture</p>
            <p>✓ South African delivery</p>
            <p>✓ Secure checkout</p>
            <p>✓ WhatsApp support</p>

        </aside>


        <!-- =====================================================
             MAIN SHOP
        ====================================================== -->

        <section class="shop-main">

            <div class="shop-title">

                <div>

                    <h1>Shop Furniture</h1>

                    <p>
                        Browse our collection and find something
                        beautiful for your home.
                    </p>

                </div>

                <?php if ($res): ?>

                    <span class="view-all">
                        <?= (int) $res->num_rows ?> products
                    </span>

                <?php endif; ?>

            </div>


            <!-- =================================================
                 SEARCH / SORT
            ================================================== -->

            <form
                class="shop-toolbar"
                method="get"
                action="<?= BASE_URL ?>/products.php"
            >

                <input
                    type="search"
                    name="q"
                    value="<?= e($q) ?>"
                    placeholder="Search furniture..."
                >

                <?php if ($cat !== ''): ?>

                    <input
                        type="hidden"
                        name="category"
                        value="<?= e($cat) ?>"
                    >

                <?php endif; ?>


                <select
                    name="sort"
                    aria-label="Sort products"
                >

                    <option
                        value="newest"
                        <?= $sort === 'newest' ? 'selected' : '' ?>
                    >
                        Sort: Newest
                    </option>

                    <option
                        value="price_low"
                        <?= $sort === 'price_low' ? 'selected' : '' ?>
                    >
                        Price: Low to high
                    </option>

                    <option
                        value="price_high"
                        <?= $sort === 'price_high' ? 'selected' : '' ?>
                    >
                        Price: High to low
                    </option>

                    <option
                        value="name"
                        <?= $sort === 'name' ? 'selected' : '' ?>
                    >
                        Name
                    </option>

                </select>


                <button type="submit">
                    Search
                </button>

            </form>


            <!-- =================================================
                 CATEGORY FILTERS
            ================================================== -->

            <div class="filter-chips">

                <a
                    class="filter-chip <?= $cat === '' ? 'active' : '' ?>"
                    href="<?= BASE_URL ?>/products.php"
                >
                    All
                </a>

                <?php foreach ($allowedCats as $c): ?>

                    <a
                        class="filter-chip <?= $cat === $c ? 'active' : '' ?>"
                        href="<?= BASE_URL ?>/products.php?category=<?= urlencode($c) ?>"
                    >
                        <?= e($c) ?>
                    </a>

                <?php endforeach; ?>

            </div>


            <!-- =================================================
                 PRODUCTS
            ================================================== -->

            <div class="product-grid">

                <?php if ($res && $res->num_rows): ?>

                    <?php while ($p = $res->fetch_assoc()): ?>

                        <?php

                        /*
                        |--------------------------------------------------------------------------
                        | Product Image
                        |--------------------------------------------------------------------------
                        */

                        $img = !empty($p['image'])
                            ? BASE_URL . '/' . ltrim($p['image'], '/')
                            : 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80';


                        /*
                        |--------------------------------------------------------------------------
                        | WhatsApp Message
                        |--------------------------------------------------------------------------
                        */

                        $msg =
                            "Hello PYS Furniture, "
                            . "I am interested in "
                            . $p['name']
                            . " (R "
                            . number_format((float) $p['price'], 2)
                            . "). "
                            . "Please provide more information.";


                        /*
                        |--------------------------------------------------------------------------
                        | PYS Furniture WhatsApp Number
                        |--------------------------------------------------------------------------
                        */

                        $wa =
                            'https://wa.me/27738373636?text='
                            . rawurlencode($msg);

                        ?>


                        <article class="product-card">

                            <!-- Product Image -->

                            <a
                                class="product-image-wrap"
                                href="<?= BASE_URL ?>/products.php?q=<?= urlencode($p['name']) ?>"
                            >

                                <img
                                    src="<?= e($img) ?>"
                                    alt="<?= e($p['name']) ?>"
                                    loading="lazy"
                                    onerror="this.src='https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=700&q=80'"
                                >

                                <?php if ((int) $p['stock'] > 0): ?>

                                    <span class="product-badge">
                                        Available
                                    </span>

                                <?php endif; ?>

                            </a>


                            <!-- Product Information -->

                            <div class="product-info">

                                <div class="product-category">
                                    <?= e($p['category']) ?>
                                </div>


                                <div class="product-name">
                                    <?= e($p['name']) ?>
                                </div>


                                <div class="product-price">

                                    <span>
                                        R <?= number_format((float) $p['price'], 2) ?>
                                    </span>


                                    <?php if ((int) $p['stock'] > 0): ?>

                                        <span class="product-stock">
                                            In stock
                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="product-stock"
                                            style="color:#b42318"
                                        >
                                            Out of stock
                                        </span>

                                    <?php endif; ?>

                                </div>


                                <!-- =================================================
                                     ACTION BUTTONS
                                ================================================== -->

                                <div class="product-actions">

                                    <?php if ((int) $p['stock'] > 0): ?>

                                        <a
                                            class="btn-cart"
                                            href="<?= BASE_URL ?>/add_to_cart.php?id=<?= (int) $p['id'] ?>"
                                        >
                                            Add to Cart
                                        </a>

                                    <?php endif; ?>


                                    <!-- PYS FURNITURE WHATSAPP -->

                                    <a
                                        class="btn-wa"
                                        href="<?= e($wa) ?>"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >
                                        WhatsApp
                                    </a>

                                </div>

                            </div>

                        </article>

                    <?php endwhile; ?>

                <?php else: ?>

                    <!-- =================================================
                         NO PRODUCTS
                    ================================================== -->

                    <div class="empty-state">

                        <h3>
                            No products found
                        </h3>

                        <p>
                            Try another search or choose a different
                            department.
                        </p>

                        <a
                            class="btn-yellow"
                            href="<?= BASE_URL ?>/products.php"
                        >
                            View all furniture
                        </a>

                    </div>

                <?php endif; ?>

            </div>

        </section>

    </div>

</div>

<?php

include __DIR__ . '/includes/footer.php';

?>