<?php
require_once '../includes/init.php';
$pfHost=PAYFAST_SANDBOX?'sandbox.payfast.co.za':'www.payfast.co.za';
$posted=file_get_contents('php://input');parse_str($posted,$data);
if(empty($data['pf_payment_id'])||empty($data['m_payment_id'])){http_response_code(400);exit;}
$req=curl_init('https://'.$pfHost.'/eng/query/validate');curl_setopt_array($req,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$posted,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>true,CURLOPT_SSL_VERIFYPEER=>true]);$response=curl_exec($req);$status=curl_getinfo($req,CURLINFO_HTTP_CODE);curl_close($req);
if($status!==200||stripos($response,'VALID')===false){http_response_code(400);exit;}
$orderId=(int)$data['m_payment_id'];$amount=(float)$data['amount_gross'];$stmt=$conn->prepare("SELECT total FROM orders WHERE id=?");$stmt->bind_param('i',$orderId);$stmt->execute();$o=$stmt->get_result()->fetch_assoc();
if(!$o||abs((float)$o['total']-$amount)>0.01){http_response_code(400);exit;}
if(($data['payment_status']??'')==='COMPLETE'){$stmt=$conn->prepare("UPDATE orders SET status='paid',payment_ref=? WHERE id=?");$ref=$data['pf_payment_id'];$stmt->bind_param('si',$ref,$orderId);$stmt->execute();}
http_response_code(200);
