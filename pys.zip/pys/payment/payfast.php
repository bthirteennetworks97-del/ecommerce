<?php
require_once '../includes/init.php';
if(!isset($_SESSION['user_id'],$_SESSION['pending_order'])) redirect('../cart.php');
$orderId=(int)$_SESSION['pending_order'];$stmt=$conn->prepare("SELECT * FROM orders WHERE id=? AND user_id=?");$uid=$_SESSION['user_id'];$stmt->bind_param('ii',$orderId,$uid);$stmt->execute();$order=$stmt->get_result()->fetch_assoc();if(!$order)redirect('../cart.php');
$endpoint=PAYFAST_SANDBOX?'https://sandbox.payfast.co.za/eng/process':'https://www.payfast.co.za/eng/process';
$return=BASE_URL.'/payment/success.php?order='.$orderId;$cancel=BASE_URL.'/payment/cancel.php?order='.$orderId;$notify=BASE_URL.'/payment/itn.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>Secure Payment</title><link rel="icon" type="image/png" href="../assets/img/favicon.png"><link rel="shortcut icon" href="../assets/img/favicon.png"></head><body style="font-family:Arial;text-align:center;padding:50px"><h2>Redirecting to PayFast...</h2><p>Order #<?=e((string)$orderId)?></p><form id="pf" action="<?=e($endpoint)?>" method="post">
<input type="hidden" name="merchant_id" value="<?=e(PAYFAST_MERCHANT_ID)?>"><input type="hidden" name="merchant_key" value="<?=e(PAYFAST_MERCHANT_KEY)?>">
<input type="hidden" name="return_url" value="<?=e($return)?>"><input type="hidden" name="cancel_url" value="<?=e($cancel)?>"><input type="hidden" name="notify_url" value="<?=e($notify)?>">
<input type="hidden" name="amount" value="<?=number_format((float)$order['total'],2,'.','')?>"><input type="hidden" name="item_name" value="Square Furniture Order #<?=e((string)$orderId)?>">
<button>Continue to PayFast</button></form><script>document.getElementById('pf').submit()</script></body></html>
