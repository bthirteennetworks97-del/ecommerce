<?php
declare(strict_types=1);

function e(?string $v): string {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">';
}
function verify_csrf(): void {
    $sessionToken = (string) ($_SESSION['csrf'] ?? '');
    $postedToken = (string) ($_POST['csrf'] ?? '');

    if ($postedToken === '') {
        $postedToken = (string) (
            $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''
        );
    }

    if (
        $sessionToken === '' ||
        $postedToken === '' ||
        !hash_equals($sessionToken, $postedToken)
    ) {
        http_response_code(419);
        exit('Invalid security token. Please refresh and try again.');
    }
}
function flash(string $type, string $message): void {
    $_SESSION['flash'][] = [$type, $message];
}
function flashes(): array {
    $x = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $x;
}
function cart_count(): int {
    return array_sum($_SESSION['cart'] ?? []);
}
function cart_total(mysqli $conn): float {
    $total = 0.0;
    foreach ($_SESSION['cart'] ?? [] as $id => $qty) {
        $stmt = $conn->prepare("SELECT price FROM products WHERE id=? AND status='active'");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $p = $stmt->get_result()->fetch_assoc();
        if ($p) $total += (float)$p['price'] * (int)$qty;
    }
    return $total;
}
function log_activity(mysqli $conn, ?int $userId, string $action): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt = $conn->prepare("INSERT INTO activity_logs(user_id,action,ip_address) VALUES(?,?,?)");
    $stmt->bind_param('iss', $userId, $action, $ip);
    $stmt->execute();
}

/**
 * Send a transactional email through Brevo's HTTPS API.
 *
 * Brevo uses POST https://api.brevo.com/v3/smtp/email with the API key
 * supplied in the `api-key` header.
 */
function send_brevo_email(
    string $toEmail,
    string $toName,
    string $subject,
    string $htmlContent,
    string $textContent = ''
): array {
    if (!defined('BREVO_API_KEY') || trim((string) BREVO_API_KEY) === '') {
        return [
            'success' => false,
            'message' => 'Brevo API key is not configured.'
        ];
    }

    if (!function_exists('curl_init')) {
        return [
            'success' => false,
            'message' => 'PHP cURL is not enabled on this server.'
        ];
    }

    $payload = [
        'sender' => [
            'name'  => BREVO_SENDER_NAME,
            'email' => BREVO_SENDER_EMAIL,
        ],
        'to' => [[
            'name'  => $toName,
            'email' => $toEmail,
        ]],
        'replyTo' => [
            'email' => BREVO_REPLY_TO,
        ],
        'subject' => $subject,
        'htmlContent' => $htmlContent,
        'textContent' => $textContent !== '' ? $textContent : strip_tags($htmlContent),
        'tags' => ['square-furniture', 'email-verification'],
    ];

    $ch = curl_init('https://api.brevo.com/v3/smtp/email');

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => [
            'accept: application/json',
            'api-key: ' . BREVO_API_KEY,
            'content-type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
    ]);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false) {
        return [
            'success' => false,
            'message' => 'Brevo connection failed: ' . $curlError,
        ];
    }

    $decoded = json_decode($response, true);

    if ($statusCode >= 200 && $statusCode < 300) {
        return [
            'success' => true,
            'message' => 'Verification email sent.',
            'message_id' => $decoded['messageId'] ?? null,
        ];
    }

    $detail = '';
    if (is_array($decoded)) {
        $detail = (string) ($decoded['message'] ?? $decoded['code'] ?? 'Brevo rejected the email request.');
    }

    return [
        'success' => false,
        'message' => 'Brevo email error (' . $statusCode . '): ' . $detail,
    ];
}

/**
 * Create the branded Square Furniture verification email.
 */
function square_furniture_verification_email(string $customerName, string $otp): array {
    $safeName = e($customerName !== '' ? $customerName : 'Customer');
    $safeOtp  = e($otp);

    $html = '<!doctype html><html><body style="margin:0;background:#f4f6f8;font-family:Arial,sans-serif;color:#18202b;">'
        . '<div style="max-width:620px;margin:30px auto;padding:0 16px;">'
        . '<div style="background:#172235;color:#fff;padding:24px 28px;border-radius:12px 12px 0 0;">'
        . '<div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.75;">Square Furniture Manufacture</div>'
        . '<h1 style="margin:8px 0 0;font-size:26px;">Verify your email</h1>'
        . '</div>'
        . '<div style="background:#fff;padding:30px 28px;border:1px solid #e1e5e9;border-top:0;border-radius:0 0 12px 12px;">'
        . '<p style="font-size:16px;">Hello ' . $safeName . ',</p>'
        . '<p style="font-size:14px;line-height:1.7;color:#5f6975;">Use the verification code below to confirm your email address and finish creating your Square Furniture customer account.</p>'
        . '<div style="margin:26px 0;text-align:center;">'
        . '<div style="display:inline-block;padding:17px 26px;border:2px dashed #ffb000;border-radius:10px;background:#fffaf0;font-size:34px;font-weight:800;letter-spacing:9px;color:#172235;">' . $safeOtp . '</div>'
        . '</div>'
        . '<p style="font-size:13px;color:#68717d;">This code expires in <strong>10 minutes</strong>. For your security, never share it with anyone.</p>'
        . '<p style="font-size:13px;color:#68717d;">If you did not start this registration, you can safely ignore this email.</p>'
        . '<hr style="border:0;border-top:1px solid #edf0f2;margin:24px 0;">'
        . '<p style="margin:0;font-size:12px;color:#8a939d;">Square Furniture Manufacture · ' . e(ADMIN_EMAIL) . '</p>'
        . '</div></div></body></html>';

    $text = "Hello " . ($customerName !== '' ? $customerName : 'Customer') . ",\n\n"
        . "Your Square Furniture verification code is: " . $otp . "\n\n"
        . "This code expires in 10 minutes. Do not share it with anyone.\n\n"
        . "If you did not start this registration, ignore this email.\n\n"
        . "Square Furniture Manufacture";

    return [
        'html' => $html,
        'text' => $text,
    ];
}

/**
 * Branded OTP email used during customer login and legacy account verification.
 */
function square_furniture_login_otp_email(string $customerName, string $otp, string $purpose = 'login'): array {
    $safeName = e($customerName !== '' ? $customerName : 'Customer');
    $safeOtp = e($otp);
    $isLogin = $purpose === 'login';
    $heading = $isLogin ? 'Verify your login' : 'Verify your email address';
    $intro = $isLogin
        ? 'Use the code below to finish signing in to your Square Furniture customer account.'
        : 'Your account was created without a completed email verification. Use the code below to verify your email before access is granted.';

    $html = '<!doctype html><html><body style="margin:0;background:#f4f6f8;font-family:Arial,sans-serif;color:#18202b;">'
        . '<div style="max-width:620px;margin:30px auto;padding:0 16px;">'
        . '<div style="background:#172235;color:#fff;padding:24px 28px;border-radius:12px 12px 0 0;">'
        . '<div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.75;">Square Furniture Manufacture</div>'
        . '<h1 style="margin:8px 0 0;font-size:26px;">' . $heading . '</h1>'
        . '</div>'
        . '<div style="background:#fff;padding:30px 28px;border:1px solid #e1e5e9;border-top:0;border-radius:0 0 12px 12px;">'
        . '<p style="font-size:16px;">Hello ' . $safeName . ',</p>'
        . '<p style="font-size:14px;line-height:1.7;color:#5f6975;">' . $intro . '</p>'
        . '<div style="margin:26px 0;text-align:center;">'
        . '<div style="display:inline-block;padding:17px 26px;border:2px dashed #ffb000;border-radius:10px;background:#fffaf0;font-size:34px;font-weight:800;letter-spacing:9px;color:#172235;">' . $safeOtp . '</div>'
        . '</div>'
        . '<p style="font-size:13px;color:#68717d;">This code expires in <strong>10 minutes</strong>, allows a maximum of 5 attempts, and can only be used once.</p>'
        . '<p style="font-size:13px;color:#68717d;">If you did not request this code, you can safely ignore this email.</p>'
        . '<hr style="border:0;border-top:1px solid #edf0f2;margin:24px 0;">'
        . '<p style="margin:0;font-size:12px;color:#8a939d;">Square Furniture Manufacture · ' . e(ADMIN_EMAIL) . '</p>'
        . '</div></div></body></html>';

    $text = "Hello " . ($customerName !== '' ? $customerName : 'Customer') . ",\n\n"
        . ($isLogin ? "Your Square Furniture login verification code is: " : "Your Square Furniture email verification code is: ") . $otp . "\n\n"
        . "This code expires in 10 minutes and can only be used once.\n\n"
        . "If you did not request this code, ignore this email.\n\n"
        . "Square Furniture Manufacture";

    return ['html' => $html, 'text' => $text];
}


/**
 * Branded email used when a customer requests to change their email address.
 */
function square_furniture_email_change_otp(string $customerName, string $otp, string $newEmail): array {
    $safeName = e($customerName !== '' ? $customerName : 'Customer');
    $safeOtp = e($otp);
    $safeEmail = e($newEmail);

    $html = '<!doctype html><html><body style="margin:0;background:#f4f6f8;font-family:Arial,sans-serif;color:#18202b;">'
        . '<div style="max-width:620px;margin:30px auto;padding:0 16px;">'
        . '<div style="background:#172235;color:#fff;padding:24px 28px;border-radius:12px 12px 0 0;">'
        . '<div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.75;">Square Furniture Manufacture</div>'
        . '<h1 style="margin:8px 0 0;font-size:26px;">Confirm your new email</h1>'
        . '</div>'
        . '<div style="background:#fff;padding:30px 28px;border:1px solid #e1e5e9;border-top:0;border-radius:0 0 12px 12px;">'
        . '<p style="font-size:16px;">Hello ' . $safeName . ',</p>'
        . '<p style="font-size:14px;line-height:1.7;color:#5f6975;">A request was made to change the email address on your Square Furniture account to <strong>' . $safeEmail . '</strong>.</p>'
        . '<div style="margin:26px 0;text-align:center;">'
        . '<div style="display:inline-block;padding:17px 26px;border:2px dashed #9a7651;border-radius:10px;background:#faf7f2;font-size:34px;font-weight:800;letter-spacing:9px;color:#172235;">' . $safeOtp . '</div>'
        . '</div>'
        . '<p style="font-size:13px;color:#68717d;">This code expires in <strong>10 minutes</strong> and can only be used once.</p>'
        . '<p style="font-size:13px;color:#68717d;">If you did not request this change, ignore this email. Your existing email address remains unchanged.</p>'
        . '<hr style="border:0;border-top:1px solid #edf0f2;margin:24px 0;">'
        . '<p style="margin:0;font-size:12px;color:#8a939d;">Square Furniture Manufacture</p>'
        . '</div></div></body></html>';

    $text = "Hello " . ($customerName !== '' ? $customerName : 'Customer') . ",\n\n"
        . "Your Square Furniture email-change verification code is: " . $otp . "\n\n"
        . "This code expires in 10 minutes and can only be used once.\n"
        . "The new email address is: " . $newEmail . "\n\n"
        . "If you did not request this change, ignore this email. Your existing email address remains unchanged.\n\n"
        . "Square Furniture Manufacture";

    return ['html' => $html, 'text' => $text];
}

