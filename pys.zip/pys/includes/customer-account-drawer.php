<?php
declare(strict_types=1);

/**
 * Square Furniture
 * Customer Account Drawer
 *
 * File:
 * /includes/customer-account-drawer.php
 *
 * Purpose:
 * - Creates the right-side animated customer account drawer.
 * - Keeps customers on the homepage.
 * - Content is loaded dynamically through customer-account.js.
 * - Works with customer-account.css.
 */

if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config/config.php';
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$is_logged_in = isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0 && (($_SESSION['role'] ?? 'customer') !== 'admin');

// Never load an administrator's identity or account data into the customer-side drawer.
if ($is_logged_in) {
    try {
        require_once __DIR__ . '/init.php';
        $drawerUid = (int) $_SESSION['user_id'];
        $drawerCheck = $conn->prepare("SELECT role,is_admin,status FROM users WHERE id=? LIMIT 1");
        $drawerCheck->bind_param('i', $drawerUid);
        $drawerCheck->execute();
        $drawerUser = $drawerCheck->get_result()->fetch_assoc();
        $drawerCheck->close();
        if (!$drawerUser || ($drawerUser['role'] ?? '') === 'admin' || (int)($drawerUser['is_admin'] ?? 0) === 1 || ($drawerUser['status'] ?? '') !== 'active') {
            $is_logged_in = false;
        }
    } catch (Throwable $e) {
        $is_logged_in = false;
    }
}

$csrf_token = $_SESSION['csrf_token'] ?? '';
?>

<!-- =========================================================
     CUSTOMER ACCOUNT DRAWER
========================================================= -->

<div
    id="customerAccountOverlay"
    class="customer-account-overlay"
    data-account-overlay
    aria-hidden="true"
></div>


<aside
    id="customerAccountDrawer"
    class="customer-account-drawer"
    data-account-drawer
    aria-hidden="true"
    aria-labelledby="customerAccountDrawerTitle"
    role="dialog"
    tabindex="-1"
>

    <!-- =====================================================
         DRAWER HEADER
    ====================================================== -->

    <header class="customer-account-header">

        <div class="customer-account-header-left">

            <button
                type="button"
                class="customer-account-back"
                data-account-back
                aria-label="Back"
                title="Back"
                hidden
            >
                <span aria-hidden="true">←</span>
            </button>

            <div class="customer-account-brand">

                <img class="customer-account-brand-logo" src="<?= BASE_URL ?>/assets/img/pys-furniture-logo.png" alt="PYS Furniture">

                <div>
                    <h2
                        id="customerAccountDrawerTitle"
                        class="customer-account-title"
                    >
                        My Account
                    </h2>

                    <p class="customer-account-subtitle">
                        Square Furniture
                    </p>
                </div>

            </div>

        </div>


        <button
            type="button"
            class="customer-account-close"
            data-close-customer-account
            aria-label="Close account"
            title="Close"
        >
            <span aria-hidden="true">×</span>
        </button>

    </header>


    <!-- =====================================================
         DRAWER CONTENT
    ====================================================== -->

    <div
        id="customerAccountContent"
        class="customer-account-content"
        data-account-content
    >

        <?php if ($is_logged_in): ?>

            <!-- Initial loading state.
                 customer-account.js replaces this content
                 with customer/account.php. -->

            <div
                class="customer-account-loading"
                data-account-loading
                role="status"
                aria-live="polite"
            >

                <div class="customer-account-spinner"></div>

                <p>
                    Loading your account…
                </p>

            </div>

        <?php else: ?>

            <!-- =================================================
                 GUEST LOGIN STATE
            ================================================== -->

            <section class="customer-account-guest">

                <div class="customer-account-guest-icon">
                    <span aria-hidden="true">♙</span>
                </div>

                <h3>
                    Welcome to Square Furniture
                </h3>

                <p>
                    Sign in to view your orders, manage your profile,
                    update your address and manage your shopping cart.
                </p>

                <div class="customer-account-guest-actions">

                    <a
                        href="<?= BASE_URL ?>/login.php"
                        class="customer-account-btn customer-account-btn-primary"
                    >
                        Sign In
                    </a>

                    <a
                        href="<?= BASE_URL ?>/register.php"
                        class="customer-account-btn customer-account-btn-secondary"
                    >
                        Create Account
                    </a>

                </div>

            </section>

        <?php endif; ?>

    </div>


    <!-- =====================================================
         DRAWER FOOTER
    ====================================================== -->

    <footer class="customer-account-footer">

        <div class="customer-account-footer-inner">

            <span>
                <?= e(APP_NAME ?? 'Square Furniture Manufacture') ?>
            </span>

            <span class="customer-account-footer-separator">
                •
            </span>

            <span>
                Secure Account
            </span>

        </div>

    </footer>

</aside>


<!-- =========================================================
     CUSTOMER ACCOUNT TOAST NOTIFICATIONS
========================================================= -->

<div
    id="customerAccountToastContainer"
    class="customer-account-toast-container"
    data-account-toast-container
    aria-live="polite"
    aria-atomic="true"
></div>


<!-- =========================================================
     GLOBAL ACCOUNT CONFIG
========================================================= -->

<script>
    window.SQUARE_FURNITURE_ACCOUNT = {
        baseUrl: <?= json_encode(BASE_URL, JSON_UNESCAPED_SLASHES) ?>,
        csrfToken: <?= json_encode($csrf_token) ?>,
        loggedIn: <?= $is_logged_in ? 'true' : 'false' ?>,

        endpoints: {
            account: <?= json_encode(BASE_URL . '/customer/account.php', JSON_UNESCAPED_SLASHES) ?>,
            profile: <?= json_encode(BASE_URL . '/customer/profile.php', JSON_UNESCAPED_SLASHES) ?>,
            sendEmailChangeOtp: <?= json_encode(BASE_URL . '/customer/send_email_change_otp.php', JSON_UNESCAPED_SLASHES) ?>,
            verifyEmailChangeOtp: <?= json_encode(BASE_URL . '/customer/verify_email_change_otp.php', JSON_UNESCAPED_SLASHES) ?>,
            orders: <?= json_encode(BASE_URL . '/customer/orders.php', JSON_UNESCAPED_SLASHES) ?>,
            orderDetails: <?= json_encode(BASE_URL . '/customer/order_details.php', JSON_UNESCAPED_SLASHES) ?>,
            cart: <?= json_encode(BASE_URL . '/customer/cart.php', JSON_UNESCAPED_SLASHES) ?>,
            cartRemove: <?= json_encode(BASE_URL . '/customer/cart_remove.php', JSON_UNESCAPED_SLASHES) ?>,
            cartUpdate: <?= json_encode(BASE_URL . '/customer/cart_update.php', JSON_UNESCAPED_SLASHES) ?>,
            password: <?= json_encode(BASE_URL . '/customer/password.php', JSON_UNESCAPED_SLASHES) ?>,
            sendOtp: <?= json_encode(BASE_URL . '/customer/send_otp.php', JSON_UNESCAPED_SLASHES) ?>,
            verifyOtp: <?= json_encode(BASE_URL . '/customer/verify_otp.php', JSON_UNESCAPED_SLASHES) ?>,
            logout: <?= json_encode(BASE_URL . '/customer/logout.php', JSON_UNESCAPED_SLASHES) ?>
        }
    };

    /*
     * Backward compatibility with customer-account.js.
     */
    window.SQUARE_FURNITURE_BASE_URL =
        <?= json_encode(BASE_URL, JSON_UNESCAPED_SLASHES) ?>;

    window.SQUARE_FURNITURE_CSRF_TOKEN =
        <?= json_encode($csrf_token) ?>;
</script>