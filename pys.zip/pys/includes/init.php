<?php
declare(strict_types=1);
session_set_cookie_params([
    'httponly'=>true,
    'secure'=>isset($_SERVER['HTTPS']),
    'samesite'=>'Lax'
]);
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

$composerAutoload = __DIR__ . '/../vendor/autoload.php';
if (is_file($composerAutoload)) {
    require_once $composerAutoload;
}

// Fallback keeps the site functional before `composer install` is run.
require_once __DIR__ . '/functions.php';
