<?php
declare(strict_types=1);
require_once __DIR__ . '/init.php';

$is_customer_logged_in = !empty($_SESSION['user_id']) && (($_SESSION['role'] ?? 'customer') !== 'admin');
$customer_name = '';

if ($is_customer_logged_in) {
    try {
        $uid = (int)$_SESSION['user_id'];
        $stmt = $conn->prepare("SELECT name,status,role,is_admin FROM users WHERE id=? LIMIT 1");
        $stmt->bind_param('i',$uid);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($u) {
            // Admin accounts must never be presented as customer accounts on the storefront.
            if (($u['role'] ?? '') === 'admin' || (int)($u['is_admin'] ?? 0) === 1) {
                $is_customer_logged_in = false;
            } else {
                $customer_name=(string)$u['name'];
                if (($u['status'] ?? 'active') !== 'active') $is_customer_logged_in=false;
            }
        }
    } catch(Throwable $e) {}
}
$current_cart_count=0;
try {$current_cart_count=(int)cart_count();} catch(Throwable $e) {}
$header_csrf_token=$_SESSION['csrf_token'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title ?? APP_NAME) ?></title>
<link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/img/logo.jpg">
<link rel="shortcut icon" href="<?= BASE_URL ?>/assets/img/logo.jpg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer-account.css">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

</head>
<body>
<header class="site-header">
  <div class="utility-bar">
    <div class="utility-inner">
      <span>South African furniture · Built for everyday living</span>
      <span>Need help? &nbsp;|&nbsp; Secure checkout</span>
    </div>
  </div>
  <div class="top-nav">
    <div class="nav-inner">
      <a class="brand" href="<?= BASE_URL ?>/index.php" aria-label="<?= e(APP_NAME) ?>">
        <img class="brand-logo" src="<?= BASE_URL ?>/assets/img/logo.jpg" alt="PYS Furniture">
        <span class="brand-copy"><strong>Square</strong><small>Furniture Manufacture</small></span>
      </a>

      <form class="global-search" action="<?= BASE_URL ?>/products.php" method="get">
        <select name="category" aria-label="Furniture category">
          <option value="">All</option>
          <?php foreach (['Bedroom','Kitchen','Living','Out-door','Dining','Office'] as $searchCat): ?>
            <option value="<?= e($searchCat) ?>" <?= (($_GET['category'] ?? '') === $searchCat) ? 'selected' : '' ?>><?= e($searchCat) ?></option>
          <?php endforeach; ?>
        </select>
        <input type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search furniture: sofas, beds, tables..." aria-label="Search furniture">
        <button type="submit" aria-label="Search">⌕</button>
      </form>

      <nav class="desktop-nav" aria-label="Main navigation">
        <a href="<?= BASE_URL ?>/index.php">Home</a>
        <a href="<?= BASE_URL ?>/products.php">Shop</a>
        <a href="<?= BASE_URL ?>/contact.php">Contact</a>
        <?php if ($is_customer_logged_in): ?>
          <button type="button" class="nav-account" data-open-customer-account data-account-section="profile"><?= e($customer_name ?: 'Account') ?></button>
          <button type="button" class="nav-account" data-open-customer-account data-account-section="orders">Orders</button>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/auth/login.php">Login</a>
        <?php endif; ?>
        <a class="cart-link" href="<?= BASE_URL ?>/cart.php">
          <span class="cart-icon">🛒</span> Cart
          <b id="headerCartCount" data-cart-count><?= $current_cart_count ?></b>
        </a>
      </nav>

      <button class="mobile-menu-toggle" type="button" aria-label="Open menu" data-mobile-menu>☰</button>
    </div>

    <div class="mobile-nav" data-mobile-nav>
      <a href="<?= BASE_URL ?>/index.php">Home</a>
      <a href="<?= BASE_URL ?>/products.php">Shop</a>
      <a href="<?= BASE_URL ?>/contact.php">Contact</a>
      <?php if ($is_customer_logged_in): ?>
        <button type="button" data-open-customer-account data-account-section="profile">My Account</button>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/auth/login.php">Login</a>
        <a href="<?= BASE_URL ?>/auth/register.php">Create Account</a>
      <?php endif; ?>
      <a href="<?= BASE_URL ?>/cart.php">Cart (<?= $current_cart_count ?>)</a>
    </div>
  </div>
</header>

<?php include __DIR__ . '/customer-account-drawer.php'; ?>

<main>
<?php foreach (flashes() as [$type,$msg]): ?>
  <div class="container"><div class="site-alert alert-<?= e($type) ?>"><?= e($msg) ?></div></div>
<?php endforeach; ?>
