</main>
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-brand">
      <a class="brand footer-brand-link" href="<?= BASE_URL ?>/index.php">
        <img class="brand-logo" src="<?= BASE_URL ?>/assets/img/logo.jpg" alt="PYS Furniture">
        <span class="brand-copy"><strong>Square</strong><small>Furniture Manufacture</small></span>
      </a>
      <p>Quality furniture designed for comfortable, beautiful South African homes.</p>
    </div>
    <div>
      <h4>Quick Links</h4>
      <a href="<?= BASE_URL ?>/index.php">Home</a>
      <a href="<?= BASE_URL ?>/products.php">Shop Furniture</a>
      <a href="<?= BASE_URL ?>/contact.php">Contact</a>
      <a href="<?= BASE_URL ?>/cart.php">Shopping Cart</a>
    </div>
    <div>
      <h4>Categories</h4>
      <a href="<?= BASE_URL ?>/products.php?category=Bedroom">Bedroom</a>
      <a href="<?= BASE_URL ?>/products.php?category=Kitchen">Kitchen</a>
      <a href="<?= BASE_URL ?>/products.php?category=Living%20Room">Living Room</a>
      <a href="<?= BASE_URL ?>/products.php?category=Outdoor">Outdoor</a>
    </div>
    <div>
      <h4>Contact</h4>
      <p>Lindelani · Stanger · Durban<br>South Africa</p>


<div class="contact-icons">

    <!-- Phone -->
    <a
        href="tel:+27738373636"
        class="phone"
        aria-label="Call PYS Furniture"
    >
        <i class="fas fa-phone"></i>
    </a>

    <!-- WhatsApp -->
    <a
        href="https://wa.me/27738373636"
        class="whatsapp"
        target="_blank"
        rel="noopener"
        aria-label="WhatsApp PYS Furniture"
    >
        <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Facebook -->
    <a
        href="https://www.facebook.com/"
        class="facebook"
        target="_blank"
        rel="noopener"
        aria-label="Facebook"
    >
        <i class="fab fa-facebook-f"></i>
    </a>

    <!-- Email -->
    <a
        href="mailto:info@pysfurniture.co.za"
        class="email"
        aria-label="Email PYS Furniture"
    >
        <i class="fas fa-envelope"></i>
    </a>

</div>

    </div>
  </div>
  <div class="container footer-bottom">
    <span>© <?= date('Y') ?> Square Furniture Manufacture. All rights reserved.</span>
    <span>Secure shopping · South Africa</span>
  </div>
</footer>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
<script src="<?= BASE_URL ?>/assets/js/customer-account.js" defer></script>
</body>
</html>
