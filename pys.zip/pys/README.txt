SQUARE FURNITURE MANUFACTURE - FULL FIXED PHP E-COMMERCE

STACK
- PHP 8+
- MySQL/MariaDB
- Bootstrap 5
- PayFast integration with ITN verification
- Secure password hashing
- CSRF protection
- Prepared SQL statements
- Login brute-force throttling
- Admin/staff roles
- Activity logging
- Product management
- Cart, Buy Now and checkout
- Delivery address capture
- Contact messages
- JSON product API

INSTALLATION
1. Copy this folder into XAMPP htdocs as: pys
2. Create/import database using database.sql in phpMyAdmin.
3. Edit config/config.php with your hosting database credentials.
4. Open: http://localhost/pys/
5. Admin login:
   Email: admin@squarefurniture.co.za
   Password: Admin@123
6. If the SQL hash does not work on a particular server, open /setup_admin.php once.
   It uses PHP password_hash() to reset the admin password. DELETE setup_admin.php immediately afterward.
7. For PayFast, put your own merchant ID, merchant key and passphrase in config/config.php.
   PAYFAST_SANDBOX=true is for testing. Set false only when your production credentials and URLs are configured.
8. Make sure cURL is enabled in PHP because the PayFast ITN verifier uses cURL.

IMPORTANT SECURITY
- Change the default admin password immediately after first login.
- Delete setup_admin.php after use.
- Do not commit config/config.php to public source control.
- Use HTTPS in production.
- PayFast payment is NOT considered paid from the browser return page; payment status is updated only after ITN verification.
- Replace placeholder contact details and PayFast credentials before launch.

============================================================
BREVO EMAIL VERIFICATION
============================================================

Customer registration now uses a two-step verification flow:

1. Customer enters name, email, phone, address and password.
2. The website stores the registration temporarily in pending_customer_registrations.
3. A secure 6-digit code is sent through Brevo's transactional email API.
4. The customer enters the code.
5. ONLY after the correct code is entered is the row created in users.
6. email_verified is saved as 1 and the customer is logged in.

IMPORTANT: A real Brevo API key is intentionally NOT included in this ZIP.

Open:
    config/config.php

Set:
    define('BREVO_API_KEY', 'YOUR_BREVO_API_KEY');
    define('BREVO_SENDER_EMAIL', 'admin@squarefurniture.co.za');
    define('BREVO_SENDER_NAME', APP_NAME);
    define('BREVO_REPLY_TO', ADMIN_EMAIL);

The sender email must be a verified sender/domain in Brevo.

For a NEW database, import database.sql. It includes the registration and login OTP tables.
For an EXISTING database, run pending_registration_migration.sql and login_otp_migration.sql once.
The old email_verification_otps table remains for the customer-account verification flow.

Brevo API endpoint used by the application:
    POST https://api.brevo.com/v3/smtp/email

The integration sends transactional HTML + plain-text email and does not use
PHP mail().

============================================================


COMPOSER / PHP 8.2
------------------
This project includes composer.json. The current email integration calls Brevo's HTTPS API with PHP cURL, so PHPMailer is not required.

From a terminal, run inside C:\xampp\htdocs\pys:
    composer install

Composer checks PHP >= 8.2 and the cURL, JSON, and MySQLi extensions, then creates vendor/autoload.php.
The site also has a direct-include fallback, so it can run before Composer is installed.
No composer.lock is included because Composer must generate it in your local environment when you run composer install.

DATABASE NOTE
--------------
database.sql is intended for a clean database import. It contains a starter admin account and demo products, but no customer records, personal contact submissions, or login-history entries. Change the starter admin password immediately.


PROFILE SETTINGS UPDATE
-----------------------
Added customer Profile Settings with:
- Change Password using password_hash/password_verify.
- Change Phone Number with validation.
- Change Email Address using a 6-digit OTP sent to the NEW email.
- New email is committed only after OTP verification.
- OTPs expire after 10 minutes, are one-time-use, hashed, and rate-limited.
- Existing email remains unchanged if verification fails or expires.

DATABASE:
For an existing installation, run:
email_change_profile_settings_migration.sql

For a fresh installation, database.sql already includes the email_change OTP purpose.
