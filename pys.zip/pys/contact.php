<?php
declare(strict_types=1);
require_once __DIR__.'/config/config.php';
require_once __DIR__.'/includes/init.php';
$page_title='Contact - '.APP_NAME;

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $name=trim((string)($_POST['name']??''));
    $email=trim((string)($_POST['email']??''));
    $phone=trim((string)($_POST['phone']??''));
    $address=trim((string)($_POST['address']??''));
    $message=trim((string)($_POST['message']??''));
    if($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || $message===''){
        flash('danger','Please enter your name, a valid email address and a message.');
    }else{
        $stmt=$conn->prepare("INSERT INTO contact_messages(name,email,phone,address,message) VALUES(?,?,?,?,?)");
        $stmt->bind_param('sssss',$name,$email,$phone,$address,$message);
        if($stmt->execute()) flash('success','Your message was received. We will respond as soon as possible.');
        else flash('danger','We could not send your message. Please try again.');
        $stmt->close();
        redirect('contact.php');
    }
}
include __DIR__.'/includes/header.php';
?>
<div class="container">
  <section class="form-shell">
    <h1>Contact Square Furniture</h1>
    <p>Have a question about a product, delivery or an order? Send us a message.</p>
    <form method="post">
      <?= csrf_field() ?>
      <div class="form-field"><label>Name</label><input name="name" required></div>
      <div class="form-field"><label>Email</label><input type="email" name="email" required></div>
      <div class="form-field"><label>Phone</label><input name="phone"></div>
      <div class="form-field"><label>Address</label><input name="address"></div>
      <div class="form-field"><label>Message</label><textarea name="message" required></textarea></div>
      <button class="btn-yellow" type="submit">Send Message</button>
    </form>
  </section>
</div>
<?php include __DIR__.'/includes/footer.php'; ?>
