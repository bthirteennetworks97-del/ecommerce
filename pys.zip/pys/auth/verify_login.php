<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('login.php');
}

verify_csrf();

$userId = (int) ($_SESSION['login_otp_user_id'] ?? 0);
$email = strtolower(trim((string) ($_SESSION['login_otp_email'] ?? '')));
$purpose = (string) ($_SESSION['login_otp_purpose'] ?? 'login');
$action = (string) ($_POST['action'] ?? 'verify');

if ($userId < 1 || !filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($purpose, ['login', 'email_verify'], true)) {
    unset($_SESSION['login_otp_user_id'], $_SESSION['login_otp_email'], $_SESSION['login_otp_purpose'], $_SESSION['login_otp_last_sent']);
    flash('warning', 'Your verification session has expired. Please log in again.');
    redirect('login.php');
}

$stmt = $conn->prepare("SELECT id, name, email, email_verified, role, status FROM users WHERE id = ? AND email = ? LIMIT 1");
$stmt->bind_param('is', $userId, $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || ($user['status'] ?? '') !== 'active') {
    unset($_SESSION['login_otp_user_id'], $_SESSION['login_otp_email'], $_SESSION['login_otp_purpose'], $_SESSION['login_otp_last_sent']);
    flash('danger', 'Your account could not be verified. Please log in again.');
    redirect('login.php');
}

if ($action === 'resend') {
    $lastSent = (int) ($_SESSION['login_otp_last_sent'] ?? 0);
    $elapsed = time() - $lastSent;
    if ($lastSent > 0 && $elapsed < 60) {
        flash('warning', 'Please wait ' . (60 - $elapsed) . ' seconds before requesting another code.');
        redirect('login.php');
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM auth_otps WHERE user_id = ? AND purpose = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->bind_param('is', $userId, $purpose);
    $stmt->execute();
    $countRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ((int) ($countRow['c'] ?? 0) >= 5) {
        flash('danger', 'Too many verification codes have been requested. Please try again later.');
        redirect('login.php');
    }

    $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE user_id = ? AND purpose = ? AND used_at IS NULL");
    $stmt->bind_param('is', $userId, $purpose);
    $stmt->execute();
    $stmt->close();

    $otp = (string) random_int(100000, 999999);
    $otpHash = password_hash($otp, PASSWORD_DEFAULT);
    if ($otpHash === false) {
        flash('danger', 'We could not prepare your verification code. Please try again.');
        redirect('login.php');
    }

    $expiresAt = date('Y-m-d H:i:s', time() + 600);
    $stmt = $conn->prepare("INSERT INTO auth_otps (user_id, email, purpose, otp_hash, expires_at, attempts) VALUES (?, ?, ?, ?, ?, 0)");
    $stmt->bind_param('issss', $userId, $email, $purpose, $otpHash, $expiresAt);
    $stmt->execute();
    $otpId = (int) $conn->insert_id;
    $stmt->close();

    $emailContent = square_furniture_login_otp_email((string) $user['name'], $otp, $purpose);
    $mail = send_brevo_email($email, (string) $user['name'], APP_NAME . ' - Your verification code', $emailContent['html'], $emailContent['text']);
    if (!$mail['success']) {
        $stmt = $conn->prepare("DELETE FROM auth_otps WHERE id = ? LIMIT 1");
        $stmt->bind_param('i', $otpId);
        $stmt->execute();
        $stmt->close();
        flash('danger', 'The verification email could not be sent. Please try again later.');
        redirect('login.php');
    }

    $_SESSION['login_otp_last_sent'] = time();
    flash('success', 'A new verification code has been sent.');
    redirect('login.php');
}

$otp = trim((string) ($_POST['otp'] ?? ''));
if (!preg_match('/^\d{6}$/', $otp)) {
    flash('danger', 'Enter the 6-digit verification code.');
    redirect('login.php');
}

$stmt = $conn->prepare("SELECT id, otp_hash, expires_at, attempts FROM auth_otps WHERE user_id = ? AND purpose = ? AND used_at IS NULL ORDER BY id DESC LIMIT 1");
$stmt->bind_param('is', $userId, $purpose);
$stmt->execute();
$record = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$record) {
    flash('danger', 'No active verification code was found. Please request a new code.');
    redirect('login.php');
}

$otpId = (int) $record['id'];
$attempts = (int) $record['attempts'];
if ($attempts >= 5) {
    $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $otpId);
    $stmt->execute();
    $stmt->close();
    flash('danger', 'Too many incorrect attempts. Please request a new code.');
    redirect('login.php');
}

$expiry = strtotime((string) $record['expires_at']);
if ($expiry === false || $expiry < time()) {
    $stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $otpId);
    $stmt->execute();
    $stmt->close();
    flash('warning', 'That verification code has expired. Please request a new code.');
    redirect('login.php');
}

if (!password_verify($otp, (string) $record['otp_hash'])) {
    $newAttempts = $attempts + 1;
    $stmt = $conn->prepare("UPDATE auth_otps SET attempts = ? WHERE id = ? LIMIT 1");
    $stmt->bind_param('ii', $newAttempts, $otpId);
    $stmt->execute();
    $stmt->close();
    flash('danger', 'That code is not correct. Please try again.');
    redirect('login.php');
}

/* One-time use: invalidate before creating the authenticated session. */
$stmt = $conn->prepare("UPDATE auth_otps SET used_at = NOW() WHERE id = ? AND used_at IS NULL LIMIT 1");
$stmt->bind_param('i', $otpId);
$stmt->execute();
$claimed = $stmt->affected_rows === 1;
$stmt->close();

if (!$claimed) {
    flash('danger', 'That verification code has already been used.');
    redirect('login.php');
}

if ($purpose === 'email_verify') {
    $stmt = $conn->prepare("UPDATE users SET email_verified = 1 WHERE id = ? LIMIT 1");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();
}

session_regenerate_id(true);
$_SESSION['user_id'] = $userId;
$_SESSION['role'] = (string) $user['role'];

$stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $userId);
$stmt->execute();
$stmt->close();

try {
    log_activity($conn, $userId, $purpose === 'login' ? 'Login OTP verified' : 'Email verified during login');
} catch (Throwable $e) {
    // Authentication must not fail because activity logging failed.
}

unset($_SESSION['login_otp_user_id'], $_SESSION['login_otp_email'], $_SESSION['login_otp_purpose'], $_SESSION['login_otp_last_sent']);
flash('success', $purpose === 'login' ? 'Login verified successfully. Welcome back!' : 'Your email has been verified and you are now logged in.');
redirect('../index.php');
