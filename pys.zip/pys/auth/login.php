<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

/* If a login OTP is already pending, show the verification screen. */
$loginOtpPending = !empty($_SESSION['login_otp_user_id'])
    && !empty($_SESSION['login_otp_email']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $pass  = (string) ($_POST['password'] ?? '');
    $ip    = $_SERVER['REMOTE_ADDR'] ?? '';

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('danger', 'Please enter a valid email address.');
        redirect('login.php');
    }

    if ($pass === '') {
        flash('danger', 'Please enter your password.');
        redirect('login.php');
    }

    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS c
         FROM login_attempts
         WHERE email = ?
         AND success = 0
         AND created_at > NOW() - INTERVAL 15 MINUTE"
    );
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $attemptRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ((int) ($attemptRow['c'] ?? 0) >= 5) {
        flash('danger', 'Too many failed login attempts. Please try again later.');
        redirect('login.php');
    }

    $stmt = $conn->prepare(
        "SELECT * FROM users WHERE email = ? LIMIT 1"
    );
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $u = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $ok = false;

    if ($u && isset($u['password'])) {
        $ok = password_verify($pass, (string) $u['password']);
    }

    $stmt = $conn->prepare(
        "INSERT INTO login_attempts (email, ip_address, success)
         VALUES (?, ?, ?)"
    );
    $success = $ok ? 1 : 0;
    $stmt->bind_param('ssi', $email, $ip, $success);
    $stmt->execute();
    $stmt->close();

    if (!$ok || !$u || ($u['status'] ?? '') !== 'active') {
        flash('danger', 'Invalid email or password.');
        redirect('login.php');
    }

    $userId = (int) $u['id'];
    $purpose = ((int) ($u['email_verified'] ?? 0) === 1)
        ? 'login'
        : 'email_verify';

    /* Start a fresh pre-authentication session. */
    session_regenerate_id(true);

    unset($_SESSION['user_id'], $_SESSION['role']);

    $_SESSION['login_otp_user_id'] = $userId;
    $_SESSION['login_otp_email'] = $email;
    $_SESSION['login_otp_purpose'] = $purpose;
    $_SESSION['login_otp_last_sent'] = 0;

    /* Invalidate older codes for this user/purpose. */
    $stmt = $conn->prepare(
        "UPDATE auth_otps
         SET used_at = NOW()
         WHERE user_id = ?
         AND purpose = 'login'
         AND used_at IS NULL"
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare(
        "UPDATE auth_otps
         SET used_at = NOW()
         WHERE user_id = ?
         AND purpose = 'email_verify'
         AND used_at IS NULL"
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    $otp = (string) random_int(100000, 999999);
    $otpHash = password_hash($otp, PASSWORD_DEFAULT);

    if ($otpHash === false) {
        unset(
            $_SESSION['login_otp_user_id'],
            $_SESSION['login_otp_email'],
            $_SESSION['login_otp_purpose']
        );

        flash('danger', 'We could not prepare your verification code. Please try again.');
        redirect('login.php');
    }

    $expiresAt = date('Y-m-d H:i:s', time() + 600);

    $stmt = $conn->prepare(
        "INSERT INTO auth_otps
         (user_id, email, purpose, otp_hash, expires_at, attempts)
         VALUES (?, ?, ?, ?, ?, 0)"
    );
    $stmt->bind_param(
        'issss',
        $userId,
        $email,
        $purpose,
        $otpHash,
        $expiresAt
    );
    $stmt->execute();
    $otpId = (int) $conn->insert_id;
    $stmt->close();

    $emailContent = square_furniture_login_otp_email(
        (string) $u['name'],
        $otp,
        $purpose
    );

    $mail = send_brevo_email(
        $email,
        (string) $u['name'],
        APP_NAME . ' - Your login verification code',
        $emailContent['html'],
        $emailContent['text']
    );

    if (!$mail['success']) {
        $stmt = $conn->prepare(
            "DELETE FROM auth_otps WHERE id = ? LIMIT 1"
        );
        $stmt->bind_param('i', $otpId);
        $stmt->execute();
        $stmt->close();

        unset(
            $_SESSION['login_otp_user_id'],
            $_SESSION['login_otp_email'],
            $_SESSION['login_otp_purpose']
        );

        flash(
            'danger',
            'We could not send your verification email. Please check your Brevo configuration and try again.'
        );
        redirect('login.php');
    }

    $_SESSION['login_otp_last_sent'] = time();

    flash(
        'success',
        $purpose === 'login'
            ? 'A 6-digit login verification code has been sent to your email.'
            : 'Your account email has not been verified. We sent a code to verify it before you can log in.'
    );

    redirect('login.php');
}

$page_title = 'Login - ' . APP_NAME;
include __DIR__ . '/../includes/header.php';
?>


<style>
/* Square Furniture Manufacture — Login page styling */
.auth-page{
  min-height:calc(100vh - 82px);
  display:flex;
  align-items:center;
  justify-content:center;
  padding:44px 20px 60px;
  background:
    radial-gradient(circle at 10% 10%,rgba(255,176,0,.10),transparent 28%),
    linear-gradient(135deg,#f7f8fa 0%,#eef1f5 100%);
  box-sizing:border-box;
}
.auth-page *,
.auth-page *::before,
.auth-page *::after{box-sizing:border-box}

.auth-card{
  width:min(1060px,100%);
  display:grid;
  grid-template-columns:42% 58%;
  background:#fff;
  border:1px solid #e1e5e9;
  border-radius:18px;
  overflow:hidden;
  box-shadow:0 25px 70px rgba(16,27,42,.14);
}

.auth-brand-panel{
  position:relative;
  padding:54px 46px;
  background:
    linear-gradient(145deg,rgba(10,18,31,.98),rgba(23,34,53,.96)),
    #172235;
  color:#fff;
  min-height:650px;
  display:flex;
  flex-direction:column;
  justify-content:center;
  overflow:hidden;
}
.auth-brand-panel::before{
  content:"";
  position:absolute;
  width:420px;height:420px;
  left:-280px;top:-230px;
  border:1px solid rgba(255,255,255,.07);
  border-radius:50%;
  box-shadow:
    0 0 0 65px rgba(255,255,255,.025),
    0 0 0 130px rgba(255,255,255,.018);
}
.auth-brand-panel::after{
  content:"";
  position:absolute;
  width:330px;height:330px;
  right:-150px;bottom:-145px;
  border:1px solid rgba(255,255,255,.11);
  border-radius:50%;
  box-shadow:
    0 0 0 55px rgba(255,255,255,.025),
    0 0 0 110px rgba(255,255,255,.018);
}

.auth-logo{
  position:relative;
  z-index:1;
  width:54px;height:54px;
  border-radius:11px;
  display:grid;
  place-items:center;
  background:linear-gradient(135deg,#fff,#cbd2da);
  color:#172235;
  font-weight:900;
  font-size:18px;
  margin-bottom:30px;
  box-shadow:0 10px 30px rgba(0,0,0,.18);
}

.auth-kicker{
  position:relative;
  z-index:1;
  font-size:9px;
  letter-spacing:2px;
  font-weight:800;
  color:#ffca38;
  margin-bottom:13px;
}
.auth-brand-panel h1{
  position:relative;
  z-index:1;
  font-family:Inter,Arial,sans-serif;
  font-size:39px;
  line-height:1.05;
  letter-spacing:-1.1px;
  margin:0 0 17px;
  max-width:360px;
}
.auth-brand-panel>p{
  position:relative;
  z-index:1;
  font-size:13px;
  line-height:1.8;
  color:#c9d0d9;
  max-width:390px;
  margin:0;
}
.auth-benefits{
  position:relative;
  z-index:1;
  display:flex;
  flex-direction:column;
  gap:11px;
  margin-top:34px;
  color:#eef2f6;
  font-size:11px;
}
.auth-benefits span{display:block}

.auth-form-panel{
  padding:52px 54px;
  display:flex;
  flex-direction:column;
  justify-content:center;
  background:#fff;
}
.auth-step-label{
  font-size:9px;
  font-weight:900;
  letter-spacing:1.7px;
  color:#9a6a00;
  margin-bottom:8px;
}
.auth-form-panel h2{
  font-size:29px;
  line-height:1.15;
  margin:0 0 8px;
  color:#172235;
  letter-spacing:-.6px;
}
.auth-intro{
  font-size:12px;
  color:#697481;
  line-height:1.7;
  margin:0 0 25px;
  max-width:560px;
}
.auth-field{margin-bottom:14px}
.auth-field label,
.verification-form label{
  display:block;
  font-size:10px;
  font-weight:800;
  color:#2b3440;
  margin-bottom:6px;
}
.auth-field input,
.verification-form input{
  width:100%;
  height:45px;
  border:1px solid #d8dde3;
  border-radius:7px;
  background:#fbfcfd;
  padding:0 13px;
  font-size:12px;
  color:#18202b;
  outline:none;
  transition:border-color .18s,box-shadow .18s,background .18s;
  font-family:inherit;
}
.auth-field input::placeholder,
.verification-form input::placeholder{color:#a0a8b1}
.auth-field input:focus,
.verification-form input:focus{
  background:#fff;
  border-color:#8d98a5;
  box-shadow:0 0 0 3px rgba(23,34,53,.07);
}
.auth-primary{
  width:100%;
  min-height:47px;
  border:0;
  border-radius:7px;
  background:#172235;
  color:#fff;
  font-size:12px;
  font-weight:800;
  cursor:pointer;
  transition:background .18s,transform .18s,box-shadow .18s;
  box-shadow:0 8px 20px rgba(23,34,53,.16);
  font-family:inherit;
}
.auth-primary:hover{
  background:#0f1826;
  transform:translateY(-1px);
  box-shadow:0 11px 24px rgba(23,34,53,.22);
}
.auth-primary:active{transform:translateY(0)}
.auth-primary span{margin-left:8px;color:#ffbe16}

.auth-login-link{
  margin:22px 0 0;
  text-align:center;
  color:#717b86;
  font-size:11px;
}
.auth-login-link a,
.auth-link{
  color:#172235;
  font-weight:800;
  text-decoration:underline;
  text-underline-offset:3px;
}
.auth-login-link a:hover,
.auth-link:hover{color:#9a6a00}

.verification-form{max-width:430px}
.verification-form .otp-input{
  text-align:center;
  font-size:29px;
  font-weight:900;
  letter-spacing:10px;
  height:64px;
  padding-left:22px;
  background:#fafbfc;
}
.verification-form small{
  display:block;
  margin:8px 0 20px;
  color:#8a939d;
  font-size:9px;
}
.auth-link-button{
  border:0;
  background:none;
  padding:0;
  color:#172235;
  font-size:10px;
  font-weight:800;
  text-decoration:underline;
  text-underline-offset:3px;
  cursor:pointer;
}
.verify-actions{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:15px;
  margin-top:16px;
  max-width:430px;
}
.verify-actions .auth-link{font-size:10px}

/* Prevent browser defaults from making the auth page look unstyled */
.auth-form-panel form{margin:0}
.auth-form-panel button{font-family:inherit}
.auth-form-panel strong{color:#172235}
.auth-form-panel .verification-form + .verification-form{margin-top:12px !important}

@media(max-width:850px){
  .auth-card{grid-template-columns:1fr}
  .auth-brand-panel{
    min-height:auto;
    padding:38px 32px;
  }
  .auth-brand-panel h1{font-size:31px}
  .auth-benefits{
    margin-top:22px;
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:8px;
  }
  .auth-form-panel{padding:38px 32px}
}

@media(max-width:560px){
  .auth-page{
    min-height:calc(100vh - 70px);
    padding:20px 10px 40px;
  }
  .auth-card{
    border-radius:12px;
    width:100%;
  }
  .auth-brand-panel{padding:28px 24px}
  .auth-logo{margin-bottom:22px}
  .auth-brand-panel h1{font-size:27px}
  .auth-brand-panel>p{font-size:12px}
  .auth-benefits{
    grid-template-columns:1fr;
    gap:7px;
  }
  .auth-form-panel{padding:30px 22px}
  .auth-form-panel h2{font-size:25px}
  .verification-form .otp-input{
    font-size:24px;
    letter-spacing:7px;
  }
  .verify-actions{
    flex-direction:column;
    align-items:flex-start;
  }
}
</style>


<main class="auth-page">
    <section class="auth-card">

        <div class="auth-brand-panel">
            <img class="auth-logo" src="<?= BASE_URL ?>/assets/img/pys-furniture-logo.png" alt="PYS Furniture">

            <div class="auth-kicker">
                SQUARE FURNITURE MANUFACTURE
            </div>

            <h1>Furniture made for your home.</h1>

            <p>
                Welcome back. Sign in to manage your account,
                track your orders and enjoy a smoother shopping
                experience with Square Furniture Manufacture.
            </p>

            <div class="auth-benefits">
                <span>✓ Secure customer account</span>
                <span>✓ Email verification</span>
                <span>✓ Easy order tracking</span>
            </div>
        </div>

        <div class="auth-form-panel">

            <?php if ($loginOtpPending): ?>

                <div class="auth-step-label">STEP 2 OF 2</div>

                <h2>Verify your login</h2>

                <p class="auth-intro">
                    Enter the 6-digit verification code sent to
                    <strong><?= e((string) $_SESSION['login_otp_email']) ?></strong>.
                    The code expires after 10 minutes.
                </p>

                <form
                    method="post"
                    action="verify_login.php"
                    class="verification-form"
                    novalidate
                >
                    <?= csrf_field() ?>

                    <input type="hidden" name="action" value="verify">

                    <div class="auth-field">
                        <label for="loginOtp">Verification code</label>

                        <input
                            id="loginOtp"
                            class="otp-input"
                            type="text"
                            name="otp"
                            inputmode="numeric"
                            autocomplete="one-time-code"
                            maxlength="6"
                            pattern="[0-9]{6}"
                            placeholder="000000"
                            aria-describedby="otpHelp"
                            required
                        >

                        <small id="otpHelp">
                            Enter the 6-digit code from your email.
                        </small>
                    </div>

                    <button type="submit" class="auth-primary">
                        Verify &amp; Continue <span>→</span>
                    </button>
                </form>

                <form
                    method="post"
                    action="verify_login.php"
                    class="verification-form"
                    style="margin-top: 12px;"
                >
                    <?= csrf_field() ?>

                    <input type="hidden" name="action" value="resend">

                    <button type="submit" class="auth-primary">
                        Resend verification code
                    </button>
                </form>

                <p class="auth-login-link">
                    <a href="login.php?restart=1">Use a different account</a>
                </p>

            <?php else: ?>

                <div class="auth-step-label">CUSTOMER ACCOUNT</div>

                <h2>Welcome back</h2>

                <p class="auth-intro">
                    Sign in to your account. We'll verify your email
                    before completing your login.
                </p>

                <form method="post" novalidate>
                    <?= csrf_field() ?>

                    <div class="auth-field">
                        <label for="loginEmail">Email address</label>

                        <input
                            id="loginEmail"
                            type="email"
                            name="email"
                            autocomplete="email"
                            placeholder="you@example.com"
                            required
                        >
                    </div>

                    <div class="auth-field">
                        <label for="loginPassword">Password</label>

                        <input
                            id="loginPassword"
                            type="password"
                            name="password"
                            autocomplete="current-password"
                            placeholder="Enter your password"
                            required
                        >
                    </div>

                    <button type="submit" class="auth-primary">
                        Continue to Email Verification <span>→</span>
                    </button>
                </form>

                <p class="auth-login-link">
                    Don't have an account?
                    <a href="<?= BASE_URL ?>/auth/register.php">
                        Create an account
                    </a>
                </p>

            <?php endif; ?>

        </div>
    </section>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const otp = document.getElementById('loginOtp');

    if (otp) {
        otp.addEventListener('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 6);
        });
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>