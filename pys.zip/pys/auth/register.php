<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/init.php';

$page_title = 'Create Account - ' . APP_NAME;

$registrationEmail = (string) ($_SESSION['registration_email'] ?? '');
if (isset($_GET['restart'])) {
    unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id'], $_SESSION['registration_last_sent']);
    $registrationEmail = '';
}
$step = ($registrationEmail !== '' && isset($_SESSION['registration_step']))
    ? 'verify'
    : 'details';

$old = [
    'name' => '',
    'email' => '',
    'phone' => '',
    'address' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = (string) ($_POST['action'] ?? 'start');

    /* ---------------------------------------------------------------
     * Start registration: validate details, create a pending record,
     * send the verification code through Brevo, but DO NOT create the
     * customer account yet.
     * --------------------------------------------------------------- */
    if ($action === 'start') {
        $old['name'] = trim((string) ($_POST['name'] ?? ''));
        $old['email'] = strtolower(trim((string) ($_POST['email'] ?? '')));
        $old['phone'] = trim((string) ($_POST['phone'] ?? ''));
        $old['address'] = trim((string) ($_POST['address'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $passwordConfirm = (string) ($_POST['password_confirm'] ?? '');

        if (mb_strlen($old['name']) < 2 || mb_strlen($old['name']) > 120) {
            flash('danger', 'Please enter your full name.');
            $step = 'details';
        } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
            flash('danger', 'Please enter a valid email address.');
            $step = 'details';
        } elseif (mb_strlen($old['phone']) < 7 || mb_strlen($old['phone']) > 30) {
            flash('danger', 'Please enter a valid phone number.');
            $step = 'details';
        } elseif (mb_strlen($old['address']) < 5 || mb_strlen($old['address']) > 1000) {
            flash('danger', 'Please enter your delivery address.');
            $step = 'details';
        } elseif (strlen($password) < 8) {
            flash('danger', 'Your password must contain at least 8 characters.');
            $step = 'details';
        } elseif ($password !== $passwordConfirm) {
            flash('danger', 'Your passwords do not match.');
            $step = 'details';
        } else {
            /* A verified existing account should use login instead. */
            $stmt = $conn->prepare("SELECT id, email_verified, status FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param('s', $old['email']);
            $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($existing) {
                if ((int) ($existing['email_verified'] ?? 0) === 1) {
                    flash('warning', 'An account with this email already exists. Please log in instead.');
                    redirect('login.php');
                }

                /* Legacy/unverified account: keep it out of the new flow. */
                flash('warning', 'This email is already associated with an unverified account. Please use the email verification option from your account or contact support.');
                redirect('login.php');
            }

            /* One active pending registration per email. */
            $stmt = $conn->prepare("SELECT id, created_at FROM pending_customer_registrations WHERE email = ? LIMIT 1");
            $stmt->bind_param('s', $old['email']);
            $stmt->execute();
            $pendingExisting = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($pendingExisting) {
                $createdAt = strtotime((string) ($pendingExisting['created_at'] ?? '')) ?: 0;
                if ($createdAt > 0 && (time() - $createdAt) < 60) {
                    flash('warning', 'Please wait a moment before requesting another verification code.');
                    $_SESSION['registration_email'] = $old['email'];
                    $_SESSION['registration_step'] = 'verify';
                    redirect('register.php');
                }
            }

            $otp = (string) random_int(100000, 999999);
            $otpHash = password_hash($otp, PASSWORD_DEFAULT);
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            if ($otpHash === false || $passwordHash === false) {
                flash('danger', 'We could not securely prepare your registration. Please try again.');
                $step = 'details';
            } else {
                $emailContent = square_furniture_verification_email($old['name'], $otp);

                /* Replace old pending record with the newest registration. */
                $conn->begin_transaction();

                try {
                    $stmt = $conn->prepare("DELETE FROM pending_customer_registrations WHERE email = ?");
                    $stmt->bind_param('s', $old['email']);
                    $stmt->execute();
                    $stmt->close();

                    $expiresAt = date('Y-m-d H:i:s', time() + 600);
                    $stmt = $conn->prepare("INSERT INTO pending_customer_registrations (name,email,phone,address,password_hash,otp_hash,expires_at,attempts) VALUES (?,?,?,?,?,?,?,0)");
                    $stmt->bind_param('sssssss', $old['name'], $old['email'], $old['phone'], $old['address'], $passwordHash, $otpHash, $expiresAt);
                    $stmt->execute();
                    $pendingId = (int) $conn->insert_id;
                    $stmt->close();

                    $mail = send_brevo_email(
                        $old['email'],
                        $old['name'],
                        APP_NAME . ' - Your verification code',
                        $emailContent['html'],
                        $emailContent['text']
                    );

                    if (!$mail['success']) {
                        throw new RuntimeException((string) ($mail['message'] ?? 'Brevo could not send the email.'));
                    }

                    $conn->commit();

                    $_SESSION['registration_email'] = $old['email'];
                    $_SESSION['registration_step'] = 'verify';
                    $_SESSION['registration_last_sent'] = time();
                    $_SESSION['registration_pending_id'] = $pendingId;

                    flash('success', 'Verification code sent. Check your email and enter the 6-digit code below.');
                    redirect('register.php');
                } catch (Throwable $e) {
                    $conn->rollback();
                    flash('danger', 'We could not send your verification email. Please check your Brevo configuration and try again.');
                    $step = 'details';
                }
            }
        }
    }

    /* ---------------------------------------------------------------
     * Verify code: ONLY after the code is correct is the users row
     * created. This is the important part of the new registration flow.
     * --------------------------------------------------------------- */
    elseif ($action === 'verify') {
        $email = strtolower(trim((string) ($_SESSION['registration_email'] ?? '')));
        $otp = trim((string) ($_POST['otp'] ?? ''));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('danger', 'Your registration session has expired. Please start again.');
            unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id']);
            redirect('register.php');
        }

        if (!preg_match('/^\d{6}$/', $otp)) {
            flash('danger', 'Enter the 6-digit verification code sent to your email.');
            $step = 'verify';
        } else {
            $stmt = $conn->prepare("SELECT * FROM pending_customer_registrations WHERE email = ? LIMIT 1");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $pending = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$pending) {
                flash('danger', 'No pending registration was found. Please start again.');
                unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id']);
                redirect('register.php');
            }

            $attempts = (int) ($pending['attempts'] ?? 0);
            $expiresAt = strtotime((string) ($pending['expires_at'] ?? '')) ?: 0;

            if ($attempts >= 5) {
                flash('danger', 'Too many incorrect attempts. Request a new verification code.');
                $step = 'verify';
            } elseif ($expiresAt < time()) {
                flash('warning', 'That verification code has expired. Request a new code.');
                $step = 'verify';
            } elseif (!password_verify($otp, (string) $pending['otp_hash'])) {
                $newAttempts = $attempts + 1;
                $stmt = $conn->prepare("UPDATE pending_customer_registrations SET attempts = ? WHERE id = ? LIMIT 1");
                $stmt->bind_param('ii', $newAttempts, $pending['id']);
                $stmt->execute();
                $stmt->close();
                flash('danger', 'That code is not correct. Please try again.');
                $step = 'verify';
            } else {
                /* Create the actual account only now. */
                $conn->begin_transaction();
                try {
                    $role = 'customer';
                    $isAdmin = 0;
                    $verified = 1;
                    $status = 'active';

                    $stmt = $conn->prepare("INSERT INTO users (name,email,phone,address,password,role,is_admin,email_verified,status) VALUES (?,?,?,?,?,?,?,?,?)");
                    $stmt->bind_param(
                        'ssssssiis',
                        $pending['name'],
                        $pending['email'],
                        $pending['phone'],
                        $pending['address'],
                        $pending['password_hash'],
                        $role,
                        $isAdmin,
                        $verified,
                        $status
                    );
                    $stmt->execute();
                    $newUserId = (int) $conn->insert_id;
                    $stmt->close();

                    $stmt = $conn->prepare("DELETE FROM pending_customer_registrations WHERE id = ? LIMIT 1");
                    $stmt->bind_param('i', $pending['id']);
                    $stmt->execute();
                    $stmt->close();

                    $conn->commit();

                    unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id'], $_SESSION['registration_last_sent']);

                    try {
                        log_activity($conn, $newUserId, 'Customer registration and email verification');
                    } catch (Throwable $e) {
                        // Account creation should not fail because activity logging failed.
                    }

                    flash('success', 'Your email has been verified and your Square Furniture account is ready. Please log in to continue.');
                    redirect('login.php');
                } catch (Throwable $e) {
                    $conn->rollback();
                    flash('danger', 'We could not finish creating your account. Please try again.');
                    $step = 'verify';
                }
            }
        }
    }

    /* ---------------------------------------------------------------
     * Resend verification code.
     * --------------------------------------------------------------- */
    elseif ($action === 'resend') {
        $email = strtolower(trim((string) ($_SESSION['registration_email'] ?? '')));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('danger', 'Your registration session has expired. Please start again.');
            unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id']);
            redirect('register.php');
        }

        $lastSent = (int) ($_SESSION['registration_last_sent'] ?? 0);
        if ($lastSent > 0 && (time() - $lastSent) < 60) {
            flash('warning', 'Please wait ' . (60 - (time() - $lastSent)) . ' seconds before requesting another code.');
            $step = 'verify';
        } else {
            $stmt = $conn->prepare("SELECT * FROM pending_customer_registrations WHERE email = ? LIMIT 1");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $pending = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$pending) {
                flash('danger', 'Your pending registration could not be found. Please start again.');
                unset($_SESSION['registration_email'], $_SESSION['registration_step'], $_SESSION['registration_pending_id']);
                redirect('register.php');
            }

            $otp = (string) random_int(100000, 999999);
            $otpHash = password_hash($otp, PASSWORD_DEFAULT);
            $expiresAt = date('Y-m-d H:i:s', time() + 600);
            $emailContent = square_furniture_verification_email((string) $pending['name'], $otp);

            $mail = send_brevo_email(
                $email,
                (string) $pending['name'],
                APP_NAME . ' - Your new verification code',
                $emailContent['html'],
                $emailContent['text']
            );

            if (!$mail['success']) {
                flash('danger', 'We could not send a new verification email. Please try again.');
                $step = 'verify';
            } else {
                $stmt = $conn->prepare("UPDATE pending_customer_registrations SET otp_hash = ?, expires_at = ?, attempts = 0 WHERE id = ? LIMIT 1");
                $stmt->bind_param('ssi', $otpHash, $expiresAt, $pending['id']);
                $stmt->execute();
                $stmt->close();
                $_SESSION['registration_last_sent'] = time();
                flash('success', 'A new verification code has been sent to your email.');
                $step = 'verify';
            }
        }
    }
}

/* Restore email in verification step. */
$registrationEmail = (string) ($_SESSION['registration_email'] ?? $registrationEmail);
$step = ($registrationEmail !== '' && ($_SESSION['registration_step'] ?? '') === 'verify') ? 'verify' : $step;

include __DIR__ . '/../includes/header.php';
?>

<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/auth.css">

<div class="auth-page">
    <div class="auth-card auth-register-card">
        <div class="auth-brand-panel">
            <img class="auth-logo" src="<?= BASE_URL ?>/assets/img/pys-furniture-logo.png" alt="PYS Furniture">
            <div class="auth-kicker">SQUARE FURNITURE MANUFACTURE</div>
            <h1>Furniture made for your home.</h1>
            <p>Create your customer account to save your details, manage orders and shop furniture faster.</p>
            <div class="auth-benefits">
                <span>✓ Secure customer account</span>
                <span>✓ Email verification</span>
                <span>✓ Faster checkout</span>
            </div>
        </div>

        <div class="auth-form-panel">
            <?php if ($step === 'verify'): ?>
                <div class="auth-step-label">STEP 2 OF 2</div>
                <h2>Check your email</h2>
                <p class="auth-intro">We sent a 6-digit verification code to <strong><?= e($registrationEmail) ?></strong>.</p>

                <form method="post" class="verification-form" autocomplete="one-time-code">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="verify">

                    <label for="registrationOtp">Verification code</label>
                    <input
                        id="registrationOtp"
                        class="otp-input"
                        type="text"
                        name="otp"
                        inputmode="numeric"
                        autocomplete="one-time-code"
                        maxlength="6"
                        pattern="[0-9]{6}"
                        placeholder="000000"
                        required
                        autofocus
                    >
                    <small>Code expires after 10 minutes.</small>

                    <button class="auth-primary" type="submit">Verify &amp; Create Account</button>
                </form>

                <div class="verify-actions">
                    <form method="post">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="resend">
                        <button type="submit" class="auth-link-button">Resend code</button>
                    </form>
                    <a href="register.php?restart=1" class="auth-link">Use a different email</a>
                </div>
            <?php else: ?>
                <div class="auth-step-label">STEP 1 OF 2</div>
                <h2>Create your account</h2>
                <p class="auth-intro">Enter your details. We will verify your email before your customer account is created.</p>

                <form method="post" class="register-form" autocomplete="on">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="start">

                    <div class="auth-field">
                        <label for="registerName">Full name</label>
                        <input id="registerName" type="text" name="name" value="<?= e($old['name']) ?>" autocomplete="name" placeholder="Your full name" required>
                    </div>

                    <div class="auth-field">
                        <label for="registerEmail">Email address</label>
                        <input id="registerEmail" type="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" placeholder="you@example.com" required>
                    </div>

                    <div class="auth-two-col">
                        <div class="auth-field">
                            <label for="registerPhone">Phone number</label>
                            <input id="registerPhone" type="tel" name="phone" value="<?= e($old['phone']) ?>" autocomplete="tel" placeholder="e.g. 082 123 4567" required>
                        </div>
                        <div class="auth-field">
                            <label for="registerAddress">Delivery address</label>
                            <input id="registerAddress" type="text" name="address" value="<?= e($old['address']) ?>" autocomplete="street-address" placeholder="Street / suburb / city" required>
                        </div>
                    </div>

                    <div class="auth-two-col">
                        <div class="auth-field">
                            <label for="registerPassword">Password</label>
                            <input id="registerPassword" type="password" name="password" autocomplete="new-password" placeholder="Minimum 8 characters" minlength="8" required>
                        </div>
                        <div class="auth-field">
                            <label for="registerPasswordConfirm">Confirm password</label>
                            <input id="registerPasswordConfirm" type="password" name="password_confirm" autocomplete="new-password" placeholder="Repeat your password" minlength="8" required>
                        </div>
                    </div>

                    <label class="auth-check">
                        <input type="checkbox" required>
                        <span>I agree to use this account for genuine Square Furniture purchases and communications related to my orders.</span>
                    </label>

                    <button class="auth-primary" type="submit">Continue &amp; Verify Email <span>→</span></button>
                </form>

                <p class="auth-login-link">Already have an account? <a href="login.php">Sign in</a></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const otp = document.getElementById('registrationOtp');
    if (otp) {
        otp.addEventListener('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 6);
        });
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
