<?php
require_once 'config/db.php';
$email='admin@squarefurniture.co.za';
$password='Admin@123';
$hash=password_hash($password,PASSWORD_DEFAULT);
$stmt=$conn->prepare("INSERT INTO users(name,email,password,role,is_admin,email_verified,status) VALUES('Square Furniture Admin',?,?, 'admin',1,1,'active') ON DUPLICATE KEY UPDATE password=VALUES(password),role='admin',is_admin=1,email_verified=1,status='active'");
$stmt->bind_param('ss',$email,$hash);$stmt->execute();
echo '<h2>Admin account created/reset.</h2><p>Email: '.htmlspecialchars($email).'</p><p>Password: '.htmlspecialchars($password).'</p><p><strong>Delete setup_admin.php from the server now.</strong></p>';
?>